"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"

export default function LoginPage() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    remember: false,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Login submitted:", formData)
    alert("تم تسجيل الدخول بنجاح!")
    // Redirect would happen here in a real app
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--light-bg)] py-12 px-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-[var(--dark-text)] mb-2">تسجيل الدخول</h1>
          <p className="text-[var(--light-text)]">أدخل بيانات حسابك للوصول إلى لوحة التحكم</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email" className="form-label">
              البريد الإلكتروني
            </label>
            <input
              type="email"
              id="email"
              name="email"
              className="form-input"
              placeholder="أدخل بريدك الإلكتروني"
              required
              value={formData.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password" className="form-label">
              كلمة المرور
            </label>
            <input
              type="password"
              id="password"
              name="password"
              className="form-input"
              placeholder="أدخل كلمة المرور"
              required
              value={formData.password}
              onChange={handleChange}
            />
          </div>

          <div className="flex justify-between items-center mb-6">
            <label className="flex items-center">
              <input
                type="checkbox"
                name="remember"
                className="ml-2"
                checked={formData.remember}
                onChange={handleChange}
              />
              <span className="text-sm">تذكرني</span>
            </label>
            <Link href="#" className="text-sm text-[var(--primary-color)] hover:underline">
              نسيت كلمة المرور؟
            </Link>
          </div>

          <button type="submit" className="btn btn-primary w-full py-3">
            تسجيل الدخول
          </button>

          <div className="text-center mt-6">
            <p>
              ليس لديك حساب؟{" "}
              <Link href="#" className="text-[var(--primary-color)] font-semibold hover:underline">
                إنشاء حساب جديد
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  )
}
