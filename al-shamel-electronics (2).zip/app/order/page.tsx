"use client"

import type React from "react"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { PlaneIcon as PaperPlane, ArrowRight, CheckCircle } from "lucide-react"

export default function OrderPage() {
  const searchParams = useSearchParams()
  const productName = searchParams.get("product") || "لم يتم تحديد المنتج"

  const [formSubmitted, setFormSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    customerName: "",
    customerPhone: "",
    customerLocation: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Order submitted:", { ...formData, productName })
    setFormSubmitted(true)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="py-16 bg-[var(--light-bg)]">
      <div className="container max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-md">
        <h1 className="text-3xl text-center text-[var(--primary-color)] mb-8 font-lalezar">اطلب الآن</h1>

        {formSubmitted ? (
          <div className="bg-green-50 text-green-800 p-6 rounded-lg border border-green-200 text-center">
            <h2 className="text-xl mb-3 flex items-center justify-center gap-2">
              <CheckCircle className="text-green-600" /> تم استلام طلبك بنجاح!
            </h2>
            <p className="mb-6">شكراً لك، سنتواصل معك قريباً لتأكيد التفاصيل.</p>
            <Link href="/#newest" className="text-[var(--primary-color)] font-medium hover:underline">
              العودة إلى قائمة الهواتف
            </Link>
          </div>
        ) : (
          <>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="customerName" className="form-label">
                  الاسم الكامل:
                </label>
                <input
                  type="text"
                  id="customerName"
                  name="customerName"
                  className="form-input"
                  required
                  placeholder="أدخل اسمك هنا"
                  value={formData.customerName}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="customerPhone" className="form-label">
                  رقم الهاتف:
                </label>
                <input
                  type="tel"
                  id="customerPhone"
                  name="customerPhone"
                  className="form-input"
                  required
                  placeholder="مثال: 7xxxxxxxx"
                  value={formData.customerPhone}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="productName" className="form-label">
                  اسم المنتج المطلوب:
                </label>
                <input
                  type="text"
                  id="productName"
                  name="productName"
                  className="form-input bg-gray-50 cursor-not-allowed"
                  readOnly
                  value={productName}
                />
              </div>

              <div className="form-group">
                <label htmlFor="customerLocation" className="form-label">
                  الموقع / العنوان:
                </label>
                <textarea
                  id="customerLocation"
                  name="customerLocation"
                  className="form-textarea"
                  required
                  placeholder="اكتب عنوانك أو موقعك بالتفصيل"
                  value={formData.customerLocation}
                  onChange={handleChange}
                />
              </div>

              <button type="submit" className="btn btn-primary w-full py-4 text-lg">
                <PaperPlane size={18} /> إرسال الطلب
              </button>
            </form>

            <Link
              href="/#newest"
              className="block text-center mt-6 text-[var(--primary-color)] font-medium hover:underline"
            >
              <ArrowRight className="inline ml-1" size={16} /> العودة إلى قائمة الهواتف
            </Link>
          </>
        )}
      </div>
    </div>
  )
}
