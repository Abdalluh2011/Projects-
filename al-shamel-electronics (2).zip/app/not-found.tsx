import Link from "next/link"

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center py-16 px-4 text-center">
      <h1 className="text-6xl font-bold text-[var(--primary-color)] mb-4">404</h1>
      <h2 className="text-2xl font-semibold mb-6">الصفحة غير موجودة</h2>
      <p className="text-[var(--light-text)] mb-8 max-w-md">
        عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها أو حذفها.
      </p>
      <Link href="/" className="btn btn-primary">
        العودة للصفحة الرئيسية
      </Link>
    </div>
  )
}
