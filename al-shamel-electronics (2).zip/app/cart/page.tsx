"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react"
import { useCart } from "@/lib/cart-context"

export default function CartPage() {
  const { items, removeItem, updateQuantity, clearCart, totalPrice } = useCart()
  const [couponCode, setCouponCode] = useState("")
  const [couponApplied, setCouponApplied] = useState(false)
  const [couponDiscount, setCouponDiscount] = useState(0)

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault()

    // Simple coupon logic - in a real app this would validate against a database
    if (couponCode.toLowerCase() === "خصم10") {
      setCouponApplied(true)
      setCouponDiscount(totalPrice * 0.1) // 10% discount
    } else {
      alert("كود الخصم غير صالح")
    }
  }

  const finalTotal = totalPrice - couponDiscount

  if (items.length === 0) {
    return (
      <div className="py-16 bg-[#f8f7fc] min-h-[70vh]">
        <div className="container max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-md text-center">
          <div className="flex flex-col items-center justify-center py-12">
            <ShoppingBag size={64} className="text-gray-300 mb-4" />
            <h1 className="text-2xl font-bold mb-2">سلة التسوق فارغة</h1>
            <p className="text-gray-500 mb-8">لم تقم بإضافة أي منتجات إلى سلة التسوق بعد</p>
            <Link href="/products" className="btn btn-primary">
              <ArrowRight size={18} className="ml-2" /> تصفح المنتجات
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="py-16 bg-[#f8f7fc]">
      <div className="container">
        <h1 className="text-3xl font-lalezar text-primary mb-8">سلة التسوق</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3">
            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-100">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">المنتجات ({items.length})</h2>
                  <button
                    onClick={clearCart}
                    className="text-sm text-red-500 hover:text-red-700 flex items-center gap-1"
                  >
                    <Trash2 size={16} /> إفراغ السلة
                  </button>
                </div>
              </div>

              <div className="divide-y divide-gray-100">
                {items.map((item) => (
                  <div key={item.id} className="p-6 flex flex-col sm:flex-row gap-4">
                    <div className="sm:w-24 h-24 relative flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        sizes="96px"
                        className="object-contain"
                      />
                    </div>

                    <div className="flex-1">
                      <Link href={`/products/${item.id}`} className="font-medium hover:text-primary">
                        {item.name}
                      </Link>
                      <div className="text-primary font-bold mt-1">{item.price} ريال</div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex items-center border border-gray-200 rounded-md">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-primary"
                          aria-label="تقليل الكمية"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="w-10 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-primary"
                          aria-label="زيادة الكمية"
                        >
                          <Plus size={16} />
                        </button>
                      </div>

                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-gray-400 hover:text-red-500"
                        aria-label="إزالة من السلة"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:w-1/3">
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h2 className="text-xl font-semibold mb-6">ملخص الطلب</h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">المجموع الفرعي</span>
                  <span>{totalPrice.toFixed(2)} ريال</span>
                </div>

                {couponApplied && (
                  <div className="flex justify-between text-green-600">
                    <span>خصم الكوبون</span>
                    <span>- {couponDiscount.toFixed(2)} ريال</span>
                  </div>
                )}

                <div className="flex justify-between font-bold text-lg pt-4 border-t border-gray-100">
                  <span>الإجمالي</span>
                  <span className="text-primary">{finalTotal.toFixed(2)} ريال</span>
                </div>
              </div>

              <form onSubmit={handleApplyCoupon} className="mb-6">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="كود الخصم"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    disabled={couponApplied}
                  />
                  <button type="submit" className="btn btn-outline py-2 px-4" disabled={couponApplied || !couponCode}>
                    تطبيق
                  </button>
                </div>
                {couponApplied && <p className="text-green-600 text-sm mt-2">تم تطبيق كود الخصم بنجاح!</p>}
              </form>

              <Link href="/checkout" className="btn btn-primary w-full">
                إتمام الشراء
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
