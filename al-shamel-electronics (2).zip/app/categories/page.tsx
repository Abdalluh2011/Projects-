import Link from "next/link"
import Image from "next/image"
import { categories, getProductsByCategory } from "@/lib/products"
import ProductRating from "@/components/product-rating"

export default function CategoriesPage() {
  return (
    <div className="py-16 bg-[#f8f7fc]">
      <div className="container">
        <h1 className="text-3xl font-lalezar text-primary mb-8">فئات الهواتف</h1>

        <div className="space-y-12">
          {categories.map((category) => {
            const categoryProducts = getProductsByCategory(category.id).slice(0, 4)

            return (
              <div key={category.id} className="bg-white rounded-2xl shadow-md overflow-hidden">
                <div className="p-6 border-b border-gray-100">
                  <h2 className="text-2xl font-lalezar text-primary">{category.name}</h2>
                  <p className="text-gray-600 mt-1">{category.description}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
                  {categoryProducts.map((product) => (
                    <div
                      key={product.id}
                      className="border border-gray-200 rounded-lg overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                    >
                      <Link href={`/products/${product.slug}`} className="block p-4">
                        <div className="h-40 flex items-center justify-center mb-4">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            width={120}
                            height={120}
                            className="object-contain max-h-full"
                          />
                        </div>
                        <h3 className="font-medium mb-2 line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
                        <ProductRating rating={product.rating} size="sm" />
                        <div className="mt-2">
                          <span className="font-bold text-primary">{product.currentPrice} ريال</span>
                          {product.oldPrice && (
                            <span className="text-sm text-gray-500 line-through mr-2">{product.oldPrice} ريال</span>
                          )}
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>

                <div className="p-4 text-center border-t border-gray-100">
                  <Link href={`/categories/${category.id}`} className="text-primary hover:underline font-medium">
                    عرض كل هواتف {category.name}
                  </Link>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
