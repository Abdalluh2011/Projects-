import { notFound } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { categories, getProductsByCategory } from "@/lib/products"
import ProductRating from "@/components/product-rating"
import AddToCartButton from "@/components/add-to-cart-button"

interface CategoryPageProps {
  params: {
    id: string
  }
}

export default function CategoryPage({ params }: CategoryPageProps) {
  const categoryId = params.id
  const category = categories.find((c) => c.id === categoryId)

  if (!category) {
    notFound()
  }

  const products = getProductsByCategory(categoryId)

  return (
    <div className="py-16 bg-[#f8f7fc]">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-3xl font-lalezar text-primary mb-2">{category.name}</h1>
          <p className="text-gray-600">{category.description}</p>
        </div>

        {products.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl shadow-md text-center">
            <p className="text-gray-600">لا توجد منتجات في هذه الفئة حالياً</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
              >
                <Link href={`/products/${product.slug}`} className="block p-4">
                  <div className="relative h-48 flex items-center justify-center mb-4">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={150}
                      height={150}
                      className="object-contain max-h-full"
                    />
                    {product.badge && (
                      <div
                        className={`absolute top-0 left-0 ${
                          product.badge.type === "new"
                            ? "bg-[#dc3545]"
                            : product.badge.type === "bestseller"
                              ? "bg-[#28a745]"
                              : "bg-[#ffc107] text-[#333]"
                        } text-white px-3 py-1 rounded-br-lg text-sm`}
                      >
                        {product.badge.text}
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium mb-2 line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
                  <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="sm" />
                  <div className="mt-2 mb-4">
                    <span className="font-bold text-primary">{product.currentPrice} ريال</span>
                    {product.oldPrice && (
                      <span className="text-sm text-gray-500 line-through mr-2">{product.oldPrice} ريال</span>
                    )}
                  </div>
                </Link>
                <div className="p-4 pt-0">
                  <AddToCartButton product={product} showQuantity={false} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
