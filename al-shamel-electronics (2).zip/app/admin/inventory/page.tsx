"use client"

import { useState } from "react"
import Image from "next/image"
import { Search, AlertTriangle, Check, RefreshCw } from "lucide-react"
import AdminLayout from "@/components/admin/admin-layout"
import { products } from "@/lib/products"

// Add inventory data to products
const inventoryProducts = products.map((product) => ({
  ...product,
  stock: Math.floor(Math.random() * 50), // Random stock between 0-49
  sku: `SKU-${product.id.toUpperCase()}`,
  location: "المستودع الرئيسي",
  lastUpdated: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000).toISOString(), // Random date within last 30 days
}))

export default function InventoryManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [stockFilter, setStockFilter] = useState("all")

  const filteredProducts = inventoryProducts.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())

    if (stockFilter === "all") return matchesSearch
    if (stockFilter === "low" && product.stock < 10) return matchesSearch
    if (stockFilter === "out" && product.stock === 0) return matchesSearch
    if (stockFilter === "in" && product.stock > 0) return matchesSearch

    return false
  })

  const getStockStatus = (stock: number) => {
    if (stock === 0) {
      return (
        <span className="flex items-center text-red-600 gap-1">
          <AlertTriangle size={14} /> نفذ المخزون
        </span>
      )
    } else if (stock < 10) {
      return (
        <span className="flex items-center text-amber-600 gap-1">
          <AlertTriangle size={14} /> منخفض ({stock})
        </span>
      )
    } else {
      return (
        <span className="flex items-center text-green-600 gap-1">
          <Check size={14} /> متوفر ({stock})
        </span>
      )
    }
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">إدارة المخزون</h1>
          <div className="flex gap-2">
            <button className="bg-primary text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-primary/90 transition-colors">
              <RefreshCw size={18} /> تحديث المخزون
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                placeholder="البحث عن منتج أو SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
            <select
              value={stockFilter}
              onChange={(e) => setStockFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="all">جميع المنتجات</option>
              <option value="low">مخزون منخفض</option>
              <option value="out">نفذ المخزون</option>
              <option value="in">متوفر</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-right">المنتج</th>
                  <th className="px-4 py-3 text-right">SKU</th>
                  <th className="px-4 py-3 text-right">المخزون</th>
                  <th className="px-4 py-3 text-right">الموقع</th>
                  <th className="px-4 py-3 text-right">آخر تحديث</th>
                  <th className="px-4 py-3 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 relative flex-shrink-0">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            fill
                            sizes="40px"
                            className="object-contain"
                          />
                        </div>
                        <span className="font-medium">{product.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{product.sku}</td>
                    <td className="px-4 py-3">{getStockStatus(product.stock)}</td>
                    <td className="px-4 py-3 text-gray-600">{product.location}</td>
                    <td className="px-4 py-3 text-gray-600">
                      {new Date(product.lastUpdated).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center">
                        <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-200 transition-colors">
                          تعديل المخزون
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-8 text-gray-500">لا توجد منتجات مطابقة للبحث</div>
          )}

          <div className="mt-4 flex justify-between items-center text-sm text-gray-600">
            <span>إجمالي المنتجات: {inventoryProducts.length}</span>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">السابق</button>
              <span className="px-3 py-1 bg-primary text-white rounded">1</span>
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">التالي</button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
