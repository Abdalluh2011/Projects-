"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Eye, Download, Mail } from "lucide-react"
import AdminLayout from "@/components/admin/admin-layout"

// Sample customers data
const customers = [
  {
    id: "CUST-001",
    name: "أحمد محمد",
    email: "ahmed@example.com",
    phone: "0512345678",
    orders: 5,
    totalSpent: 7899,
    lastOrder: "2023-05-10",
    status: "active",
  },
  {
    id: "CUST-002",
    name: "سارة أحمد",
    email: "sara@example.com",
    phone: "0523456789",
    orders: 2,
    totalSpent: 1299,
    lastOrder: "2023-04-25",
    status: "active",
  },
  {
    id: "CUST-003",
    name: "محمد علي",
    email: "mohamed@example.com",
    phone: "0534567890",
    orders: 8,
    totalSpent: 12499,
    lastOrder: "2023-05-15",
    status: "active",
  },
  {
    id: "CUST-004",
    name: "فاطمة حسن",
    email: "fatima@example.com",
    phone: "0545678901",
    orders: 1,
    totalSpent: 799,
    lastOrder: "2023-03-20",
    status: "inactive",
  },
  {
    id: "CUST-005",
    name: "خالد عبدالله",
    email: "khaled@example.com",
    phone: "0556789012",
    orders: 3,
    totalSpent: 4299,
    lastOrder: "2023-05-05",
    status: "active",
  },
]

export default function CustomersManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredCustomers = customers.filter(
    (customer) =>
      (customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone.includes(searchTerm)) &&
      (statusFilter === "all" || customer.status === statusFilter),
  )

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">إدارة العملاء</h1>
          <div className="flex gap-2">
            <button className="bg-primary text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-primary/90 transition-colors">
              <Mail size={18} /> إرسال بريد جماعي
            </button>
            <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md flex items-center gap-2 hover:bg-gray-200 transition-colors">
              <Download size={18} /> تصدير العملاء
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                placeholder="البحث عن عميل..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="all">جميع العملاء</option>
              <option value="active">نشط</option>
              <option value="inactive">غير نشط</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-right">العميل</th>
                  <th className="px-4 py-3 text-right">البريد الإلكتروني</th>
                  <th className="px-4 py-3 text-right">الهاتف</th>
                  <th className="px-4 py-3 text-right">الطلبات</th>
                  <th className="px-4 py-3 text-right">إجمالي الإنفاق</th>
                  <th className="px-4 py-3 text-right">آخر طلب</th>
                  <th className="px-4 py-3 text-right">الحالة</th>
                  <th className="px-4 py-3 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{customer.name}</td>
                    <td className="px-4 py-3 text-gray-600">{customer.email}</td>
                    <td className="px-4 py-3">{customer.phone}</td>
                    <td className="px-4 py-3 text-center">{customer.orders}</td>
                    <td className="px-4 py-3 font-medium">{customer.totalSpent} ريال</td>
                    <td className="px-4 py-3 text-gray-600">
                      {new Date(customer.lastOrder).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="px-4 py-3">
                      {customer.status === "active" ? (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          نشط
                        </span>
                      ) : (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                          غير نشط
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center">
                        <Link
                          href={`/admin/customers/${customer.id}`}
                          className="p-1 text-blue-600 hover:text-blue-800"
                        >
                          <Eye size={18} />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredCustomers.length === 0 && (
            <div className="text-center py-8 text-gray-500">لا يوجد عملاء مطابقين للبحث</div>
          )}

          <div className="mt-4 flex justify-between items-center text-sm text-gray-600">
            <span>إجمالي العملاء: {customers.length}</span>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">السابق</button>
              <span className="px-3 py-1 bg-primary text-white rounded">1</span>
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">التالي</button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
