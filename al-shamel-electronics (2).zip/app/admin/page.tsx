"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminLayout from "@/components/admin/admin-layout"
import DashboardStats from "@/components/admin/dashboard-stats"
import RecentOrders from "@/components/admin/recent-orders"
import LowStockProducts from "@/components/admin/low-stock-products"
import SalesChart from "@/components/admin/sales-chart"

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Simulate authentication check
  useEffect(() => {
    const checkAuth = () => {
      // In a real app, this would check for a valid admin session
      const isAdmin = localStorage.getItem("adminAuthenticated") === "true"
      setIsAuthenticated(isAdmin)
      setIsLoading(false)

      if (!isAdmin) {
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">لوحة التحكم</h1>

        <DashboardStats />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">المبيعات الأخيرة</h2>
            <SalesChart />
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">الطلبات الأخيرة</h2>
            <RecentOrders />
          </div>
        </div>

        <div className="mt-6 bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">المنتجات منخفضة المخزون</h2>
          <LowStockProducts />
        </div>
      </div>
    </AdminLayout>
  )
}
