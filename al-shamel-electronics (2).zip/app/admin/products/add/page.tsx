"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowRight, Upload } from "lucide-react"
import AdminLayout from "@/components/admin/admin-layout"

export default function AddProductPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    brand: "",
    category: "هواتف فاخرة",
    currentPrice: "",
    oldPrice: "",
    description: "",
    image: "",
    specifications: {
      screen: "",
      processor: "",
      backCamera: "",
      frontCamera: "",
      storage: "",
      ram: "",
      battery: "",
      additionalFeatures: "",
    },
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target

    if (name.includes(".")) {
      const [parent, child] = name.split(".")
      setFormData((prev) => ({
        ...prev,
        [parent]: {
          ...prev[parent as keyof typeof prev],
          [child]: value,
        },
      }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // في تطبيق حقيقي، هنا سيتم إرسال البيانات إلى API
    console.log("تم إرسال بيانات المنتج:", formData)

    // محاكاة تأخير الشبكة
    setTimeout(() => {
      setIsSubmitting(false)
      alert("تم إضافة المنتج بنجاح!")
      router.push("/admin/products")
    }, 1000)
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">إضافة منتج جديد</h1>
          <Link
            href="/admin/products"
            className="flex items-center gap-2 text-gray-600 hover:text-primary transition-colors"
          >
            <ArrowRight size={18} /> العودة إلى المنتجات
          </Link>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="name" className="block text-gray-700 mb-2">
                اسم المنتج <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="مثال: iPhone 13 Pro Max"
              />
            </div>

            <div>
              <label htmlFor="brand" className="block text-gray-700 mb-2">
                العلامة التجارية <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="brand"
                name="brand"
                value={formData.brand}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="مثال: Apple"
              />
            </div>

            <div>
              <label htmlFor="category" className="block text-gray-700 mb-2">
                الفئة <span className="text-red-500">*</span>
              </label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              >
                <option value="هواتف فاخرة">هواتف فاخرة</option>
                <option value="هواتف متوسطة">هواتف متوسطة</option>
                <option value="هواتف اقتصادية">هواتف اقتصادية</option>
              </select>
            </div>

            <div>
              <label htmlFor="currentPrice" className="block text-gray-700 mb-2">
                السعر الحالي <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                id="currentPrice"
                name="currentPrice"
                value={formData.currentPrice}
                onChange={handleChange}
                required
                min="0"
                step="0.01"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="مثال: 3499"
              />
            </div>

            <div>
              <label htmlFor="oldPrice" className="block text-gray-700 mb-2">
                السعر القديم (اختياري)
              </label>
              <input
                type="number"
                id="oldPrice"
                name="oldPrice"
                value={formData.oldPrice}
                onChange={handleChange}
                min="0"
                step="0.01"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="مثال: 3999"
              />
            </div>

            <div>
              <label htmlFor="image" className="block text-gray-700 mb-2">
                رابط الصورة <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  id="image"
                  name="image"
                  value={formData.image}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: /images/product.jpg"
                />
                <button
                  type="button"
                  className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md flex items-center gap-2 hover:bg-gray-200 transition-colors"
                >
                  <Upload size={18} />
                </button>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="description" className="block text-gray-700 mb-2">
              وصف المنتج <span className="text-red-500">*</span>
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="اكتب وصفاً تفصيلياً للمنتج..."
            ></textarea>
          </div>

          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-4">المواصفات الفنية</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="specifications.screen" className="block text-gray-700 mb-2">
                  الشاشة <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.screen"
                  name="specifications.screen"
                  value={formData.specifications.screen}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: Super Retina XDR بحجم 6.7 بوصة"
                />
              </div>

              <div>
                <label htmlFor="specifications.processor" className="block text-gray-700 mb-2">
                  المعالج <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.processor"
                  name="specifications.processor"
                  value={formData.specifications.processor}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: شريحة A15 Bionic"
                />
              </div>

              <div>
                <label htmlFor="specifications.backCamera" className="block text-gray-700 mb-2">
                  الكاميرا الخلفية <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.backCamera"
                  name="specifications.backCamera"
                  value={formData.specifications.backCamera}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: نظام Pro بدقة 12MP"
                />
              </div>

              <div>
                <label htmlFor="specifications.frontCamera" className="block text-gray-700 mb-2">
                  الكاميرا الأمامية <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.frontCamera"
                  name="specifications.frontCamera"
                  value={formData.specifications.frontCamera}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: TrueDepth بدقة 12MP"
                />
              </div>

              <div>
                <label htmlFor="specifications.storage" className="block text-gray-700 mb-2">
                  التخزين <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.storage"
                  name="specifications.storage"
                  value={formData.specifications.storage}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: 128GB / 256GB / 512GB"
                />
              </div>

              <div>
                <label htmlFor="specifications.ram" className="block text-gray-700 mb-2">
                  الذاكرة العشوائية (RAM)
                </label>
                <input
                  type="text"
                  id="specifications.ram"
                  name="specifications.ram"
                  value={formData.specifications.ram}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: 6GB / 8GB"
                />
              </div>

              <div>
                <label htmlFor="specifications.battery" className="block text-gray-700 mb-2">
                  البطارية <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="specifications.battery"
                  name="specifications.battery"
                  value={formData.specifications.battery}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: 5000mAh، شحن سريع 33W"
                />
              </div>

              <div>
                <label htmlFor="specifications.additionalFeatures" className="block text-gray-700 mb-2">
                  ميزات إضافية
                </label>
                <input
                  type="text"
                  id="specifications.additionalFeatures"
                  name="specifications.additionalFeatures"
                  value={formData.specifications.additionalFeatures}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="مثال: مقاومة الماء IP68، Face ID"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Link
              href="/admin/products"
              className="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
            >
              إلغاء
            </Link>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors ${
                isSubmitting ? "opacity-70 cursor-not-allowed" : ""
              }`}
            >
              {isSubmitting ? "جاري الحفظ..." : "حفظ المنتج"}
            </button>
          </div>
        </form>
      </div>
    </AdminLayout>
  )
}
