"use client"

import { useState } from "react"
import AdminLayout from "@/components/admin/admin-layout"
import SalesReportChart from "@/components/admin/sales-report-chart"
import TopProductsChart from "@/components/admin/top-products-chart"
import CustomerAcquisitionChart from "@/components/admin/customer-acquisition-chart"

export default function ReportsPage() {
  const [dateRange, setDateRange] = useState("month")

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">التقارير والإحصائيات</h1>
          <div className="flex gap-2">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="week">آخر أسبوع</option>
              <option value="month">آخر شهر</option>
              <option value="quarter">آخر 3 أشهر</option>
              <option value="year">آخر سنة</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-sm font-medium text-gray-500 mb-2">إجمالي المبيعات</h3>
            <p className="text-3xl font-bold">25,499 ريال</p>
            <div className="mt-2 flex items-center text-sm">
              <span className="text-green-600 font-medium">+12.5%</span>
              <span className="text-gray-500 mr-2">مقارنة بالفترة السابقة</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-sm font-medium text-gray-500 mb-2">عدد الطلبات</h3>
            <p className="text-3xl font-bold">128</p>
            <div className="mt-2 flex items-center text-sm">
              <span className="text-green-600 font-medium">+8.2%</span>
              <span className="text-gray-500 mr-2">مقارنة بالفترة السابقة</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-sm font-medium text-gray-500 mb-2">متوسط قيمة الطلب</h3>
            <p className="text-3xl font-bold">199 ريال</p>
            <div className="mt-2 flex items-center text-sm">
              <span className="text-red-600 font-medium">-2.1%</span>
              <span className="text-gray-500 mr-2">مقارنة بالفترة السابقة</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-sm font-medium text-gray-500 mb-2">عملاء جدد</h3>
            <p className="text-3xl font-bold">45</p>
            <div className="mt-2 flex items-center text-sm">
              <span className="text-green-600 font-medium">+15.8%</span>
              <span className="text-gray-500 mr-2">مقارنة بالفترة السابقة</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-lg font-semibold mb-4">تقرير المبيعات</h2>
          <SalesReportChart dateRange={dateRange} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">أفضل المنتجات مبيعاً</h2>
            <TopProductsChart />
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">اكتساب العملاء</h2>
            <CustomerAcquisitionChart dateRange={dateRange} />
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
