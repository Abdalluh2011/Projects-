"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Eye, Download } from "lucide-react"
import AdminLayout from "@/components/admin/admin-layout"

// Sample orders data
const orders = [
  {
    id: "ORD-001",
    customer: "أحمد محمد",
    date: "2023-05-15",
    total: 3499,
    status: "completed",
    items: 2,
  },
  {
    id: "ORD-002",
    customer: "سارة أحمد",
    date: "2023-05-14",
    total: 1299,
    status: "processing",
    items: 1,
  },
  {
    id: "ORD-003",
    customer: "محمد علي",
    date: "2023-05-13",
    total: 2199,
    status: "shipped",
    items: 3,
  },
  {
    id: "ORD-004",
    customer: "فاطمة حسن",
    date: "2023-05-12",
    total: 799,
    status: "cancelled",
    items: 1,
  },
  {
    id: "ORD-005",
    customer: "خالد عبدالله",
    date: "2023-05-11",
    total: 4299,
    status: "completed",
    items: 2,
  },
]

export default function OrdersManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredOrders = orders.filter(
    (order) =>
      (order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (statusFilter === "all" || order.status === statusFilter),
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">مكتمل</span>
      case "processing":
        return (
          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">قيد المعالجة</span>
        )
      case "shipped":
        return (
          <span className="px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">تم الشحن</span>
        )
      case "cancelled":
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">ملغي</span>
      default:
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">{status}</span>
    }
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">إدارة الطلبات</h1>
          <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md flex items-center gap-2 hover:bg-gray-200 transition-colors">
            <Download size={18} /> تصدير الطلبات
          </button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                placeholder="البحث عن طلب أو عميل..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="all">جميع الحالات</option>
              <option value="completed">مكتمل</option>
              <option value="processing">قيد المعالجة</option>
              <option value="shipped">تم الشحن</option>
              <option value="cancelled">ملغي</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-right">رقم الطلب</th>
                  <th className="px-4 py-3 text-right">العميل</th>
                  <th className="px-4 py-3 text-right">التاريخ</th>
                  <th className="px-4 py-3 text-right">المجموع</th>
                  <th className="px-4 py-3 text-right">العناصر</th>
                  <th className="px-4 py-3 text-right">الحالة</th>
                  <th className="px-4 py-3 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{order.id}</td>
                    <td className="px-4 py-3">{order.customer}</td>
                    <td className="px-4 py-3 text-gray-600">{new Date(order.date).toLocaleDateString("ar-SA")}</td>
                    <td className="px-4 py-3 font-medium">{order.total} ريال</td>
                    <td className="px-4 py-3 text-gray-600">{order.items}</td>
                    <td className="px-4 py-3">{getStatusBadge(order.status)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center">
                        <Link href={`/admin/orders/${order.id}`} className="p-1 text-blue-600 hover:text-blue-800">
                          <Eye size={18} />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredOrders.length === 0 && (
            <div className="text-center py-8 text-gray-500">لا توجد طلبات مطابقة للبحث</div>
          )}

          <div className="mt-4 flex justify-between items-center text-sm text-gray-600">
            <span>إجمالي الطلبات: {orders.length}</span>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">السابق</button>
              <span className="px-3 py-1 bg-primary text-white rounded">1</span>
              <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">التالي</button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
