"use client"

import { useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { products } from "@/lib/products"
import ProductRating from "@/components/product-rating"
import AddToCartButton from "@/components/add-to-cart-button"
import { Filter, SlidersHorizontal } from "lucide-react"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""

  const [filteredProducts, setFilteredProducts] = useState([...products])
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({
    priceRange: [0, 5000],
    brands: [] as string[],
  })

  // Extract unique brands from products
  const allBrands = Array.from(
    new Set(
      products.map((p) => {
        // Extract brand from product name (e.g., "iPhone", "Samsung", "Xiaomi", "Oppo")
        const brandMatch = p.name.match(/^(\w+)/i)
        return brandMatch ? brandMatch[0] : "Other"
      }),
    ),
  )

  useEffect(() => {
    if (!query) {
      setFilteredProducts([...products])
      return
    }

    const results = products.filter(
      (product) =>
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        Object.values(product.specifications).some((spec) =>
          typeof spec === "string" ? spec.toLowerCase().includes(query.toLowerCase()) : false,
        ),
    )

    setFilteredProducts(results)
  }, [query])

  // Apply filters
  useEffect(() => {
    let results = [...products]

    // Filter by search query
    if (query) {
      results = results.filter(
        (product) =>
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          Object.values(product.specifications).some((spec) =>
            typeof spec === "string" ? spec.toLowerCase().includes(query.toLowerCase()) : false,
          ),
      )
    }

    // Filter by price range
    results = results.filter(
      (product) => product.currentPrice >= filters.priceRange[0] && product.currentPrice <= filters.priceRange[1],
    )

    // Filter by brands
    if (filters.brands.length > 0) {
      results = results.filter((product) => {
        const brandMatch = product.name.match(/^(\w+)/i)
        const brand = brandMatch ? brandMatch[0] : "Other"
        return filters.brands.includes(brand)
      })
    }

    setFilteredProducts(results)
  }, [query, filters])

  const toggleBrandFilter = (brand: string) => {
    setFilters((prev) => {
      if (prev.brands.includes(brand)) {
        return { ...prev, brands: prev.brands.filter((b) => b !== brand) }
      } else {
        return { ...prev, brands: [...prev.brands, brand] }
      }
    })
  }

  return (
    <div className="py-16 bg-[#f8f7fc]">
      <div className="container">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-lalezar text-primary">{query ? `نتائج البحث: "${query}"` : "جميع المنتجات"}</h1>
          <button
            className="flex items-center gap-2 text-gray-600 hover:text-primary"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal size={18} />
            <span className="hidden sm:inline">الفلاتر</span>
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {showFilters && (
            <div className="md:w-1/4 bg-white p-6 rounded-2xl shadow-md h-fit">
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Filter size={18} /> الفلاتر
                </h2>

                <div className="mb-6">
                  <h3 className="font-medium mb-3">نطاق السعر</h3>
                  <div className="flex items-center gap-4">
                    <input
                      type="number"
                      value={filters.priceRange[0]}
                      onChange={(e) =>
                        setFilters((prev) => ({
                          ...prev,
                          priceRange: [Number.parseInt(e.target.value) || 0, prev.priceRange[1]],
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="من"
                    />
                    <span>-</span>
                    <input
                      type="number"
                      value={filters.priceRange[1]}
                      onChange={(e) =>
                        setFilters((prev) => ({
                          ...prev,
                          priceRange: [prev.priceRange[0], Number.parseInt(e.target.value) || 5000],
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="إلى"
                    />
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-3">العلامة التجارية</h3>
                  <div className="space-y-2">
                    {allBrands.map((brand) => (
                      <label key={brand} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={filters.brands.includes(brand)}
                          onChange={() => toggleBrandFilter(brand)}
                          className="rounded text-primary focus:ring-primary"
                        />
                        <span>{brand}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setFilters({ priceRange: [0, 5000], brands: [] })}
                className="text-sm text-primary hover:underline"
              >
                إعادة تعيين الفلاتر
              </button>
            </div>
          )}

          <div className={`${showFilters ? "md:w-3/4" : "w-full"}`}>
            {filteredProducts.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl shadow-md text-center">
                <h2 className="text-xl mb-2">لا توجد نتائج</h2>
                <p className="text-gray-500 mb-4">لم نتمكن من العثور على أي منتجات تطابق معايير البحث الخاصة بك</p>
                <button
                  onClick={() => setFilters({ priceRange: [0, 5000], brands: [] })}
                  className="text-primary hover:underline"
                >
                  إعادة تعيين الفلاتر
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  >
                    <Link href={`/products/${product.slug}`} className="block p-4">
                      <div className="relative h-48 flex items-center justify-center mb-4">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          width={150}
                          height={150}
                          className="object-contain max-h-full"
                        />
                        {product.badge && (
                          <div
                            className={`absolute top-0 left-0 ${
                              product.badge.type === "new"
                                ? "bg-[#dc3545]"
                                : product.badge.type === "bestseller"
                                  ? "bg-[#28a745]"
                                  : "bg-[#ffc107] text-[#333]"
                            } text-white px-3 py-1 rounded-br-lg text-sm`}
                          >
                            {product.badge.text}
                          </div>
                        )}
                      </div>
                      <h3 className="font-medium mb-2 line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
                      <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="sm" />
                      <div className="mt-2 mb-4">
                        <span className="font-bold text-primary">{product.currentPrice} ريال</span>
                        {product.oldPrice && (
                          <span className="text-sm text-gray-500 line-through mr-2">{product.oldPrice} ريال</span>
                        )}
                      </div>
                    </Link>
                    <div className="p-4 pt-0">
                      <AddToCartButton product={product} showQuantity={false} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
