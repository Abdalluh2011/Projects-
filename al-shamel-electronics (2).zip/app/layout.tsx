import type React from "react"
import type { Metadata } from "next"
import { Tajawal, Lalezar } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollToTop from "@/components/scroll-to-top"
import { CartProvider } from "@/lib/cart-context"

const tajawal = Tajawal({
  subsets: ["arabic"],
  weight: ["400", "500", "700"],
  variable: "--font-tajawal",
})

const lalezar = Lalezar({
  subsets: ["arabic"],
  weight: ["400"],
  variable: "--font-lalezar",
})

export const metadata: Metadata = {
  title: "الشامل للألكترونيات | متجر الهواتف الذكية",
  description: "متجر الشامل للإلكترونيات - أفضل مكان لشراء الهواتف الذكية والأجهزة الإلكترونية بأسعار تنافسية",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${tajawal.variable} ${lalezar.variable}`}>
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
          <ScrollToTop />
        </CartProvider>
      </body>
    </html>
  )
}
