import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { getProductBySlug } from "@/lib/products"
import AddToCartButton from "@/components/add-to-cart-button"
import ProductRating from "@/components/product-rating"
import RelatedProducts from "@/components/related-products"
import WishlistButton from "@/components/wishlist-button"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductBySlug(params.slug)

  if (!product) {
    notFound()
  }

  return (
    <div className="py-16 bg-[#f8f7fc]">
      <div className="container max-w-6xl mx-auto">
        <div className="bg-white p-8 rounded-2xl shadow-md mb-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-2/5">
              <div className="sticky top-24">
                <div className="relative mb-4">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={500}
                    height={500}
                    className="rounded-xl border border-gray-200 object-contain mx-auto"
                  />
                  <WishlistButton productId={product.id} className="absolute top-4 left-4" />
                </div>
                <div className="flex justify-center">
                  <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="lg" />
                </div>
              </div>
            </div>

            <div className="lg:w-3/5">
              <h1 className="text-3xl md:text-4xl text-primary mb-4 font-lalezar">{product.name}</h1>

              <div className="flex items-center gap-4 mb-6">
                <span className="text-2xl font-bold text-primary">{product.currentPrice} ريال</span>
                {product.oldPrice && (
                  <span className="text-lg text-gray-500 line-through">{product.oldPrice} ريال</span>
                )}
                {product.oldPrice && (
                  <span className="bg-green-100 text-green-800 text-sm px-2 py-1 rounded-md">
                    خصم {Math.round(((product.oldPrice - product.currentPrice) / product.oldPrice) * 100)}%
                  </span>
                )}
              </div>

              <div className="mb-8">
                <p className="text-gray-700 leading-relaxed">{product.description}</p>
              </div>

              <div className="mb-8">
                <h2 className="text-xl mb-4 pb-2 border-b-2 border-gray-100">المواصفات الفنية</h2>
                <ul className="space-y-3">
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">الشاشة:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.screen}</span>
                  </li>
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">المعالج:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.processor}</span>
                  </li>
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">الكاميرا الخلفية:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.backCamera}</span>
                  </li>
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">الكاميرا الأمامية:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.frontCamera}</span>
                  </li>
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">التخزين:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.storage}</span>
                  </li>
                  {product.specifications.ram && (
                    <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                      <strong className="text-gray-600 w-1/3 flex-shrink-0">الذاكرة العشوائية (RAM):</strong>
                      <span className="text-gray-700 w-2/3 text-left">{product.specifications.ram}</span>
                    </li>
                  )}
                  <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                    <strong className="text-gray-600 w-1/3 flex-shrink-0">البطارية:</strong>
                    <span className="text-gray-700 w-2/3 text-left">{product.specifications.battery}</span>
                  </li>
                  {product.specifications.additionalFeatures && (
                    <li className="flex justify-between py-2 border-b border-dashed border-gray-100 gap-4">
                      <strong className="text-gray-600 w-1/3 flex-shrink-0">ميزات إضافية:</strong>
                      <span className="text-gray-700 w-2/3 text-left">{product.specifications.additionalFeatures}</span>
                    </li>
                  )}
                </ul>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <AddToCartButton product={product} className="flex-1" />
                <Link href="/#newest" className="btn btn-outline">
                  <ArrowRight size={18} /> العودة إلى القائمة
                </Link>
              </div>
            </div>
          </div>
        </div>

        <RelatedProducts currentProductId={product.id} />
      </div>
    </div>
  )
}
