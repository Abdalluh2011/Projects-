import Link from "next/link"
import Image from "next/image"
import { products } from "@/lib/products"

export default function ProductsPage() {
  return (
    <div className="py-16 bg-[var(--light-bg)]">
      <div className="container">
        <div className="section-header">
          <h1 className="section-title">جميع الهواتف المتوفرة</h1>
          <p className="section-subtitle">تصفح مجموعتنا الكاملة من الهواتف الذكية</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:translate-y-[-5px] hover:shadow-lg relative"
            >
              {product.badge && (
                <div
                  className={`absolute top-4 left-4 ${
                    product.badge.type === "new"
                      ? "bg-[var(--danger-color)]"
                      : product.badge.type === "bestseller"
                        ? "bg-[var(--success-color)]"
                        : "bg-[var(--warning-color)] text-[var(--dark-text)]"
                  } text-white px-3 py-1 rounded-full text-sm font-medium z-10`}
                >
                  {product.badge.text}
                </div>
              )}
              <Link href={`/products/${product.slug}`} className="block">
                <div className="p-6 border-b border-[var(--border-color)] h-[250px] flex items-center justify-center">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={200}
                    height={200}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
                <div className="p-6 flex flex-col h-[180px]">
                  <h3 className="text-lg font-semibold mb-2 min-h-[2.6em] line-clamp-2">{product.name}</h3>
                  <div className="text-[var(--warning-color)] mb-3 flex items-center gap-1">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <span key={i}>
                          {i < Math.floor(product.rating)
                            ? "★"
                            : i === Math.floor(product.rating) && product.rating % 1 > 0
                              ? "★"
                              : "☆"}
                        </span>
                      ))}
                    <span className="text-[var(--light-text)] text-sm mr-1">({product.reviewCount})</span>
                  </div>
                  <div className="mt-auto">
                    <span className="text-xl font-bold text-[var(--primary-color)]">{product.currentPrice} ريال</span>
                    {product.oldPrice && (
                      <span className="text-[var(--light-text)] text-base line-through mr-2">
                        {product.oldPrice} ريال
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
