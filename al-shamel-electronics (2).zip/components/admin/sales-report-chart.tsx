"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

// بيانات المبيعات التجريبية حسب الفترة الزمنية
const weekData = [
  { name: "السبت", sales: 1200, orders: 5 },
  { name: "الأحد", sales: 1900, orders: 8 },
  { name: "الإثنين", sales: 1500, orders: 6 },
  { name: "الثلاثاء", sales: 2100, orders: 9 },
  { name: "الأربعاء", sales: 1800, orders: 7 },
  { name: "الخميس", sales: 2400, orders: 10 },
  { name: "الجمعة", sales: 2700, orders: 12 },
]

const monthData = [
  { name: "الأسبوع 1", sales: 9500, orders: 42 },
  { name: "الأسبوع 2", sales: 11200, orders: 48 },
  { name: "الأسبوع 3", sales: 10800, orders: 45 },
  { name: "الأسبوع 4", sales: 12500, orders: 52 },
]

const quarterData = [
  { name: "يناير", sales: 42000, orders: 180 },
  { name: "فبراير", sales: 38000, orders: 165 },
  { name: "مارس", sales: 45000, orders: 195 },
]

const yearData = [
  { name: "الربع الأول", sales: 125000, orders: 540 },
  { name: "الربع الثاني", sales: 145000, orders: 620 },
  { name: "الربع الثالث", sales: 135000, orders: 580 },
  { name: "الربع الرابع", sales: 160000, orders: 680 },
]

interface SalesReportChartProps {
  dateRange: string
}

export default function SalesReportChart({ dateRange }: SalesReportChartProps) {
  // اختيار البيانات المناسبة حسب الفترة الزمنية
  const getChartData = () => {
    switch (dateRange) {
      case "week":
        return weekData
      case "month":
        return monthData
      case "quarter":
        return quarterData
      case "year":
        return yearData
      default:
        return monthData
    }
  }

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={getChartData()} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" orientation="left" stroke="#6e0aef" />
          <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
          <Tooltip
            formatter={(value, name) => [
              name === "sales" ? `${value} ريال` : value,
              name === "sales" ? "المبيعات" : "الطلبات",
            ]}
          />
          <Legend formatter={(value) => (value === "sales" ? "المبيعات" : "الطلبات")} />
          <Bar yAxisId="left" dataKey="sales" name="sales" fill="#6e0aef" radius={[4, 4, 0, 0]} />
          <Bar yAxisId="right" dataKey="orders" name="orders" fill="#82ca9d" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
