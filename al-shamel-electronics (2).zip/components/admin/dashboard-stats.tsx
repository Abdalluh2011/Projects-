export default function DashboardStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-sm font-medium text-gray-500 mb-2">إجمالي المبيعات (اليوم)</h3>
        <p className="text-3xl font-bold">2,499 ريال</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-green-600 font-medium">+15%</span>
          <span className="text-gray-500 mr-2">مقارنة بالأمس</span>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-sm font-medium text-gray-500 mb-2">الطلبات الجديدة</h3>
        <p className="text-3xl font-bold">12</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-green-600 font-medium">+5%</span>
          <span className="text-gray-500 mr-2">مقارنة بالأمس</span>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-sm font-medium text-gray-500 mb-2">عدد الزيارات</h3>
        <p className="text-3xl font-bold">324</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-red-600 font-medium">-2%</span>
          <span className="text-gray-500 mr-2">مقارنة بالأمس</span>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-sm font-medium text-gray-500 mb-2">منتجات منخفضة المخزون</h3>
        <p className="text-3xl font-bold">5</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-amber-600 font-medium">تحتاج للتجديد</span>
        </div>
      </div>
    </div>
  )
}
