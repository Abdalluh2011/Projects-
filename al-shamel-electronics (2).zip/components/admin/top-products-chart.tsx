"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"

// بيانات المنتجات الأكثر مبيعاً
const data = [
  { name: "iPhone 13 Pro Max", value: 35 },
  { name: "Samsung Galaxy A14", value: 25 },
  { name: "Xiaomi Poco X3 Pro", value: 20 },
  { name: "OnePlus Nord N20", value: 15 },
  { name: "أخرى", value: 5 },
]

const COLORS = ["#6e0aef", "#8e44ad", "#3498db", "#1abc9c", "#95a5a6"]

export default function TopProductsChart() {
  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => `${value}%`} />
          <Legend layout="vertical" verticalAlign="middle" align="right" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
