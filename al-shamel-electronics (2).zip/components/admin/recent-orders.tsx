import Link from "next/link"

export default function RecentOrders() {
  const recentOrders = [
    {
      id: "ORD-001",
      customer: "أحمد محمد",
      date: "2023-05-15",
      total: 3499,
      status: "completed",
    },
    {
      id: "ORD-002",
      customer: "سارة أحمد",
      date: "2023-05-14",
      total: 1299,
      status: "processing",
    },
    {
      id: "ORD-003",
      customer: "محمد علي",
      date: "2023-05-13",
      total: 2199,
      status: "shipped",
    },
    {
      id: "ORD-004",
      customer: "فاطمة حسن",
      date: "2023-05-12",
      total: 799,
      status: "cancelled",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">مكتمل</span>
      case "processing":
        return (
          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">قيد المعالجة</span>
        )
      case "shipped":
        return (
          <span className="px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">تم الشحن</span>
        )
      case "cancelled":
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">ملغي</span>
      default:
        return <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">{status}</span>
    }
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="px-4 py-2 text-right">رقم الطلب</th>
            <th className="px-4 py-2 text-right">العميل</th>
            <th className="px-4 py-2 text-right">التاريخ</th>
            <th className="px-4 py-2 text-right">المجموع</th>
            <th className="px-4 py-2 text-right">الحالة</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {recentOrders.map((order) => (
            <tr key={order.id} className="hover:bg-gray-50">
              <td className="px-4 py-2 font-medium">
                <Link href={`/admin/orders/${order.id}`} className="text-primary hover:underline">
                  {order.id}
                </Link>
              </td>
              <td className="px-4 py-2">{order.customer}</td>
              <td className="px-4 py-2 text-gray-600">{new Date(order.date).toLocaleDateString("ar-SA")}</td>
              <td className="px-4 py-2 font-medium">{order.total} ريال</td>
              <td className="px-4 py-2">{getStatusBadge(order.status)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 text-center">
        <Link href="/admin/orders" className="text-primary hover:underline text-sm">
          عرض جميع الطلبات
        </Link>
      </div>
    </div>
  )
}
