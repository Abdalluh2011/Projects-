"use client"

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

// بيانات اكتساب العملاء التجريبية حسب الفترة الزمنية
const weekData = [
  { name: "السبت", customers: 3 },
  { name: "الأحد", customers: 5 },
  { name: "الإثنين", customers: 2 },
  { name: "الثلاثاء", customers: 7 },
  { name: "الأربعاء", customers: 4 },
  { name: "الخميس", customers: 6 },
  { name: "الجمعة", customers: 8 },
]

const monthData = [
  { name: "الأسبوع 1", customers: 12 },
  { name: "الأسبوع 2", customers: 18 },
  { name: "الأسبوع 3", customers: 15 },
  { name: "الأسبوع 4", customers: 22 },
]

const quarterData = [
  { name: "يناير", customers: 45 },
  { name: "فبراير", customers: 38 },
  { name: "مارس", customers: 52 },
]

const yearData = [
  { name: "الربع الأول", customers: 135 },
  { name: "الربع الثاني", customers: 165 },
  { name: "الربع الثالث", customers: 142 },
  { name: "الربع الرابع", customers: 178 },
]

interface CustomerAcquisitionChartProps {
  dateRange: string
}

export default function CustomerAcquisitionChart({ dateRange }: CustomerAcquisitionChartProps) {
  // اختيار البيانات المناسبة حسب الفترة الزمنية
  const getChartData = () => {
    switch (dateRange) {
      case "week":
        return weekData
      case "month":
        return monthData
      case "quarter":
        return quarterData
      case "year":
        return yearData
      default:
        return monthData
    }
  }

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={getChartData()} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip formatter={(value) => [`${value} عميل`, "العملاء الجدد"]} />
          <Area type="monotone" dataKey="customers" stroke="#6e0aef" fill="#6e0aef" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
