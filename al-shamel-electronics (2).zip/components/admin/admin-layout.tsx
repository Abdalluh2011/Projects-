"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Smartphone,
} from "lucide-react"

interface AdminLayoutProps {
  children: React.ReactNode
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const pathname = usePathname()
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const [isInventoryOpen, setIsInventoryOpen] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024)
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false)
      } else {
        setIsSidebarOpen(true)
      }
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated")
    window.location.href = "/admin/login"
  }

  const navItems = [
    {
      name: "لوحة التحكم",
      href: "/admin",
      icon: <LayoutDashboard size={20} />,
    },
    {
      name: "المنتجات",
      href: "/admin/products",
      icon: <Smartphone size={20} />,
    },
    {
      name: "الطلبات",
      href: "/admin/orders",
      icon: <ShoppingCart size={20} />,
    },
    {
      name: "العملاء",
      href: "/admin/customers",
      icon: <Users size={20} />,
    },
    {
      name: "المخزون",
      href: "/admin/inventory",
      icon: <Package size={20} />,
      submenu: [
        {
          name: "إدارة المخزون",
          href: "/admin/inventory",
        },
        {
          name: "طلبات التوريد",
          href: "/admin/inventory/purchase-orders",
        },
      ],
    },
    {
      name: "التقارير",
      href: "/admin/reports",
      icon: <BarChart3 size={20} />,
    },
    {
      name: "الإعدادات",
      href: "/admin/settings",
      icon: <Settings size={20} />,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="text-gray-600 hover:text-primary">
            {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <Link href="/admin" className="flex items-center gap-2">
            <Smartphone className="text-primary" size={24} />
            <span className="font-bold text-lg">لوحة تحكم الشامل</span>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/" className="text-sm text-gray-600 hover:text-primary">
            العودة للموقع
          </Link>
          <button onClick={handleLogout} className="flex items-center gap-1 text-gray-600 hover:text-red-600">
            <LogOut size={18} />
            <span className="hidden md:inline">تسجيل الخروج</span>
          </button>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside
          className={`bg-white shadow-md z-20 ${
            isSidebarOpen
              ? "fixed inset-y-0 right-0 w-64 pt-16 transition-transform duration-300 transform translate-x-0"
              : "fixed inset-y-0 right-0 w-64 pt-16 transition-transform duration-300 transform translate-x-full"
          } lg:relative lg:translate-x-0`}
        >
          <nav className="p-4">
            <ul className="space-y-1">
              {navItems.map((item) => (
                <li key={item.name}>
                  {item.submenu ? (
                    <div>
                      <button
                        onClick={() => setIsInventoryOpen(!isInventoryOpen)}
                        className={`w-full flex items-center justify-between p-3 rounded-md ${
                          pathname.startsWith(item.href)
                            ? "bg-primary/10 text-primary"
                            : "text-gray-700 hover:bg-gray-100"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {item.icon}
                          <span>{item.name}</span>
                        </div>
                        <ChevronDown
                          size={16}
                          className={`transition-transform ${isInventoryOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                      {isInventoryOpen && (
                        <ul className="pr-10 mt-1 space-y-1">
                          {item.submenu.map((subitem) => (
                            <li key={subitem.name}>
                              <Link
                                href={subitem.href}
                                className={`block p-2 rounded-md ${
                                  pathname === subitem.href
                                    ? "bg-primary/10 text-primary"
                                    : "text-gray-700 hover:bg-gray-100"
                                }`}
                                onClick={() => isMobile && setIsSidebarOpen(false)}
                              >
                                {subitem.name}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className={`flex items-center gap-3 p-3 rounded-md ${
                        pathname === item.href ? "bg-primary/10 text-primary" : "text-gray-700 hover:bg-gray-100"
                      }`}
                      onClick={() => isMobile && setIsSidebarOpen(false)}
                    >
                      {item.icon}
                      <span>{item.name}</span>
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-x-auto">
          {/* Overlay for mobile */}
          {isSidebarOpen && isMobile && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-10" onClick={() => setIsSidebarOpen(false)}></div>
          )}
          {children}
        </main>
      </div>
    </div>
  )
}
