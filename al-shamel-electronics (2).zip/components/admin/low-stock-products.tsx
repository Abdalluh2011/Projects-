import Image from "next/image"
import Link from "next/link"
import { AlertTriangle } from "lucide-react"

export default function LowStockProducts() {
  const lowStockProducts = [
    {
      id: "iphone-13-pro-max",
      name: "iPhone 13 Pro Max",
      image: "/images/Apple-iPhone-13-Pro-Max.jpg",
      stock: 3,
      sku: "SKU-IPHONE-13-PM",
    },
    {
      id: "samsung-galaxy-a1",
      name: "Samsung Galaxy A14",
      image: "/images/Samsung-Galaxy-A1.jpg",
      stock: 5,
      sku: "SKU-SAMSUNG-A14",
    },
    {
      id: "xiaomi-poco-x3",
      name: "Xiaomi Poco X3 Pro",
      image: "/images/Xiaomi--Poco-X3.jpg",
      stock: 2,
      sku: "SKU-XIAOMI-POCO-X3",
    },
    {
      id: "oneplus-nord",
      name: "OnePlus Nord N20",
      image: "/images/one-plus.jpg",
      stock: 0,
      sku: "SKU-ONEPLUS-NORD",
    },
  ]

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="px-4 py-2 text-right">المنتج</th>
            <th className="px-4 py-2 text-right">SKU</th>
            <th className="px-4 py-2 text-right">المخزون</th>
            <th className="px-4 py-2 text-center">الإجراءات</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {lowStockProducts.map((product) => (
            <tr key={product.id} className="hover:bg-gray-50">
              <td className="px-4 py-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 relative flex-shrink-0">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      sizes="40px"
                      className="object-contain"
                    />
                  </div>
                  <span className="font-medium">{product.name}</span>
                </div>
              </td>
              <td className="px-4 py-2 text-gray-600">{product.sku}</td>
              <td className="px-4 py-2">
                {product.stock === 0 ? (
                  <span className="flex items-center text-red-600 gap-1">
                    <AlertTriangle size={14} /> نفذ المخزون
                  </span>
                ) : (
                  <span className="flex items-center text-amber-600 gap-1">
                    <AlertTriangle size={14} /> منخفض ({product.stock})
                  </span>
                )}
              </td>
              <td className="px-4 py-2 text-center">
                <Link href={`/admin/inventory?product=${product.id}`} className="text-primary hover:underline text-sm">
                  تحديث المخزون
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 text-center">
        <Link href="/admin/inventory" className="text-primary hover:underline text-sm">
          عرض جميع المنتجات
        </Link>
      </div>
    </div>
  )
}
