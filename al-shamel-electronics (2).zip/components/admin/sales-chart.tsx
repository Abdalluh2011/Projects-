"use client"

import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

// بيانات المبيعات التجريبية
const data = [
  { name: "السبت", sales: 1200 },
  { name: "الأحد", sales: 1900 },
  { name: "الإثنين", sales: 1500 },
  { name: "الثلاثاء", sales: 2100 },
  { name: "الأربعاء", sales: 1800 },
  { name: "الخميس", sales: 2400 },
  { name: "الجمعة", sales: 2700 },
]

export default function SalesChart() {
  return (
    <div className="h-72">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip formatter={(value) => `${value} ريال`} />
          <Line type="monotone" dataKey="sales" stroke="#6e0aef" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
