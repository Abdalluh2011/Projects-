import { Star, StarHalf } from "lucide-react"

interface ProductRatingProps {
  rating: number
  reviewCount?: number
  size?: "sm" | "md" | "lg"
}

export default function ProductRating({ rating, reviewCount, size = "md" }: ProductRatingProps) {
  const fullStars = Math.floor(rating)
  const hasHalfStar = rating % 1 >= 0.5

  const starSize = {
    sm: 14,
    md: 16,
    lg: 20,
  }[size]

  const textSize = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  }[size]

  return (
    <div className="flex items-center gap-1">
      {Array(5)
        .fill(0)
        .map((_, i) => {
          if (i < fullStars) {
            return <Star key={i} size={starSize} className="fill-yellow-400 text-yellow-400" />
          } else if (i === fullStars && hasHalfStar) {
            return <StarHalf key={i} size={starSize} className="fill-yellow-400 text-yellow-400" />
          } else {
            return <Star key={i} size={starSize} className="text-gray-300" />
          }
        })}
      {reviewCount !== undefined && <span className={`text-gray-500 ${textSize} mr-1`}>({reviewCount})</span>}
    </div>
  )
}
