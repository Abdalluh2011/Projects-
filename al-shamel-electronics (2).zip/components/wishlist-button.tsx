"use client"

import { useState, useEffect } from "react"
import { Heart } from "lucide-react"

interface WishlistButtonProps {
  productId: string
  className?: string
}

export default function WishlistButton({ productId, className = "" }: WishlistButtonProps) {
  const [isInWishlist, setIsInWishlist] = useState(false)

  useEffect(() => {
    // Check if product is in wishlist on component mount
    const wishlist = JSON.parse(localStorage.getItem("wishlist") || "[]")
    setIsInWishlist(wishlist.includes(productId))
  }, [productId])

  const toggleWishlist = () => {
    const wishlist = JSON.parse(localStorage.getItem("wishlist") || "[]")

    if (isInWishlist) {
      // Remove from wishlist
      const updatedWishlist = wishlist.filter((id: string) => id !== productId)
      localStorage.setItem("wishlist", JSON.stringify(updatedWishlist))
      setIsInWishlist(false)
    } else {
      // Add to wishlist
      const updatedWishlist = [...wishlist, productId]
      localStorage.setItem("wishlist", JSON.stringify(updatedWishlist))
      setIsInWishlist(true)
    }
  }

  return (
    <button
      onClick={(e) => {
        e.preventDefault()
        toggleWishlist()
      }}
      className={`w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center transition-colors ${className}`}
      aria-label={isInWishlist ? "إزالة من المفضلة" : "إضافة إلى المفضلة"}
    >
      <Heart size={20} className={isInWishlist ? "fill-red-500 text-red-500" : "text-gray-400 hover:text-red-500"} />
    </button>
  )
}
