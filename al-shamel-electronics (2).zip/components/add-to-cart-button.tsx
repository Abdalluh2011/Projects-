"use client"

import { useState } from "react"
import { ShoppingCart, Check, Minus, Plus } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import type { Product } from "@/lib/products"

interface AddToCartButtonProps {
  product: Product
  className?: string
  showQuantity?: boolean
}

export default function AddToCartButton({ product, className = "", showQuantity = true }: AddToCartButtonProps) {
  const [quantity, setQuantity] = useState(1)
  const [isAdded, setIsAdded] = useState(false)
  const { addItem } = useCart()

  const handleAddToCart = () => {
    addItem(product, quantity)
    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 2000)
  }

  const incrementQuantity = () => {
    setQuantity((prev) => prev + 1)
  }

  const decrementQuantity = () => {
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1))
  }

  return (
    <div className={`flex flex-col ${className}`}>
      {showQuantity && (
        <div className="flex items-center justify-center mb-3 bg-gray-50 rounded-lg p-1">
          <button
            onClick={decrementQuantity}
            className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-primary"
            aria-label="تقليل الكمية"
          >
            <Minus size={16} />
          </button>
          <span className="mx-3 w-8 text-center font-medium">{quantity}</span>
          <button
            onClick={incrementQuantity}
            className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-primary"
            aria-label="زيادة الكمية"
          >
            <Plus size={16} />
          </button>
        </div>
      )}
      <button
        onClick={handleAddToCart}
        disabled={isAdded}
        className={`btn ${
          isAdded ? "bg-green-600 hover:bg-green-700" : "btn-primary"
        } flex items-center justify-center gap-2`}
      >
        {isAdded ? (
          <>
            <Check size={18} /> تمت الإضافة إلى السلة
          </>
        ) : (
          <>
            <ShoppingCart size={18} /> إضافة إلى السلة
          </>
        )}
      </button>
    </div>
  )
}
