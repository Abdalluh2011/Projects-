import { Truck, Shield, Headphones, Tag } from "lucide-react"

export default function FeaturesSection() {
  const features = [
    {
      icon: <Truck className="text-primary text-3xl" />,
      title: "سرعة بالتوصيل",
      description: "طلبك يصل خلال 2-5 أيام عمل",
    },
    {
      icon: <Shield className="text-primary text-3xl" />,
      title: "ضمان الجودة",
      description: "منتجات أصلية 100% مع ضمان",
    },
    {
      icon: <Headphones className="text-primary text-3xl" />,
      title: "دعم فني",
      description: "مساعدة متوفرة على مدار الساعة",
    },
    {
      icon: <Tag className="text-primary text-3xl" />,
      title: "أسعار تنافسية",
      description: "أفضل العروض والخصومات الدورية",
    },
  ]

  return (
    <section id="features" className="py-16 md:py-20">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">لماذا نحن أفضل خيار؟</h2>
          <p className="section-subtitle">نقدم لكم أفضل الخدمات لتجربة تسوق مميزة</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-2xl p-8 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-transparent animate-fadeInUp"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-16 h-16 bg-[rgba(110,10,239,0.1)] rounded-full flex items-center justify-center mx-auto mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-[#777]">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
