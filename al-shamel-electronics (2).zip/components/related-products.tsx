import Link from "next/link"
import Image from "next/image"
import { products } from "@/lib/products"
import ProductRating from "./product-rating"
import AddToCartButton from "./add-to-cart-button"

interface RelatedProductsProps {
  currentProductId: string
}

export default function RelatedProducts({ currentProductId }: RelatedProductsProps) {
  // Get the current product to find its category
  const currentProduct = products.find((p) => p.id === currentProductId)

  // Filter products to get related ones (excluding current product)
  const relatedProducts = products.filter((p) => p.id !== currentProductId).slice(0, 4) // Limit to 4 related products

  if (relatedProducts.length === 0) {
    return null
  }

  return (
    <div className="bg-white p-8 rounded-2xl shadow-md">
      <h2 className="text-2xl font-lalezar text-primary mb-6">منتجات ذات صلة</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {relatedProducts.map((product) => (
          <div key={product.id} className="border border-gray-200 rounded-lg overflow-hidden">
            <Link href={`/products/${product.slug}`} className="block p-4">
              <div className="h-40 flex items-center justify-center mb-4">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={120}
                  height={120}
                  className="object-contain max-h-full"
                />
              </div>
              <h3 className="font-medium mb-2 line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
              <ProductRating rating={product.rating} size="sm" />
              <div className="mt-2 mb-4">
                <span className="font-bold text-primary">{product.currentPrice} ريال</span>
                {product.oldPrice && (
                  <span className="text-sm text-gray-500 line-through mr-2">{product.oldPrice} ريال</span>
                )}
              </div>
            </Link>
            <div className="p-4 pt-0">
              <AddToCartButton product={product} showQuantity={false} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
