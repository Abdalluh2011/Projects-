import Image from "next/image"
import Link from "next/link"
import { Info, Smartphone } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="py-16 md:py-20 bg-[#f8f7fc]">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-8 md:gap-12">
        <div className="text-center md:text-right max-w-xl">
          <span className="inline-block bg-[rgba(110,10,239,0.1)] text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            تسوق بأمان. تسوق بسرعة
          </span>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight">
            اكتشف أحدث الهواتف بأفضل الأسعار
          </h1>
          <p className="text-[#777] text-base md:text-lg mb-8 max-w-[90%] md:max-w-full mx-auto md:mx-0">
            متجر الشامل هو وجهتك الأولى لشراء كل ما هو متعلق بالهواتف الذكية.
            <span className="highlight"> جودة وسرعة وأمان</span> أثناء تسوقك.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <Link href="#features" className="btn btn-primary">
              <Info size={18} /> إعرف أكثر
            </Link>
            <Link href="#newest" className="btn btn-outline">
              <Smartphone size={18} /> تصفح المنتجات
            </Link>
          </div>
        </div>
        <div className="max-w-md animate-float">
          <Image
            src="/images/smartphone.png"
            alt="هاتف ذكي"
            width={450}
            height={450}
            priority
            className="max-h-[400px] object-contain"
          />
        </div>
      </div>
    </section>
  )
}
