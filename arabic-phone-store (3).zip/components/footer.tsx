import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail, Clock } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-white pt-12 pb-6 border-t border-[var(--border-color)]">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* معلومات المتجر */}
          <div>
            <div className="mb-4">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5859572394321104542_121.jpg-jX978AW8NauuUYss8GtrSB2cC4GdVP.jpeg"
                alt="الشامل للإلكترونيات"
                width={150}
                height={60}
                className="h-16 w-auto"
              />
            </div>
            <p className="text-[var(--light-text)] mb-4">
              وجهتك الأولى لشراء أحدث الهواتف الذكية والإلكترونيات والمكتبة بأفضل الأسعار وبضمان الجودة.
            </p>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-[var(--light-text)]">
                <MapPin size={18} className="text-primary flex-shrink-0" />
                <span>تعز - مقبنة حمير الوادي - سوق الفكيكة</span>
              </li>
              <li className="flex items-center gap-2 text-[var(--light-text)]">
                <Phone size={18} className="text-primary flex-shrink-0" />
                <a href="tel:+967713465838" className="hover:text-primary">
                  +967 713465838
                </a>
              </li>
              <li className="flex items-center gap-2 text-[var(--light-text)]">
                <Mail size={18} className="text-primary flex-shrink-0" />
                <a href="mailto:mhammd2019mm@gmail.com" className="hover:text-primary">
                  mhammd2019mm@gmail.com
                </a>
              </li>
            </ul>
          </div>

          {/* روابط سريعة */}
          <div>
            <h3 className="text-lg font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-[var(--light-text)] hover:text-primary">
                  الصفحة الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-[var(--light-text)] hover:text-primary">
                  جميع المنتجات
                </Link>
              </li>
              <li>
                <Link href="/categories" className="text-[var(--light-text)] hover:text-primary">
                  فئات الهواتف
                </Link>
              </li>
              <li>
                <Link href="/search" className="text-[var(--light-text)] hover:text-primary">
                  البحث
                </Link>
              </li>
              <li>
                <Link href="/cart" className="text-[var(--light-text)] hover:text-primary">
                  سلة التسوق
                </Link>
              </li>
            </ul>
          </div>

          {/* معلومات المتجر */}
          <div>
            <h3 className="text-lg font-bold mb-4">خدمة العملاء</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-[var(--light-text)] hover:text-primary">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[var(--light-text)] hover:text-primary">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[var(--light-text)] hover:text-primary">
                  سياسة الإرجاع والاستبدال
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[var(--light-text)] hover:text-primary">
                  الأسئلة الشائعة
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[var(--light-text)] hover:text-primary">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>

          {/* ساعات العمل والتواصل الاجتماعي */}
          <div>
            <h3 className="text-lg font-bold mb-4">ساعات العمل</h3>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center gap-2 text-[var(--light-text)]">
                <Clock size={18} className="text-primary flex-shrink-0" />
                <span>على مدار الأسبوع: 8:00 صباحاً - 10:00 مساءً</span>
              </li>
              <li className="flex items-center gap-2 text-[var(--light-text)]">
                <Clock size={18} className="text-primary flex-shrink-0" />
                <span>التجارة الإلكترونية: متاح 24/7</span>
              </li>
            </ul>

            <h3 className="text-lg font-bold mb-4">تابعنا على</h3>
            <div className="flex gap-4">
              <a
                href="https://www.facebook.com/share/1LAXpnprQh/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#f8f7fc] flex items-center justify-center text-[var(--light-text)] hover:text-primary hover:bg-[#f0eefb] transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#f8f7fc] flex items-center justify-center text-[var(--light-text)] hover:text-primary hover:bg-[#f0eefb] transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#f8f7fc] flex items-center justify-center text-[var(--light-text)] hover:text-primary hover:bg-[#f0eefb] transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-[var(--border-color)] pt-6 text-center">
          <p className="text-[var(--light-text)]">© 2025 متجر الشامل للإلكترونيات والمكتبة. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  )
}
