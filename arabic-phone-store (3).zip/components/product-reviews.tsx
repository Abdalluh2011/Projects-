"use client"

import type React from "react"

import { useState } from "react"
import { Star, ThumbsUp, MessageCircle } from "lucide-react"
import { useReviews } from "@/lib/reviews-context"

interface ProductReviewsProps {
  productId: string
}

export default function ProductReviews({ productId }: ProductReviewsProps) {
  const { getProductReviews, getAverageRating, addReview, markHelpful } = useReviews()
  const [showReviewForm, setShowReviewForm] = useState(false)
  const [newReview, setNewReview] = useState({
    userName: "",
    rating: 5,
    comment: "",
  })

  const productReviews = getProductReviews(productId)
  const averageRating = getAverageRating(productId)

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    if (newReview.userName.trim() && newReview.comment.trim()) {
      addReview({
        productId,
        userName: newReview.userName,
        rating: newReview.rating,
        comment: newReview.comment,
      })
      setNewReview({ userName: "", rating: 5, comment: "" })
      setShowReviewForm(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <MessageCircle className="text-primary" size={20} />
          التقييمات والمراجعات
        </h3>
        <button onClick={() => setShowReviewForm(!showReviewForm)} className="btn btn-outline text-sm">
          اكتب مراجعة
        </button>
      </div>

      {/* ملخص التقييمات */}
      {productReviews.length > 0 && (
        <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{averageRating}</div>
              <div className="flex items-center justify-center mb-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={16}
                    className={`${star <= averageRating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                  />
                ))}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">{productReviews.length} مراجعة</div>
            </div>
            <div className="flex-1">
              {[5, 4, 3, 2, 1].map((rating) => {
                const count = productReviews.filter((r) => r.rating === rating).length
                const percentage = productReviews.length > 0 ? (count / productReviews.length) * 100 : 0
                return (
                  <div key={rating} className="flex items-center gap-2 mb-1">
                    <span className="text-sm w-8">{rating}</span>
                    <Star size={12} className="text-yellow-400 fill-yellow-400" />
                    <div className="flex-1 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                      <div
                        className="bg-yellow-400 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600 dark:text-gray-400 w-8">{count}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* نموذج إضافة مراجعة */}
      {showReviewForm && (
        <div className="mb-6 p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
          <h4 className="font-bold mb-4 text-gray-900 dark:text-white">اكتب مراجعتك</h4>
          <form onSubmit={handleSubmitReview} className="space-y-4">
            <div>
              <label htmlFor="userName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                الاسم
              </label>
              <input
                type="text"
                id="userName"
                value={newReview.userName}
                onChange={(e) => setNewReview({ ...newReview, userName: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">التقييم</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setNewReview({ ...newReview, rating: star })}
                    className="p-1"
                  >
                    <Star
                      size={24}
                      className={`${
                        star <= newReview.rating
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-gray-300 hover:text-yellow-400"
                      } transition-colors`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="comment" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                المراجعة
              </label>
              <textarea
                id="comment"
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="شاركنا رأيك في المنتج..."
                required
              />
            </div>
            <div className="flex gap-3">
              <button type="submit" className="btn btn-primary">
                نشر المراجعة
              </button>
              <button type="button" onClick={() => setShowReviewForm(false)} className="btn btn-outline">
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* قائمة المراجعات */}
      <div className="space-y-4">
        {productReviews.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            لا توجد مراجعات بعد. كن أول من يكتب مراجعة!
          </div>
        ) : (
          productReviews.map((review) => (
            <div key={review.id} className="border-b border-gray-200 dark:border-gray-600 pb-4 last:border-b-0">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h5 className="font-medium text-gray-900 dark:text-white">{review.userName}</h5>
                  <div className="flex items-center gap-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          size={14}
                          className={`${star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{formatDate(review.date)}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-3">{review.comment}</p>
              <button
                onClick={() => markHelpful(review.id)}
                className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400 hover:text-primary transition-colors"
              >
                <ThumbsUp size={14} />
                مفيد ({review.helpful})
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
