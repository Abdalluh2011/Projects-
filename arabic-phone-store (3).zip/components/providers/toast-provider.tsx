"use client"

import { ToastContainer } from "@/components/ui/toast"
import { useToast } from "@/lib/hooks/use-toast"
import { createContext, useContext, type ReactNode } from "react"

const ToastContext = createContext<ReturnType<typeof useToast> | undefined>(undefined)

export function ToastProvider({ children }: { children: ReactNode }) {
  const toast = useToast()

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <ToastContainer toasts={toast.toasts} onRemove={toast.removeToast} />
    </ToastContext.Provider>
  )
}

export function useToastContext() {
  const context = useContext(ToastContext)
  if (context === undefined) {
    throw new Error("useToastContext must be used within a ToastProvider")
  }
  return context
}
