import { Star } from "lucide-react"

interface ProductRatingProps {
  rating: number
  reviewCount: number
  size?: "sm" | "md" | "lg"
}

export default function ProductRating({ rating, reviewCount, size = "md" }: ProductRatingProps) {
  const sizeClasses = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
  }

  const starSize = {
    sm: 14,
    md: 16,
    lg: 18,
  }

  return (
    <div className={`flex items-center gap-2 ${sizeClasses[size]}`}>
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={starSize[size]}
            className={`${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
          />
        ))}
      </div>
      <span className="text-gray-600">({reviewCount})</span>
    </div>
  )
}
