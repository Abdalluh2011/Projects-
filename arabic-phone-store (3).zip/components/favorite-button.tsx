"use client"

import type React from "react"

import { Heart } from "lucide-react"
import { useFavorites } from "@/lib/favorites-context"
import type { Product } from "@/lib/products"

interface FavoriteButtonProps {
  product: Product
  size?: "sm" | "md" | "lg"
}

export default function FavoriteButton({ product, size = "md" }: FavoriteButtonProps) {
  const { addToFavorites, removeFromFavorites, isFavorite } = useFavorites()
  const isProductFavorite = isFavorite(product.id)

  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  }

  const iconSize = {
    sm: 16,
    md: 20,
    lg: 24,
  }

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (isProductFavorite) {
      removeFromFavorites(product.id)
    } else {
      addToFavorites({
        id: product.id,
        name: product.name,
        price: product.currentPrice,
        image: product.image,
        slug: product.slug,
      })
    }
  }

  return (
    <button
      onClick={handleToggleFavorite}
      className={`${sizeClasses[size]} flex items-center justify-center rounded-full bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-600 group`}
      aria-label={isProductFavorite ? "إزالة من المفضلة" : "إضافة للمفضلة"}
    >
      <Heart
        size={iconSize[size]}
        className={`transition-colors duration-300 ${
          isProductFavorite ? "text-red-500 fill-red-500" : "text-gray-400 dark:text-gray-500 group-hover:text-red-500"
        }`}
      />
    </button>
  )
}
