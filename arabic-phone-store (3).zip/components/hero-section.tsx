import Link from "next/link"
import Image from "next/image"
import { Info, Smartphone } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="py-16 md:py-20 bg-[#f8f7fc] dark:bg-gray-800">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-8 md:gap-12">
        <div className="text-center md:text-right max-w-xl order-2 md:order-1">
          <span className="inline-block bg-[rgba(110,10,239,0.1)] dark:bg-[rgba(110,10,239,0.2)] text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            تسوق بأمان. تسوق بسرعة
          </span>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight text-gray-900 dark:text-white">
            اكتشف أحدث الهواتف بأفضل الأسعار
          </h1>
          <p className="text-gray-600 dark:text-gray-300 text-base md:text-lg mb-8 max-w-[90%] md:max-w-full mx-auto md:mx-0">
            متجر الشامل هو وجهتك الأولى لشراء كل ما هو متعلق بالهواتف الذكية.
            <span className="highlight"> جودة وسرعة وأمان</span> أثناء تسوقك.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <Link href="#newest" className="btn btn-primary">
              <Smartphone size={18} /> تصفح المنتجات
            </Link>
            <Link href="#features" className="btn btn-outline">
              <Info size={18} /> إعرف أكثر
            </Link>
          </div>
        </div>
        <div className="max-w-md animate-float order-1 md:order-2">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5859572394321104542_121.jpg-jX978AW8NauuUYss8GtrSB2cC4GdVP.jpeg"
            alt="الشامل للإلكترونيات"
            width={400}
            height={300}
            priority
            className="max-h-[300px] w-auto object-contain"
          />
        </div>
      </div>
    </section>
  )
}
