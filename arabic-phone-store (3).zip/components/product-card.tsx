import Link from "next/link"
import LazyImage from "@/components/lazy-image"
import ProductRating from "@/components/product-rating"
import FavoriteButton from "@/components/favorite-button"
import CompareButton from "@/components/compare-button"
import type { Product } from "@/lib/products"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-lg relative animate-fadeInUp border border-gray-200 dark:border-gray-700">
      {product.badge && (
        <div
          className={`absolute top-4 left-4 ${
            product.badge.type === "new"
              ? "bg-[#dc3545]"
              : product.badge.type === "bestseller"
                ? "bg-[#28a745]"
                : "bg-[#ffc107] text-[#333]"
          } text-white px-3 py-1 rounded-full text-sm font-medium z-10`}
        >
          {product.badge.text}
        </div>
      )}

      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
        <FavoriteButton product={product} size="sm" />
        <CompareButton product={product} size="sm" />
      </div>

      <Link href={`/products/${product.slug}`} className="block">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700 h-[250px] flex items-center justify-center">
          <LazyImage
            src={product.image || "/placeholder.svg?height=200&width=200"}
            alt={product.name}
            width={200}
            height={200}
            className="max-h-full max-w-full object-contain"
          />
        </div>
        <div className="p-6 flex flex-col h-[180px]">
          <h3 className="text-lg font-semibold mb-2 min-h-[2.6em] line-clamp-2 text-gray-900 dark:text-white">
            {product.name}
          </h3>
          <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="sm" />
          <div className="mt-auto">
            <span className="text-xl font-bold text-primary">{product.currentPrice} ريال</span>
            {product.oldPrice && (
              <span className="text-gray-500 dark:text-gray-400 text-base line-through mr-2">
                {product.oldPrice} ريال
              </span>
            )}
          </div>
        </div>
      </Link>
    </div>
  )
}
