import Link from "next/link"
import Image from "next/image"
import { Smartphone } from "lucide-react"
import { products } from "@/lib/products"
import ProductRating from "@/components/product-rating"

export default function ProductsSection() {
  return (
    <section id="newest" className="py-16 md:py-20 bg-[#f8f7fc] dark:bg-gray-800">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">الهواتف المضافة حديثاً</h2>
          <p className="section-subtitle">أحدث الموديلات بأفضل الأسعار</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {products.slice(0, 6).map((product, index) => (
            <div
              key={product.id}
              className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-lg relative animate-fadeInUp border border-gray-200 dark:border-gray-700"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {product.badge && (
                <div
                  className={`absolute top-4 left-4 ${
                    product.badge.type === "new"
                      ? "bg-[#dc3545]"
                      : product.badge.type === "bestseller"
                        ? "bg-[#28a745]"
                        : "bg-[#ffc107] text-[#333]"
                  } text-white px-3 py-1 rounded-full text-sm font-medium z-10`}
                >
                  {product.badge.text}
                </div>
              )}
              <Link href={`/products/${product.slug}`} className="block">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700 h-[250px] flex items-center justify-center">
                  <Image
                    src={product.image || "/placeholder.svg?height=200&width=200"}
                    alt={product.name}
                    width={200}
                    height={200}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
                <div className="p-6 flex flex-col h-[180px]">
                  <h3 className="text-lg font-semibold mb-2 min-h-[2.6em] line-clamp-2 text-gray-900 dark:text-white">
                    {product.name}
                  </h3>
                  <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="sm" />
                  <div className="mt-auto">
                    <span className="text-xl font-bold text-primary">{product.currentPrice} ريال</span>
                    {product.oldPrice && (
                      <span className="text-gray-500 dark:text-gray-400 text-base line-through mr-2">
                        {product.oldPrice} ريال
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/products" className="btn btn-primary">
            <Smartphone size={18} /> تصفح جميع الهواتف
          </Link>
        </div>
      </div>
    </section>
  )
}
