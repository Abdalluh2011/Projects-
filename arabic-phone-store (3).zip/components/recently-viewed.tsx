"use client"

import Link from "next/link"
import Image from "next/image"
import { Clock, X } from "lucide-react"
import { useRecentlyViewed } from "@/lib/recently-viewed-context"

export default function RecentlyViewed() {
  const { recentlyViewed, clearRecentlyViewed } = useRecentlyViewed()

  if (recentlyViewed.length === 0) return null

  return (
    <section className="py-16 bg-white dark:bg-gray-900">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Clock className="text-primary" size={24} />
            المنتجات المشاهدة مؤخراً
          </h2>
          <button
            onClick={clearRecentlyViewed}
            className="text-sm text-gray-500 dark:text-gray-400 hover:text-red-500 flex items-center gap-1"
          >
            <X size={16} />
            مسح الكل
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {recentlyViewed.map((item) => (
            <Link
              key={item.id}
              href={`/products/${item.slug}`}
              className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 hover:shadow-md transition-shadow border border-gray-200 dark:border-gray-700"
            >
              <div className="aspect-square mb-3 relative">
                <Image
                  src={item.image || "/placeholder.svg?height=120&width=120"}
                  alt={item.name}
                  fill
                  sizes="120px"
                  className="object-contain"
                />
              </div>
              <h3 className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2 mb-2">{item.name}</h3>
              <p className="text-primary font-bold text-sm">{item.price} ريال</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
