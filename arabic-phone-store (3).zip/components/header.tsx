"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Home, Star, Smartphone, ShoppingCart, User, Heart, Settings, Scale, Tag } from "lucide-react"
import SearchBar from "./search-bar"
import ThemeToggle from "./theme-toggle"
import NotificationsDropdown from "./notifications-dropdown"
import { useCart } from "@/lib/cart-context"
import { useFavorites } from "@/lib/favorites-context"
import { useCompare } from "@/lib/compare-context"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const menuRef = useRef<HTMLUListElement>(null)
  const togglerRef = useRef<HTMLButtonElement>(null)
  const { items } = useCart()
  const { favorites } = useFavorites()
  const { compareList } = useCompare()

  const cartItemsCount = items.reduce((total, item) => total + item.quantity, 0)
  const favoritesCount = favorites.length
  const compareCount = compareList.length

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        togglerRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        !togglerRef.current.contains(event.target as Node) &&
        isMenuOpen
      ) {
        setIsMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isMenuOpen])

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
          <Link href="/" className="flex items-center text-xl md:text-2xl font-semibold gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5859572394321104542_121.jpg-jX978AW8NauuUYss8GtrSB2cC4GdVP.jpeg"
              alt="الشامل للإلكترونيات"
              width={120}
              height={50}
              className="h-12 w-auto"
            />
          </Link>

          <div className="hidden md:block flex-1 mx-8">
            <SearchBar />
          </div>

          <div className="flex items-center gap-4">
            <ThemeToggle />
            <NotificationsDropdown />
            <Link href="/favorites" className="relative">
              <Heart className="text-gray-600 dark:text-gray-300 hover:text-primary transition-colors" />
              {favoritesCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {favoritesCount}
                </span>
              )}
            </Link>
            <Link href="/compare" className="relative">
              <Scale className="text-gray-600 dark:text-gray-300 hover:text-primary transition-colors" />
              {compareCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {compareCount}
                </span>
              )}
            </Link>
            <Link href="/cart" className="relative">
              <ShoppingCart className="text-gray-600 dark:text-gray-300 hover:text-primary transition-colors" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {cartItemsCount}
                </span>
              )}
            </Link>
            <Link href="/admin" className="hidden md:block">
              <Settings className="text-gray-600 dark:text-gray-300 hover:text-primary transition-colors" />
            </Link>
            <Link href="/login" className="text-gray-600 dark:text-gray-300 hover:text-primary transition-colors">
              <User />
            </Link>
            <button
              ref={togglerRef}
              className="md:hidden text-2xl p-2 text-gray-600 dark:text-gray-300"
              onClick={toggleMenu}
              aria-label={isMenuOpen ? "إغلاق القائمة" : "فتح القائمة"}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        <div className="md:hidden py-2">
          <SearchBar />
        </div>

        <nav className="flex">
          <ul
            ref={menuRef}
            className={`md:flex md:items-center md:gap-6 ${
              isMenuOpen
                ? "fixed top-[140px] right-0 w-4/5 max-w-[320px] h-[calc(100vh-140px)] bg-white dark:bg-gray-900 flex-col items-stretch p-6 gap-0 shadow-lg transition-all duration-350 z-50 overflow-y-auto border-l border-gray-200 dark:border-gray-700"
                : "fixed top-[140px] right-[-100%] md:static md:h-auto md:w-auto md:shadow-none md:p-0 md:overflow-visible"
            }`}
          >
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Home size={18} /> الصفحة الرئيسية
              </Link>
            </li>
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/#features"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Star size={18} /> ميزاتنا
              </Link>
            </li>
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/#newest"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Smartphone size={18} /> أحدث الهواتف
              </Link>
            </li>
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/offers"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Tag size={18} /> العروض الخاصة
              </Link>
            </li>
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/favorites"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Heart size={18} /> المفضلة
                {favoritesCount > 0 && (
                  <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">{favoritesCount}</span>
                )}
              </Link>
            </li>
            <li className="md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/compare"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Scale size={18} /> المقارنة
                {compareCount > 0 && (
                  <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">{compareCount}</span>
                )}
              </Link>
            </li>
            <li className="md:hidden md:mb-0 md:border-b-0 border-b border-gray-200 dark:border-gray-700 last:border-b-0 last:mb-0">
              <Link
                href="/admin"
                className="flex items-center text-primary font-medium hover:opacity-80 transition-colors py-3 md:py-2 gap-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Settings size={18} /> لوحة التحكم
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  )
}
