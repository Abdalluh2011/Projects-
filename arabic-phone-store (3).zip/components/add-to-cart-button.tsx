"use client"

import { useState } from "react"
import { ShoppingCart, Check } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import type { Product } from "@/lib/products"

interface AddToCartButtonProps {
  product: Product
}

export default function AddToCartButton({ product }: AddToCartButtonProps) {
  const { addItem } = useCart()
  const [quantity, setQuantity] = useState(1)
  const [isAdded, setIsAdded] = useState(false)

  const handleAddToCart = () => {
    addItem(
      {
        id: product.id,
        name: product.name,
        price: product.currentPrice,
        image: product.image || "/placeholder.svg?height=96&width=96",
      },
      quantity,
    )

    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 2000)
  }

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity > 0) {
      setQuantity(newQuantity)
    }
  }

  return (
    <div className="flex flex-col sm:flex-row gap-4">
      <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
        <button
          onClick={() => handleQuantityChange(quantity - 1)}
          className="w-10 h-10 flex items-center justify-center bg-gray-100 hover:bg-gray-200 transition-colors"
          aria-label="تقليل الكمية"
        >
          -
        </button>
        <span className="w-12 text-center">{quantity}</span>
        <button
          onClick={() => handleQuantityChange(quantity + 1)}
          className="w-10 h-10 flex items-center justify-center bg-gray-100 hover:bg-gray-200 transition-colors"
          aria-label="زيادة الكمية"
        >
          +
        </button>
      </div>

      <button
        onClick={handleAddToCart}
        className={`flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-lg font-medium transition-all ${
          isAdded ? "bg-green-600 text-white" : "bg-primary text-white hover:bg-primary-hover"
        }`}
      >
        {isAdded ? (
          <>
            <Check size={20} /> تمت الإضافة إلى السلة
          </>
        ) : (
          <>
            <ShoppingCart size={20} /> إضافة إلى السلة
          </>
        )}
      </button>
    </div>
  )
}
