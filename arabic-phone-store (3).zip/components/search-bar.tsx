"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Search, X, Filter } from "lucide-react"
import { products } from "@/lib/products"

export default function SearchBar() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [searchResults, setSearchResults] = useState<typeof products>([])
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({
    category: "",
    brand: "",
    minPrice: "",
    maxPrice: "",
  })
  const searchRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
        setShowFilters(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  useEffect(() => {
    if (searchTerm.length > 1) {
      let results = products.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          Object.values(product.specifications).some((spec) =>
            typeof spec === "string" ? spec.toLowerCase().includes(searchTerm.toLowerCase()) : false,
          ),
      )

      // تطبيق الفلاتر
      if (filters.category) {
        results = results.filter((product) => product.category === filters.category)
      }
      if (filters.brand) {
        results = results.filter((product) => product.brand === filters.brand)
      }
      if (filters.minPrice) {
        results = results.filter((product) => product.currentPrice >= Number.parseInt(filters.minPrice))
      }
      if (filters.maxPrice) {
        results = results.filter((product) => product.currentPrice <= Number.parseInt(filters.maxPrice))
      }

      setSearchResults(results)
      setIsOpen(true)
    } else {
      setSearchResults([])
      setIsOpen(false)
    }
  }, [searchTerm, filters])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      const queryParams = new URLSearchParams({
        q: searchTerm,
        ...(filters.category && { category: filters.category }),
        ...(filters.brand && { brand: filters.brand }),
        ...(filters.minPrice && { minPrice: filters.minPrice }),
        ...(filters.maxPrice && { maxPrice: filters.maxPrice }),
      })
      router.push(`/search?${queryParams.toString()}`)
      setIsOpen(false)
    }
  }

  const handleFilterChange = (filterName: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [filterName]: value,
    }))
  }

  const clearFilters = () => {
    setFilters({
      category: "",
      brand: "",
      minPrice: "",
      maxPrice: "",
    })
  }

  const uniqueCategories = Array.from(new Set(products.map((p) => p.category)))
  const uniqueBrands = Array.from(new Set(products.map((p) => p.brand)))

  return (
    <div className="relative w-full max-w-md mx-auto md:mx-0" ref={searchRef}>
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="ابحث عن هاتف..."
          className="w-full px-4 py-2 pr-10 pl-10 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
        />
        <button
          type="submit"
          className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 hover:text-primary"
        >
          <Search size={18} />
        </button>
        <button
          type="button"
          onClick={() => setShowFilters(!showFilters)}
          className="absolute right-10 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 hover:text-primary"
        >
          <Filter size={18} />
        </button>
        {searchTerm && (
          <button
            type="button"
            onClick={() => setSearchTerm("")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X size={18} />
          </button>
        )}
      </form>

      {/* فلاتر البحث */}
      {showFilters && (
        <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg p-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">الفئة</label>
              <select
                value={filters.category}
                onChange={(e) => handleFilterChange("category", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="">جميع الفئات</option>
                {uniqueCategories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                العلامة التجارية
              </label>
              <select
                value={filters.brand}
                onChange={(e) => handleFilterChange("brand", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="">جميع العلامات</option>
                {uniqueBrands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">السعر من</label>
              <input
                type="number"
                value={filters.minPrice}
                onChange={(e) => handleFilterChange("minPrice", e.target.value)}
                placeholder="0"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">السعر إلى</label>
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => handleFilterChange("maxPrice", e.target.value)}
                placeholder="5000"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
          </div>
          <div className="flex justify-between mt-4">
            <button
              type="button"
              onClick={clearFilters}
              className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
            >
              مسح الفلاتر
            </button>
            <button
              type="button"
              onClick={() => setShowFilters(false)}
              className="text-sm text-primary hover:underline"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* نتائج البحث */}
      {isOpen && searchResults.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg max-h-96 overflow-y-auto">
          <div className="p-2">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
              نتائج البحث ({searchResults.length})
            </h3>
            <ul className="space-y-2">
              {searchResults.slice(0, 5).map((product) => (
                <li key={product.id}>
                  <Link
                    href={`/products/${product.slug}`}
                    className="flex items-center p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-md"
                    onClick={() => setIsOpen(false)}
                  >
                    <div className="w-12 h-12 relative flex-shrink-0">
                      <Image
                        src={product.image || "/placeholder.svg?height=48&width=48"}
                        alt={product.name}
                        fill
                        sizes="48px"
                        className="object-contain"
                      />
                    </div>
                    <div className="mr-3 flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{product.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {product.brand} • {product.currentPrice} ريال
                      </p>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="p-2 border-t border-gray-200 dark:border-gray-600">
            <button
              onClick={() => {
                handleSubmit(new Event("submit") as any)
              }}
              className="w-full text-center text-sm text-primary hover:underline py-1"
            >
              عرض كل النتائج ({searchResults.length})
            </button>
          </div>
        </div>
      )}

      {isOpen && searchTerm.length > 1 && searchResults.length === 0 && (
        <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg p-4 text-center">
          <p className="text-gray-500 dark:text-gray-400">لا توجد نتائج مطابقة</p>
        </div>
      )}
    </div>
  )
}
