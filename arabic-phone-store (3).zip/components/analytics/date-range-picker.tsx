"use client"

import { useState } from "react"
import { Calendar } from "lucide-react"

interface DateRangePickerProps {
  onDateRangeChange: (startDate: string, endDate: string) => void
  defaultRange?: string
}

export default function DateRangePicker({ onDateRangeChange, defaultRange = "7d" }: DateRangePickerProps) {
  const [selectedRange, setSelectedRange] = useState(defaultRange)
  const [customStart, setCustomStart] = useState("")
  const [customEnd, setCustomEnd] = useState("")

  const predefinedRanges = [
    { value: "1d", label: "اليوم" },
    { value: "7d", label: "آخر 7 أيام" },
    { value: "30d", label: "آخر 30 يوم" },
    { value: "90d", label: "آخر 3 أشهر" },
    { value: "1y", label: "آخر سنة" },
    { value: "custom", label: "فترة مخصصة" },
  ]

  const handleRangeChange = (range: string) => {
    setSelectedRange(range)

    if (range !== "custom") {
      const endDate = new Date()
      const startDate = new Date()

      switch (range) {
        case "1d":
          // Same day
          break
        case "7d":
          startDate.setDate(endDate.getDate() - 7)
          break
        case "30d":
          startDate.setDate(endDate.getDate() - 30)
          break
        case "90d":
          startDate.setDate(endDate.getDate() - 90)
          break
        case "1y":
          startDate.setFullYear(endDate.getFullYear() - 1)
          break
      }

      onDateRangeChange(startDate.toISOString().split("T")[0], endDate.toISOString().split("T")[0])
    }
  }

  const handleCustomDateChange = () => {
    if (customStart && customEnd) {
      onDateRangeChange(customStart, customEnd)
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
      <div className="flex items-center gap-2 mb-4">
        <Calendar size={16} className="text-gray-500 dark:text-gray-400" />
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">فترة التقرير</span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
        {predefinedRanges.map((range) => (
          <button
            key={range.value}
            onClick={() => handleRangeChange(range.value)}
            className={`px-3 py-2 text-sm rounded-lg transition-colors ${
              selectedRange === range.value
                ? "bg-primary text-white"
                : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
            }`}
          >
            {range.label}
          </button>
        ))}
      </div>

      {selectedRange === "custom" && (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">من</label>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">إلى</label>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="col-span-2">
            <button
              onClick={handleCustomDateChange}
              disabled={!customStart || !customEnd}
              className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
            >
              تطبيق
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
