"use client"

interface BarChartProps {
  data: Array<{
    label: string
    value: number
    color?: string
  }>
  height?: number
  showValues?: boolean
}

export default function BarChart({ data, height = 200, showValues = true }: BarChartProps) {
  const maxValue = Math.max(...data.map((item) => item.value))

  return (
    <div className="w-full">
      <div className="flex items-end justify-between gap-2" style={{ height: `${height}px` }}>
        {data.map((item, index) => {
          const barHeight = (item.value / maxValue) * (height - 40)
          const color = item.color || "#6e0aef"

          return (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="flex flex-col items-center justify-end h-full">
                {showValues && (
                  <span className="text-xs text-gray-600 dark:text-gray-400 mb-1">{item.value.toLocaleString()}</span>
                )}
                <div
                  className="w-full rounded-t transition-all duration-500 hover:opacity-80"
                  style={{
                    height: `${barHeight}px`,
                    backgroundColor: color,
                    minHeight: "4px",
                  }}
                />
              </div>
              <span className="text-xs text-gray-700 dark:text-gray-300 mt-2 text-center">{item.label}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
