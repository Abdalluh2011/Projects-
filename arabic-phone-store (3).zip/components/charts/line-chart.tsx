"use client"

interface LineChartProps {
  data: Array<{
    label: string
    value: number
  }>
  height?: number
  color?: string
  showDots?: boolean
}

export default function LineChart({ data, height = 200, color = "#6e0aef", showDots = true }: LineChartProps) {
  const maxValue = Math.max(...data.map((item) => item.value))
  const minValue = Math.min(...data.map((item) => item.value))
  const range = maxValue - minValue || 1

  const points = data
    .map((item, index) => {
      const x = (index / (data.length - 1)) * 100
      const y = 100 - ((item.value - minValue) / range) * 80 // 80% of height for the line
      return `${x},${y}`
    })
    .join(" ")

  return (
    <div className="w-full">
      <div className="relative" style={{ height: `${height}px` }}>
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Grid lines */}
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e5e7eb" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#grid)" />

          {/* Line */}
          <polyline fill="none" stroke={color} strokeWidth="2" points={points} className="drop-shadow-sm" />

          {/* Area under line */}
          <polygon fill={`${color}20`} points={`${points} 100,100 0,100`} />

          {/* Dots */}
          {showDots &&
            data.map((item, index) => {
              const x = (index / (data.length - 1)) * 100
              const y = 100 - ((item.value - minValue) / range) * 80
              return <circle key={index} cx={x} cy={y} r="1.5" fill={color} className="drop-shadow-sm" />
            })}
        </svg>

        {/* Labels */}
        <div className="absolute bottom-0 left-0 right-0 flex justify-between">
          {data.map((item, index) => (
            <span key={index} className="text-xs text-gray-600 dark:text-gray-400">
              {item.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
