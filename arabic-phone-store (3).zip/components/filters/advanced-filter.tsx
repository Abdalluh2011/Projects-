"use client"

import { useState } from "react"
import { Filter, Save, RotateCcw, Search, ChevronDown, Calendar } from "lucide-react"

export interface FilterOption {
  key: string
  label: string
  type: "select" | "multiselect" | "range" | "date" | "daterange" | "search" | "number"
  options?: Array<{ value: string; label: string }>
  placeholder?: string
  min?: number
  max?: number
}

export interface FilterValues {
  [key: string]: any
}

interface AdvancedFilterProps {
  filters: FilterOption[]
  values: FilterValues
  onChange: (values: FilterValues) => void
  onSave?: (name: string, values: FilterValues) => void
  savedFilters?: Array<{ name: string; values: FilterValues }>
  onLoadSaved?: (values: FilterValues) => void
  resultCount?: number
  className?: string
}

export default function AdvancedFilter({
  filters,
  values,
  onChange,
  onSave,
  savedFilters = [],
  onLoadSaved,
  resultCount,
  className = "",
}: AdvancedFilterProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)
  const [filterName, setFilterName] = useState("")
  const [savedFiltersOpen, setSavedFiltersOpen] = useState(false)

  const handleFilterChange = (key: string, value: any) => {
    const newValues = { ...values, [key]: value }
    onChange(newValues)
  }

  const handleReset = () => {
    const resetValues: FilterValues = {}
    filters.forEach((filter) => {
      if (filter.type === "multiselect") {
        resetValues[filter.key] = []
      } else if (filter.type === "range" || filter.type === "daterange") {
        resetValues[filter.key] = { min: "", max: "" }
      } else {
        resetValues[filter.key] = ""
      }
    })
    onChange(resetValues)
  }

  const handleSaveFilter = () => {
    if (filterName.trim() && onSave) {
      onSave(filterName.trim(), values)
      setFilterName("")
      setSaveDialogOpen(false)
    }
  }

  const hasActiveFilters = Object.values(values).some((value) => {
    if (Array.isArray(value)) return value.length > 0
    if (typeof value === "object" && value !== null) {
      return Object.values(value).some((v) => v !== "" && v !== null && v !== undefined)
    }
    return value !== "" && value !== null && value !== undefined
  })

  const renderFilterInput = (filter: FilterOption) => {
    const value = values[filter.key]

    switch (filter.type) {
      case "search":
        return (
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="text"
              value={value || ""}
              onChange={(e) => handleFilterChange(filter.key, e.target.value)}
              placeholder={filter.placeholder}
              className="w-full px-4 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )

      case "select":
        return (
          <select
            value={value || ""}
            onChange={(e) => handleFilterChange(filter.key, e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="">جميع {filter.label}</option>
            {filter.options?.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        )

      case "multiselect":
        return (
          <div className="space-y-2">
            {filter.options?.map((option) => (
              <label key={option.value} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={(value || []).includes(option.value)}
                  onChange={(e) => {
                    const currentValues = value || []
                    const newValues = e.target.checked
                      ? [...currentValues, option.value]
                      : currentValues.filter((v: string) => v !== option.value)
                    handleFilterChange(filter.key, newValues)
                  }}
                  className="rounded border-gray-300 text-primary focus:ring-primary"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">{option.label}</span>
              </label>
            ))}
          </div>
        )

      case "range":
        return (
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              value={value?.min || ""}
              onChange={(e) => handleFilterChange(filter.key, { ...value, min: e.target.value })}
              placeholder={`من ${filter.min || 0}`}
              min={filter.min}
              max={filter.max}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <input
              type="number"
              value={value?.max || ""}
              onChange={(e) => handleFilterChange(filter.key, { ...value, max: e.target.value })}
              placeholder={`إلى ${filter.max || 10000}`}
              min={filter.min}
              max={filter.max}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )

      case "date":
        return (
          <div className="relative">
            <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="date"
              value={value || ""}
              onChange={(e) => handleFilterChange(filter.key, e.target.value)}
              className="w-full px-4 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )

      case "daterange":
        return (
          <div className="grid grid-cols-2 gap-2">
            <input
              type="date"
              value={value?.start || ""}
              onChange={(e) => handleFilterChange(filter.key, { ...value, start: e.target.value })}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <input
              type="date"
              value={value?.end || ""}
              onChange={(e) => handleFilterChange(filter.key, { ...value, end: e.target.value })}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )

      case "number":
        return (
          <input
            type="number"
            value={value || ""}
            onChange={(e) => handleFilterChange(filter.key, e.target.value)}
            placeholder={filter.placeholder}
            min={filter.min}
            max={filter.max}
            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        )

      default:
        return null
    }
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-600">
        <div className="flex items-center gap-3">
          <Filter className="text-primary" size={20} />
          <h3 className="font-bold text-gray-900 dark:text-white">فلترة متقدمة</h3>
          {hasActiveFilters && (
            <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
              {
                Object.values(values).filter((v) => {
                  if (Array.isArray(v)) return v.length > 0
                  if (typeof v === "object" && v !== null) {
                    return Object.values(v).some((val) => val !== "" && val !== null)
                  }
                  return v !== "" && v !== null
                }).length
              }{" "}
              فلتر نشط
            </span>
          )}
          {resultCount !== undefined && (
            <span className="text-sm text-gray-500 dark:text-gray-400">({resultCount} نتيجة)</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {savedFilters.length > 0 && (
            <div className="relative">
              <button
                onClick={() => setSavedFiltersOpen(!savedFiltersOpen)}
                className="flex items-center gap-2 px-3 py-2 text-sm bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
              >
                الفلاتر المحفوظة
                <ChevronDown size={14} />
              </button>
              {savedFiltersOpen && (
                <div className="absolute left-0 top-full mt-1 w-48 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg z-50">
                  {savedFilters.map((saved, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        onLoadSaved?.(saved.values)
                        setSavedFiltersOpen(false)
                      }}
                      className="w-full text-right px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 first:rounded-t-lg last:rounded-b-lg"
                    >
                      {saved.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
          {onSave && hasActiveFilters && (
            <button
              onClick={() => setSaveDialogOpen(true)}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-green-500 text-white rounded-lg hover:bg-green-600"
            >
              <Save size={14} />
              حفظ
            </button>
          )}
          {hasActiveFilters && (
            <button
              onClick={handleReset}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600"
            >
              <RotateCcw size={14} />
              إعادة تعيين
            </button>
          )}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-2 px-3 py-2 text-sm bg-primary text-white rounded-lg hover:bg-primary-hover"
          >
            <Filter size={14} />
            {isExpanded ? "إخفاء الفلاتر" : "إظهار الفلاتر"}
          </button>
        </div>
      </div>

      {/* Filters */}
      {isExpanded && (
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filters.map((filter) => (
              <div key={filter.key} className="space-y-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{filter.label}</label>
                {renderFilterInput(filter)}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Save Dialog */}
      {saveDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">حفظ الفلتر</h3>
            <input
              type="text"
              value={filterName}
              onChange={(e) => setFilterName(e.target.value)}
              placeholder="اسم الفلتر"
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white mb-4"
            />
            <div className="flex gap-3">
              <button
                onClick={handleSaveFilter}
                disabled={!filterName.trim()}
                className="flex-1 bg-primary text-white py-2 rounded-lg hover:bg-primary-hover disabled:opacity-50 disabled:cursor-not-allowed"
              >
                حفظ
              </button>
              <button
                onClick={() => setSaveDialogOpen(false)}
                className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
