"use client"

import { ArrowUp, ArrowDown } from "lucide-react"

export interface SortOption {
  key: string
  label: string
  direction?: "asc" | "desc"
}

interface SortOptionsProps {
  options: SortOption[]
  value: string
  direction: "asc" | "desc"
  onChange: (sortKey: string, direction: "asc" | "desc") => void
  className?: string
}

export default function SortOptions({ options, value, direction, onChange, className = "" }: SortOptionsProps) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <span className="text-sm text-gray-600 dark:text-gray-400">ترتيب حسب:</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value, direction)}
        className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
      >
        {options.map((option) => (
          <option key={option.key} value={option.key}>
            {option.label}
          </option>
        ))}
      </select>
      <button
        onClick={() => onChange(value, direction === "asc" ? "desc" : "asc")}
        className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title={direction === "asc" ? "تصاعدي" : "تنازلي"}
      >
        {direction === "asc" ? (
          <ArrowUp size={16} className="text-gray-600 dark:text-gray-400" />
        ) : (
          <ArrowDown size={16} className="text-gray-600 dark:text-gray-400" />
        )}
      </button>
    </div>
  )
}
