"use client"

import Link from "next/link"
import { Scale, X } from "lucide-react"
import { useCompare } from "@/lib/compare-context"

export default function CompareFloatingButton() {
  const { compareList, removeFromCompare } = useCompare()

  if (compareList.length === 0) return null

  return (
    <div className="fixed bottom-24 left-8 z-40">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-600 p-4 max-w-xs">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-gray-900 dark:text-white">المقارنة ({compareList.length})</h4>
          <Scale className="text-primary" size={16} />
        </div>

        <div className="space-y-2 mb-3">
          {compareList.map((product) => (
            <div key={product.id} className="flex items-center justify-between text-sm">
              <span className="text-gray-700 dark:text-gray-300 truncate flex-1">{product.name}</span>
              <button onClick={() => removeFromCompare(product.id)} className="text-red-500 hover:text-red-700 ml-2">
                <X size={14} />
              </button>
            </div>
          ))}
        </div>

        <Link
          href="/compare"
          className="block w-full bg-primary text-white text-center py-2 rounded-lg hover:bg-primary-hover transition-colors text-sm font-medium"
        >
          مقارنة المنتجات
        </Link>
      </div>
    </div>
  )
}
