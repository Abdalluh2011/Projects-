"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Package, Truck, CheckCircle, Clock, MapPin, Phone, Mail } from "lucide-react"
import { useOrders, type Order } from "@/lib/orders-context"

interface OrderTrackingPageProps {
  params: {
    id: string
  }
}

export default function OrderTrackingPage({ params }: OrderTrackingPageProps) {
  const { getOrderById } = useOrders()
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Add a small delay to ensure the context is properly loaded
    const timer = setTimeout(() => {
      const foundOrder = getOrderById(params.id)
      setOrder(foundOrder || null)
      setLoading(false)
    }, 100)

    return () => clearTimeout(timer)
  }, [params.id, getOrderById])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="text-yellow-500" size={20} />
      case "confirmed":
        return <CheckCircle className="text-blue-500" size={20} />
      case "processing":
        return <Package className="text-orange-500" size={20} />
      case "shipped":
        return <Truck className="text-green-500" size={20} />
      case "delivered":
        return <CheckCircle className="text-green-600" size={20} />
      default:
        return <Clock className="text-gray-500" size={20} />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "قيد المراجعة"
      case "confirmed":
        return "مؤكد"
      case "processing":
        return "قيد التحضير"
      case "shipped":
        return "تم الشحن"
      case "delivered":
        return "تم التسليم"
      case "cancelled":
        return "ملغي"
      default:
        return status
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  if (loading) {
    return (
      <div className="container py-12">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">جاري تحميل بيانات الطلب...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <Package size={64} className="mx-auto text-gray-300 dark:text-gray-600 mb-6" />
          <h1 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">الطلب غير موجود</h1>
          <p className="text-gray-500 dark:text-gray-400 mb-8">لم نتمكن من العثور على الطلب رقم: {params.id}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/orders" className="btn btn-primary">
              عرض جميع الطلبات
            </Link>
            <Link href="/products" className="btn btn-outline">
              تصفح المنتجات
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-12">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-primary">
          الرئيسية
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} />{" "}
        <Link href="/orders" className="hover:text-primary">
          طلباتي
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} /> {order.id}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* معلومات الطلب */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">طلب رقم: {order.id}</h1>
              <div className="flex items-center gap-2">
                {getStatusIcon(order.status)}
                <span className="font-medium text-gray-900 dark:text-white">{getStatusText(order.status)}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">تاريخ الطلب</p>
                <p className="font-medium text-gray-900 dark:text-white">{formatDate(order.orderDate)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">التسليم المتوقع</p>
                <p className="font-medium text-gray-900 dark:text-white">{formatDate(order.estimatedDelivery)}</p>
              </div>
              {order.trackingNumber && (
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">رقم التتبع</p>
                  <p className="font-medium text-primary">{order.trackingNumber}</p>
                </div>
              )}
            </div>

            {/* المنتجات */}
            <div className="border-t border-gray-200 dark:border-gray-600 pt-6">
              <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">المنتجات</h3>
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4">
                    <div className="w-16 h-16 relative">
                      <Image
                        src={item.image || "/placeholder.svg?height=64&width=64"}
                        alt={item.name}
                        fill
                        sizes="64px"
                        className="object-contain rounded"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">{item.name}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">الكمية: {item.quantity}</p>
                    </div>
                    <div className="text-primary font-bold">{item.price * item.quantity} ريال</div>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-200 dark:border-gray-600 mt-4 pt-4 flex justify-between">
                <span className="font-bold text-gray-900 dark:text-white">الإجمالي</span>
                <span className="font-bold text-primary text-xl">{order.total} ريال</span>
              </div>
            </div>
          </div>

          {/* تتبع الطلب */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-bold mb-6 text-gray-900 dark:text-white">تتبع الطلب</h2>
            <div className="space-y-4">
              {order.statusHistory.map((status, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="flex flex-col items-center">
                    {getStatusIcon(status.status)}
                    {index < order.statusHistory.length - 1 && (
                      <div className="w-0.5 h-8 bg-gray-300 dark:bg-gray-600 mt-2"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-900 dark:text-white">{getStatusText(status.status)}</h4>
                      <span className="text-sm text-gray-500 dark:text-gray-400">{formatDate(status.date)}</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{status.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* معلومات التسليم */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white flex items-center gap-2">
              <MapPin className="text-primary" size={20} />
              عنوان التسليم
            </h3>
            <div className="space-y-2 text-gray-700 dark:text-gray-300">
              <p className="font-medium">
                {order.customerInfo.firstName} {order.customerInfo.lastName}
              </p>
              <p>{order.customerInfo.address}</p>
              <p>
                {order.customerInfo.city}, {order.customerInfo.governorate}
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">معلومات الاتصال</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                <Phone size={16} className="text-primary" />
                <span>{order.customerInfo.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                <Mail size={16} className="text-primary" />
                <span>{order.customerInfo.email}</span>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">طريقة الدفع</h3>
            <p className="text-gray-700 dark:text-gray-300">
              {order.paymentMethod === "cash"
                ? "الدفع عند الاستلام"
                : order.paymentMethod === "card"
                  ? "بطاقة ائتمانية"
                  : "تحويل بنكي"}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
