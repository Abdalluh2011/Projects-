"use client"

import { useSearchParams } from "next/navigation"
import { Search } from "lucide-react"
import { products } from "@/lib/products"
import ProductCard from "@/components/product-card"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""

  const searchResults = query
    ? products.filter(
        (product) =>
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.description.toLowerCase().includes(query.toLowerCase()) ||
          product.brand.toLowerCase().includes(query.toLowerCase()) ||
          product.category.toLowerCase().includes(query.toLowerCase()) ||
          Object.values(product.specifications).some(
            (spec) => typeof spec === "string" && spec.toLowerCase().includes(query.toLowerCase()),
          ),
      )
    : []

  return (
    <div className="container py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">نتائج البحث: {query}</h1>
        <p className="text-gray-600">تم العثور على {searchResults.length} منتج</p>
      </div>

      {searchResults.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {searchResults.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <Search size={64} className="mx-auto text-gray-300 mb-6" />
          <h2 className="text-2xl font-bold mb-4">لم يتم العثور على نتائج</h2>
          <p className="text-gray-500 max-w-md mx-auto">
            لم نتمكن من العثور على أي منتجات تطابق "{query}". يرجى تجربة كلمات بحث أخرى أو تصفح جميع المنتجات.
          </p>
        </div>
      )}
    </div>
  )
}
