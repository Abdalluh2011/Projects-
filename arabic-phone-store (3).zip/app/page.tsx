import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import ProductsSection from "@/components/products-section"
import RecentlyViewed from "@/components/recently-viewed"

export default function Home() {
  return (
    <>
      <HeroSection />
      <FeaturesSection />
      <ProductsSection />
      <RecentlyViewed />
    </>
  )
}
