"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Trash2, ShoppingBag, ArrowRight, AlertCircle } from "lucide-react"
import { useCart } from "@/lib/cart-context"

export default function CartPage() {
  const { items, removeItem, updateQuantity, clearCart, totalPrice } = useCart()
  const [couponCode, setCouponCode] = useState("")
  const [couponError, setCouponError] = useState("")

  const handleQuantityChange = (id: string, newQuantity: number) => {
    if (newQuantity > 0) {
      updateQuantity(id, newQuantity)
    }
  }

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setCouponError("الكوبون غير صالح أو منتهي الصلاحية")
  }

  if (items.length === 0) {
    return (
      <div className="container py-16 text-center">
        <div className="max-w-md mx-auto">
          <ShoppingBag size={64} className="mx-auto text-gray-300 mb-6" />
          <h1 className="text-2xl font-bold mb-4">سلة التسوق فارغة</h1>
          <p className="text-gray-500 mb-8">لم تقم بإضافة أي منتجات إلى سلة التسوق بعد.</p>
          <Link href="/products" className="btn btn-primary">
            تصفح المنتجات
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-8">سلة التسوق</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">المنتجات ({items.length})</h2>
            </div>

            <ul>
              {items.map((item) => (
                <li key={item.id} className="p-6 border-b border-gray-200 last:border-0">
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <div className="w-24 h-24 relative flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg?height=96&width=96"}
                        alt={item.name}
                        fill
                        sizes="96px"
                        className="object-contain"
                      />
                    </div>
                    <div className="flex-1 text-center sm:text-right">
                      <h3 className="font-semibold mb-1">{item.name}</h3>
                      <p className="text-primary font-bold">{item.price} ريال</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
                        <button
                          onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center bg-gray-100 hover:bg-gray-200 transition-colors"
                          aria-label="تقليل الكمية"
                        >
                          -
                        </button>
                        <span className="w-10 text-center">{item.quantity}</span>
                        <button
                          onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center bg-gray-100 hover:bg-gray-200 transition-colors"
                          aria-label="زيادة الكمية"
                        >
                          +
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                        aria-label="إزالة من السلة"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            <div className="p-6 flex justify-between items-center bg-gray-50">
              <button onClick={clearCart} className="text-red-500 hover:text-red-700 transition-colors text-sm">
                إفراغ السلة
              </button>
              <Link href="/products" className="flex items-center gap-2 text-primary hover:underline">
                <ArrowRight size={16} className="rotate-180" /> متابعة التسوق
              </Link>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-xl shadow-sm overflow-hidden sticky top-24">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">ملخص الطلب</h2>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <form onSubmit={handleCouponSubmit}>
                  <label htmlFor="coupon" className="block text-sm font-medium text-gray-700 mb-2">
                    كود الخصم
                  </label>
                  <div className="flex">
                    <input
                      type="text"
                      id="coupon"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="flex-1 border border-gray-300 rounded-r-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="أدخل كود الخصم"
                    />
                    <button
                      type="submit"
                      className="bg-primary text-white px-4 py-2 rounded-l-lg hover:bg-primary-hover transition-colors"
                    >
                      تطبيق
                    </button>
                  </div>
                  {couponError && (
                    <div className="mt-2 text-red-500 text-sm flex items-center gap-1">
                      <AlertCircle size={14} />
                      {couponError}
                    </div>
                  )}
                </form>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">إجمالي المنتجات</span>
                  <span>{totalPrice} ريال</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الشحن</span>
                  <span>مجاني</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الضريبة (15%)</span>
                  <span>{(totalPrice * 0.15).toFixed(2)} ريال</span>
                </div>
                <div className="border-t border-gray-200 pt-3 flex justify-between font-bold">
                  <span>الإجمالي</span>
                  <span className="text-primary">{(totalPrice * 1.15).toFixed(2)} ريال</span>
                </div>
              </div>

              <Link
                href="/checkout"
                className="w-full bg-primary text-white py-3 rounded-lg text-center block hover:bg-primary-hover transition-colors font-medium"
              >
                إتمام الطلب
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
