"use client"

import Link from "next/link"
import Image from "next/image"
import { Heart, ArrowRight, ShoppingBag } from "lucide-react"
import { useFavorites } from "@/lib/favorites-context"
import FavoriteButton from "@/components/favorite-button"
import { getProductBySlug } from "@/lib/products"

export default function FavoritesPage() {
  const { favorites } = useFavorites()

  return (
    <div className="container py-12">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-primary">
          الرئيسية
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} /> المفضلة
      </div>

      <h1 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white flex items-center gap-3">
        <Heart className="text-red-500" size={32} />
        المنتجات المفضلة ({favorites.length})
      </h1>

      {favorites.length === 0 ? (
        <div className="text-center py-16">
          <Heart size={64} className="mx-auto text-gray-300 dark:text-gray-600 mb-6" />
          <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">لا توجد منتجات مفضلة</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md mx-auto">
            لم تقم بإضافة أي منتجات إلى قائمة المفضلة بعد. تصفح منتجاتنا واختر ما يعجبك!
          </p>
          <Link href="/products" className="btn btn-primary">
            <ShoppingBag size={18} />
            تصفح المنتجات
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {favorites.map((favorite) => {
            const product = getProductBySlug(favorite.slug)
            return (
              <div
                key={favorite.id}
                className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-lg relative border border-gray-200 dark:border-gray-700"
              >
                <div className="absolute top-4 right-4 z-10">
                  {product && <FavoriteButton product={product} size="sm" />}
                </div>
                <Link href={`/products/${favorite.slug}`} className="block">
                  <div className="p-6 border-b border-gray-200 dark:border-gray-700 h-[250px] flex items-center justify-center">
                    <Image
                      src={favorite.image || "/placeholder.svg?height=200&width=200"}
                      alt={favorite.name}
                      width={200}
                      height={200}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white line-clamp-2">
                      {favorite.name}
                    </h3>
                    <div className="text-xl font-bold text-primary">{favorite.price} ريال</div>
                  </div>
                </Link>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
