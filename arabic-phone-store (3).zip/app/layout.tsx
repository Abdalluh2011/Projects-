import type React from "react"
import type { Metadata } from "next"
import { Tajawal, Lalezar } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollToTop from "@/components/scroll-to-top"
import CompareFloatingButton from "@/components/compare-floating-button"
import ErrorBoundary from "@/components/ui/error-boundary"
import { ToastProvider } from "@/components/providers/toast-provider"
import { CartProvider } from "@/lib/cart-context"
import { ThemeProvider } from "@/lib/theme-context"
import { FavoritesProvider } from "@/lib/favorites-context"
import { ReviewsProvider } from "@/lib/reviews-context"
import { OrdersProvider } from "@/lib/orders-context"
import { NotificationsProvider } from "@/lib/notifications-context"
import { RecentlyViewedProvider } from "@/lib/recently-viewed-context"
import { CompareProvider } from "@/lib/compare-context"
import { AnalyticsProvider } from "@/lib/analytics-context"
import { SavedFiltersProvider } from "@/lib/saved-filters-context"
import { AuthProvider } from "@/lib/auth-context"
import { Suspense } from "react"

const tajawal = Tajawal({
  subsets: ["arabic"],
  weight: ["400", "500", "700"],
  variable: "--font-tajawal",
})

const lalezar = Lalezar({
  subsets: ["arabic"],
  weight: ["400"],
  variable: "--font-lalezar",
})

export const metadata: Metadata = {
  title: "الشامل للألكترونيات | متجر الهواتف الذكية",
  description: "متجر الشامل للإلكترونيات - أفضل مكان لشراء الهواتف الذكية والأجهزة الإلكترونية بأسعار تنافسية",
  keywords: "هواتف ذكية, إلكترونيات, متجر, تسوق, أجهزة محمولة, تكنولوجيا",
  authors: [{ name: "الشامل للإلكترونيات" }],
  creator: "الشامل للإلكترونيات",
  publisher: "الشامل للإلكترونيات",
  robots: "index, follow",
  manifest: "/manifest.json",
  themeColor: "#6e0aef",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "الشامل للإلكترونيات",
  },
  openGraph: {
    type: "website",
    locale: "ar_SA",
    url: "https://alshamel-electronics.com",
    siteName: "الشامل للإلكترونيات",
    title: "الشامل للألكترونيات | متجر الهواتف الذكية",
    description: "متجر الشامل للإلكترونيات - أفضل مكان لشراء الهواتف الذكية والأجهزة الإلكترونية بأسعار تنافسية",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "الشامل للإلكترونيات",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "الشامل للألكترونيات | متجر الهواتف الذكية",
    description: "متجر الشامل للإلكترونيات - أفضل مكان لشراء الهواتف الذكية والأجهزة الإلكترونية بأسعار تنافسية",
    images: ["/og-image.jpg"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl" className="scroll-smooth">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="الشامل للإلكترونيات" />
        <link rel="canonical" href="https://alshamel-electronics.com" />
      </head>
      <body
        className={`${tajawal.variable} ${lalezar.variable} bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300`}
      >
        <ErrorBoundary>
          <ThemeProvider>
            <ToastProvider>
              <AuthProvider>
                <NotificationsProvider>
                  <OrdersProvider>
                    <AnalyticsProvider>
                      <SavedFiltersProvider>
                        <ReviewsProvider>
                          <FavoritesProvider>
                            <RecentlyViewedProvider>
                              <CompareProvider>
                                <CartProvider>
                                  <Suspense fallback={<div>Loading...</div>}>
                                    <Header />
                                    <main className="min-h-screen">{children}</main>
                                    <Footer />
                                    <ScrollToTop />
                                    <CompareFloatingButton />
                                  </Suspense>
                                </CartProvider>
                              </CompareProvider>
                            </RecentlyViewedProvider>
                          </FavoritesProvider>
                        </ReviewsProvider>
                      </SavedFiltersProvider>
                    </AnalyticsProvider>
                  </OrdersProvider>
                </NotificationsProvider>
              </AuthProvider>
            </ToastProvider>
          </ThemeProvider>
        </ErrorBoundary>
      </body>
    </html>
  )
}
