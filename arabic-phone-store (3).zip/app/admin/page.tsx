"use client"

import { useState, useMemo } from "react"
import {
  Package,
  Users,
  ShoppingCart,
  TrendingUp,
  Eye,
  Edit,
  Trash2,
  Plus,
  DollarSign,
  Download,
  RefreshCw,
  AlertTriangle,
  Target,
  MousePointer,
  Clock,
} from "lucide-react"
import { products } from "@/lib/products"
import { useAnalytics } from "@/lib/analytics-context"
import { useOrders } from "@/lib/orders-context"
import { useSavedFilters } from "@/lib/saved-filters-context"
import KPICard from "@/components/analytics/kpi-card"
import BarChart from "@/components/charts/bar-chart"
import LineChart from "@/components/charts/line-chart"
import DonutChart from "@/components/charts/donut-chart"
import DateRangePicker from "@/components/analytics/date-range-picker"
import AdvancedFilter, { type FilterValues, type FilterOption } from "@/components/filters/advanced-filter"
import SortOptions, { type SortOption } from "@/components/filters/sort-options"
import { applyFilters, applySorting, getFilterSummary } from "@/lib/filter-utils"
import AdminGuard from "@/components/admin/admin-guard"
import AdminHeader from "@/components/admin/admin-header"

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [dateRange, setDateRange] = useState({ start: "", end: "" })
  const { analytics, refreshAnalytics, getAnalyticsByDateRange, exportReport } = useAnalytics()
  const { orders } = useOrders()
  const { saveFilter, getFiltersByType } = useSavedFilters()

  // Filter states
  const [ordersFilters, setOrdersFilters] = useState<FilterValues>({})
  const [productsFilters, setProductsFilters] = useState<FilterValues>({})
  const [customersFilters, setCustomersFilters] = useState<FilterValues>({})
  const [reportsFilters, setReportsFilters] = useState<FilterValues>({})

  // Sort states
  const [ordersSort, setOrdersSort] = useState({ key: "orderDate", direction: "desc" as "asc" | "desc" })
  const [productsSort, setProductsSort] = useState({ key: "name", direction: "asc" as "asc" | "desc" })

  const handleDateRangeChange = (startDate: string, endDate: string) => {
    setDateRange({ start: startDate, end: endDate })
  }

  // Orders filter configuration
  const ordersFilterConfig: FilterOption[] = [
    {
      key: "search",
      label: "البحث",
      type: "search",
      placeholder: "البحث برقم الطلب أو اسم العميل...",
    },
    {
      key: "status",
      label: "حالة الطلب",
      type: "multiselect",
      options: [
        { value: "pending", label: "قيد المراجعة" },
        { value: "confirmed", label: "مؤكد" },
        { value: "processing", label: "قيد التحضير" },
        { value: "shipped", label: "تم الشحن" },
        { value: "delivered", label: "تم التسليم" },
        { value: "cancelled", label: "ملغي" },
      ],
    },
    {
      key: "total",
      label: "مبلغ الطلب (ريال)",
      type: "range",
      min: 0,
      max: 10000,
    },
    {
      key: "orderDate",
      label: "فترة الطلب",
      type: "daterange",
    },
    {
      key: "paymentMethod",
      label: "طريقة الدفع",
      type: "select",
      options: [
        { value: "cash", label: "الدفع عند الاستلام" },
        { value: "card", label: "بطاقة ائتمانية" },
        { value: "bank", label: "تحويل بنكي" },
      ],
    },
    {
      key: "customerInfo.governorate",
      label: "المحافظة",
      type: "select",
      options: [
        { value: "صنعاء", label: "صنعاء" },
        { value: "عدن", label: "عدن" },
        { value: "تعز", label: "تعز" },
        { value: "الحديدة", label: "الحديدة" },
        { value: "إب", label: "إب" },
        { value: "ذمار", label: "ذمار" },
        { value: "حضرموت", label: "حضرموت" },
        { value: "لحج", label: "لحج" },
      ],
    },
  ]

  // Products filter configuration
  const productsFilterConfig: FilterOption[] = [
    {
      key: "search",
      label: "البحث",
      type: "search",
      placeholder: "البحث في اسم المنتج أو الوصف...",
    },
    {
      key: "category",
      label: "الفئة",
      type: "multiselect",
      options: [
        { value: "هواتف فاخرة", label: "هواتف فاخرة" },
        { value: "هواتف متوسطة", label: "هواتف متوسطة" },
        { value: "هواتف اقتصادية", label: "هواتف اقتصادية" },
      ],
    },
    {
      key: "brand",
      label: "العلامة التجارية",
      type: "multiselect",
      options: [
        { value: "Apple", label: "Apple" },
        { value: "Samsung", label: "Samsung" },
        { value: "Xiaomi", label: "Xiaomi" },
        { value: "OnePlus", label: "OnePlus" },
        { value: "BLU", label: "BLU" },
      ],
    },
    {
      key: "currentPrice",
      label: "السعر (ريال)",
      type: "range",
      min: 0,
      max: 5000,
    },
    {
      key: "rating",
      label: "التقييم",
      type: "range",
      min: 1,
      max: 5,
    },
    {
      key: "hasDiscount",
      label: "المنتجات المخفضة",
      type: "select",
      options: [
        { value: "true", label: "نعم" },
        { value: "false", label: "لا" },
      ],
    },
  ]

  // Reports filter configuration
  const reportsFilterConfig: FilterOption[] = [
    {
      key: "reportType",
      label: "نوع التقرير",
      type: "select",
      options: [
        { value: "sales", label: "تقرير المبيعات" },
        { value: "products", label: "تقرير المنتجات" },
        { value: "customers", label: "تقرير العملاء" },
        { value: "orders", label: "تقرير الطلبات" },
      ],
    },
    {
      key: "period",
      label: "الفترة الزمنية",
      type: "daterange",
    },
    {
      key: "minRevenue",
      label: "الحد الأدنى للإيرادات",
      type: "number",
      min: 0,
    },
    {
      key: "includeRefunds",
      label: "تضمين المرتجعات",
      type: "select",
      options: [
        { value: "true", label: "نعم" },
        { value: "false", label: "لا" },
      ],
    },
  ]

  // Sort options
  const ordersSortOptions: SortOption[] = [
    { key: "orderDate", label: "تاريخ الطلب" },
    { key: "total", label: "مبلغ الطلب" },
    { key: "customerInfo.firstName", label: "اسم العميل" },
    { key: "status", label: "حالة الطلب" },
  ]

  const productsSortOptions: SortOption[] = [
    { key: "name", label: "اسم المنتج" },
    { key: "currentPrice", label: "السعر" },
    { key: "rating", label: "التقييم" },
    { key: "brand", label: "العلامة التجارية" },
    { key: "category", label: "الفئة" },
  ]

  // Apply filters and sorting
  const filteredOrders = useMemo(() => {
    const filtered = applyFilters(orders, ordersFilters, ordersFilterConfig)
    return applySorting(filtered, ordersSort.key, ordersSort.direction)
  }, [orders, ordersFilters, ordersSort])

  const filteredProducts = useMemo(() => {
    // Add hasDiscount property to products for filtering
    const productsWithDiscount = products.map((product) => ({
      ...product,
      hasDiscount: product.oldPrice ? "true" : "false",
    }))

    const filtered = applyFilters(productsWithDiscount, productsFilters, productsFilterConfig)
    return applySorting(filtered, productsSort.key, productsSort.direction)
  }, [products, productsFilters, productsSort])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "shipped":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "processing":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "confirmed":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "pending":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
      case "delivered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "shipped":
        return "تم الشحن"
      case "processing":
        return "قيد التحضير"
      case "confirmed":
        return "مؤكد"
      case "pending":
        return "قيد المراجعة"
      case "delivered":
        return "تم التسليم"
      case "cancelled":
        return "ملغي"
      default:
        return status
    }
  }

  // Prepare chart data
  const salesChartData =
    analytics.salesByDay?.map((day) => ({
      label: day.day,
      value: day.revenue,
    })) || []

  const ordersChartData =
    analytics.salesByMonth?.map((month) => ({
      label: month.month,
      value: month.orders,
      color: "#6e0aef",
    })) || []

  const statusChartData = Object.entries(analytics.ordersByStatus || {}).map(([status, count]) => ({
    label: getStatusText(status),
    value: count,
    color:
      status === "delivered"
        ? "#10b981"
        : status === "shipped"
          ? "#3b82f6"
          : status === "processing"
            ? "#f59e0b"
            : status === "pending"
              ? "#8b5cf6"
              : "#ef4444",
  }))

  const trafficSourcesData =
    analytics.topTrafficSources?.map((source) => ({
      label: source.source,
      value: source.visitors,
      color: `hsl(${Math.random() * 360}, 70%, 50%)`,
    })) || []

  return (
    <AdminGuard>
      <AdminHeader />
      <div className="container py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">لوحة تحكم الإدارة</h1>
            <p className="text-gray-600 dark:text-gray-400">إدارة المتجر والطلبات والمنتجات مع فلترة متقدمة</p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={refreshAnalytics}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            >
              <RefreshCw size={16} />
              تحديث البيانات
            </button>
            <DateRangePicker onDateRangeChange={handleDateRangeChange} />
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard
            title="إجمالي المبيعات"
            value={analytics.totalRevenue || 0}
            format="currency"
            change={{ value: 12.5, type: "increase", period: "هذا الشهر" }}
            icon={DollarSign}
            color="bg-green-500"
          />
          <KPICard
            title="إجمالي الطلبات"
            value={analytics.totalOrders || 0}
            change={{ value: 8.2, type: "increase", period: "هذا الأسبوع" }}
            icon={ShoppingCart}
            color="bg-blue-500"
          />
          <KPICard
            title="إجمالي العملاء"
            value={analytics.totalCustomers || 0}
            change={{ value: 15.3, type: "increase", period: "هذا الشهر" }}
            icon={Users}
            color="bg-purple-500"
          />
          <KPICard
            title="معدل التحويل"
            value={analytics.conversionRate || 0}
            format="percentage"
            change={{ value: 2.1, type: "decrease", period: "هذا الأسبوع" }}
            icon={Target}
            color="bg-orange-500"
          />
        </div>

        {/* Additional KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard
            title="متوسط قيمة الطلب"
            value={analytics.averageOrderValue || 0}
            format="currency"
            change={{ value: 5.7, type: "increase", period: "هذا الشهر" }}
            icon={TrendingUp}
            color="bg-indigo-500"
          />
          <KPICard
            title="الزوار الفريدون"
            value={analytics.uniqueVisitors || 0}
            change={{ value: 18.9, type: "increase", period: "هذا الأسبوع" }}
            icon={MousePointer}
            color="bg-pink-500"
          />
          <KPICard
            title="معدل ترك السلة"
            value={analytics.cartAbandonmentRate || 0}
            format="percentage"
            change={{ value: 3.2, type: "decrease", period: "هذا الشهر" }}
            icon={AlertTriangle}
            color="bg-red-500"
          />
          <KPICard
            title="متوسط مدة الجلسة"
            value={`${Math.floor((analytics.averageSessionDuration || 0) / 60)}:${String((analytics.averageSessionDuration || 0) % 60).padStart(2, "0")}`}
            change={{ value: 7.4, type: "increase", period: "هذا الأسبوع" }}
            icon={Clock}
            color="bg-teal-500"
          />
        </div>

        {/* التبويبات */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
          <div className="border-b border-gray-200 dark:border-gray-600">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab("overview")}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === "overview"
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                نظرة عامة
              </button>
              <button
                onClick={() => setActiveTab("analytics")}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === "analytics"
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                التحليلات المتقدمة
              </button>
              <button
                onClick={() => setActiveTab("orders")}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === "orders"
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                الطلبات ({filteredOrders.length})
              </button>
              <button
                onClick={() => setActiveTab("products")}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === "products"
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                المنتجات ({filteredProducts.length})
              </button>
              <button
                onClick={() => setActiveTab("reports")}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === "reports"
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                التقارير
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === "overview" && (
              <div className="space-y-8">
                {/* Charts Row 1 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">المبيعات اليومية</h3>
                    <LineChart data={salesChartData} height={200} />
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">الطلبات الشهرية</h3>
                    <BarChart data={ordersChartData} height={200} />
                  </div>
                </div>

                {/* Charts Row 2 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">حالة الطلبات</h3>
                    <DonutChart data={statusChartData} />
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">مصادر الزيارات</h3>
                    <DonutChart data={trafficSourcesData} />
                  </div>
                </div>

                {/* Recent Orders */}
                <div>
                  <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">آخر الطلبات</h2>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200 dark:border-gray-600">
                          <th className="text-right py-3 text-gray-600 dark:text-gray-400">رقم الطلب</th>
                          <th className="text-right py-3 text-gray-600 dark:text-gray-400">العميل</th>
                          <th className="text-right py-3 text-gray-600 dark:text-gray-400">المبلغ</th>
                          <th className="text-right py-3 text-gray-600 dark:text-gray-400">الحالة</th>
                          <th className="text-right py-3 text-gray-600 dark:text-gray-400">التاريخ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredOrders.slice(0, 5).map((order) => (
                          <tr key={order.id} className="border-b border-gray-200 dark:border-gray-600">
                            <td className="py-3 text-gray-900 dark:text-white">{order.id}</td>
                            <td className="py-3 text-gray-900 dark:text-white">
                              {order.customerInfo.firstName} {order.customerInfo.lastName}
                            </td>
                            <td className="py-3 text-gray-900 dark:text-white">{order.total} ريال</td>
                            <td className="py-3">
                              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(order.status)}`}>
                                {getStatusText(order.status)}
                              </span>
                            </td>
                            <td className="py-3 text-gray-900 dark:text-white">{order.orderDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "analytics" && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">التحليلات المتقدمة</h2>
                  <div className="flex gap-2">
                    <button
                      onClick={() => exportReport("sales")}
                      className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                    >
                      <Download size={16} />
                      تصدير تقرير المبيعات
                    </button>
                  </div>
                </div>

                {/* Top Selling Products */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">أكثر المنتجات مبيعاً</h3>
                  <div className="space-y-4">
                    {analytics.topSellingProducts?.map((product, index) => (
                      <div
                        key={product.id}
                        className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg"
                      >
                        <div className="flex items-center gap-4">
                          <span className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </span>
                          <div>
                            <h4 className="font-medium text-gray-900 dark:text-white">{product.name}</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {product.sales} مبيعة • {product.revenue} ريال
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-primary">{product.revenue} ريال</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{product.sales} قطعة</div>
                        </div>
                      </div>
                    )) || []}
                  </div>
                </div>

                {/* Low Stock Alert */}
                <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-6 border border-red-200 dark:border-red-800">
                  <h3 className="text-lg font-bold mb-4 text-red-800 dark:text-red-200 flex items-center gap-2">
                    <AlertTriangle size={20} />
                    تنبيه: منتجات قليلة المخزون
                  </h3>
                  <div className="space-y-3">
                    {analytics.lowStockProducts?.map((product) => (
                      <div
                        key={product.id}
                        className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg"
                      >
                        <span className="font-medium text-gray-900 dark:text-white">{product.name}</span>
                        <span className="text-red-600 dark:text-red-400 font-bold">{product.stock} قطعة متبقية</span>
                      </div>
                    )) || []}
                  </div>
                </div>

                {/* Customer Analytics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 text-center">
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">عملاء جدد</h4>
                    <div className="text-3xl font-bold text-green-500 mb-2">{analytics.newCustomers || 0}</div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">هذا الشهر</p>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 text-center">
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">عملاء عائدون</h4>
                    <div className="text-3xl font-bold text-blue-500 mb-2">{analytics.returningCustomers || 0}</div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">هذا الشهر</p>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 text-center">
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">قيمة العميل</h4>
                    <div className="text-3xl font-bold text-purple-500 mb-2">
                      {Math.round(analytics.customerLifetimeValue || 0)} ريال
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">متوسط القيمة</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "orders" && (
              <div className="space-y-6">
                {/* Advanced Filters */}
                <AdvancedFilter
                  filters={ordersFilterConfig}
                  values={ordersFilters}
                  onChange={setOrdersFilters}
                  onSave={(name, values) => saveFilter(name, "orders", values)}
                  savedFilters={getFiltersByType("orders")}
                  onLoadSaved={setOrdersFilters}
                  resultCount={filteredOrders.length}
                />

                {/* Sort Options */}
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    إدارة الطلبات ({filteredOrders.length})
                  </h2>
                  <SortOptions
                    options={ordersSortOptions}
                    value={ordersSort.key}
                    direction={ordersSort.direction}
                    onChange={(key, direction) => setOrdersSort({ key, direction })}
                  />
                </div>

                {/* Filter Summary */}
                {Object.values(ordersFilters).some((v) => v && (Array.isArray(v) ? v.length > 0 : true)) && (
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                    <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">الفلاتر المطبقة:</h4>
                    <div className="flex flex-wrap gap-2">
                      {getFilterSummary(ordersFilters, ordersFilterConfig).map((summary, index) => (
                        <span
                          key={index}
                          className="bg-blue-100 dark:bg-blue-800 text-blue-800 dark:text-blue-200 px-2 py-1 rounded text-sm"
                        >
                          {summary}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Orders Table */}
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-600">
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">رقم الطلب</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">العميل</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">المبلغ</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">الحالة</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">التاريخ</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">المحافظة</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">طريقة الدفع</th>
                        <th className="text-right py-3 text-gray-600 dark:text-gray-400">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((order) => (
                        <tr key={order.id} className="border-b border-gray-200 dark:border-gray-600">
                          <td className="py-3 text-gray-900 dark:text-white">{order.id}</td>
                          <td className="py-3 text-gray-900 dark:text-white">
                            {order.customerInfo.firstName} {order.customerInfo.lastName}
                          </td>
                          <td className="py-3 text-gray-900 dark:text-white">{order.total} ريال</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(order.status)}`}>
                              {getStatusText(order.status)}
                            </span>
                          </td>
                          <td className="py-3 text-gray-900 dark:text-white">{order.orderDate}</td>
                          <td className="py-3 text-gray-900 dark:text-white">{order.customerInfo.governorate}</td>
                          <td className="py-3 text-gray-900 dark:text-white">
                            {order.paymentMethod === "cash"
                              ? "الدفع عند الاستلام"
                              : order.paymentMethod === "card"
                                ? "بطاقة ائتمانية"
                                : "تحويل بنكي"}
                          </td>
                          <td className="py-3">
                            <div className="flex items-center gap-2">
                              <button className="p-1 text-blue-500 hover:text-blue-700" title="عرض">
                                <Eye size={16} />
                              </button>
                              <button className="p-1 text-green-500 hover:text-green-700" title="تعديل">
                                <Edit size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {filteredOrders.length === 0 && (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    لا توجد طلبات تطابق الفلاتر المحددة
                  </div>
                )}
              </div>
            )}

            {activeTab === "products" && (
              <div className="space-y-6">
                {/* Advanced Filters */}
                <AdvancedFilter
                  filters={productsFilterConfig}
                  values={productsFilters}
                  onChange={setProductsFilters}
                  onSave={(name, values) => saveFilter(name, "products", values)}
                  savedFilters={getFiltersByType("products")}
                  onLoadSaved={setProductsFilters}
                  resultCount={filteredProducts.length}
                />

                {/* Sort Options */}
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    إدارة المنتجات ({filteredProducts.length})
                  </h2>
                  <div className="flex items-center gap-4">
                    <SortOptions
                      options={productsSortOptions}
                      value={productsSort.key}
                      direction={productsSort.direction}
                      onChange={(key, direction) => setProductsSort({ key, direction })}
                    />
                    <button className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-hover">
                      <Plus size={16} />
                      إضافة منتج
                    </button>
                  </div>
                </div>

                {/* Filter Summary */}
                {Object.values(productsFilters).some((v) => v && (Array.isArray(v) ? v.length > 0 : true)) && (
                  <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                    <h4 className="font-medium text-green-800 dark:text-green-200 mb-2">الفلاتر المطبقة:</h4>
                    <div className="flex flex-wrap gap-2">
                      {getFilterSummary(productsFilters, productsFilterConfig).map((summary, index) => (
                        <span
                          key={index}
                          className="bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200 px-2 py-1 rounded text-sm"
                        >
                          {summary}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Products Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredProducts.map((product) => (
                    <div
                      key={product.id}
                      className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 hover:shadow-lg transition-shadow"
                    >
                      <div className="aspect-square bg-gray-100 dark:bg-gray-700 rounded-lg mb-4 flex items-center justify-center relative">
                        {product.badge && (
                          <span
                            className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium ${
                              product.badge.type === "new"
                                ? "bg-red-500 text-white"
                                : product.badge.type === "bestseller"
                                  ? "bg-green-500 text-white"
                                  : "bg-yellow-500 text-black"
                            }`}
                          >
                            {product.badge.text}
                          </span>
                        )}
                        {product.oldPrice && (
                          <span className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                            -{Math.round(((product.oldPrice - product.currentPrice) / product.oldPrice) * 100)}%
                          </span>
                        )}
                        <Package className="text-gray-400" size={48} />
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-medium text-gray-900 dark:text-white line-clamp-2">{product.name}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {product.brand} • {product.category}
                        </p>
                        <div className="flex items-center gap-2">
                          <span className="text-primary font-bold">{product.currentPrice} ريال</span>
                          {product.oldPrice && (
                            <span className="text-gray-500 dark:text-gray-400 text-sm line-through">
                              {product.oldPrice} ريال
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <span
                              key={star}
                              className={`text-sm ${star <= product.rating ? "text-yellow-400" : "text-gray-300"}`}
                            >
                              ★
                            </span>
                          ))}
                          <span className="text-sm text-gray-500 dark:text-gray-400 mr-1">({product.reviewCount})</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-4">
                        <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 text-sm">
                          <Eye size={14} />
                          عرض
                        </button>
                        <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 text-sm">
                          <Edit size={14} />
                          تعديل
                        </button>
                        <button className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {filteredProducts.length === 0 && (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    لا توجد منتجات تطابق الفلاتر المحددة
                  </div>
                )}
              </div>
            )}

            {activeTab === "reports" && (
              <div className="space-y-8">
                {/* Advanced Filters for Reports */}
                <AdvancedFilter
                  filters={reportsFilterConfig}
                  values={reportsFilters}
                  onChange={setReportsFilters}
                  onSave={(name, values) => saveFilter(name, "reports", values)}
                  savedFilters={getFiltersByType("reports")}
                  onLoadSaved={setReportsFilters}
                />

                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">التقارير المفصلة</h2>
                  <div className="flex gap-2">
                    <button
                      onClick={() => exportReport("sales")}
                      className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                    >
                      <Download size={16} />
                      تقرير المبيعات
                    </button>
                    <button
                      onClick={() => exportReport("products")}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                    >
                      <Download size={16} />
                      تقرير المنتجات
                    </button>
                    <button
                      onClick={() => exportReport("customers")}
                      className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
                    >
                      <Download size={16} />
                      تقرير العملاء
                    </button>
                    <button
                      onClick={() => exportReport("orders")}
                      className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                    >
                      <Download size={16} />
                      تقرير الطلبات
                    </button>
                  </div>
                </div>

                {/* Filter Summary for Reports */}
                {Object.values(reportsFilters).some((v) => v && (Array.isArray(v) ? v.length > 0 : true)) && (
                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 border border-purple-200 dark:border-purple-800">
                    <h4 className="font-medium text-purple-800 dark:text-purple-200 mb-2">فلاتر التقرير:</h4>
                    <div className="flex flex-wrap gap-2">
                      {getFilterSummary(reportsFilters, reportsFilterConfig).map((summary, index) => (
                        <span
                          key={index}
                          className="bg-purple-100 dark:bg-purple-800 text-purple-800 dark:text-purple-200 px-2 py-1 rounded text-sm"
                        >
                          {summary}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                    <h3 className="text-lg font-bold mb-2">إجمالي المبيعات</h3>
                    <div className="text-3xl font-bold">{analytics.totalRevenue?.toLocaleString()} ريال</div>
                    <p className="text-green-100 text-sm mt-2">+12.5% من الشهر الماضي</p>
                  </div>
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                    <h3 className="text-lg font-bold mb-2">عدد الطلبات</h3>
                    <div className="text-3xl font-bold">{analytics.totalOrders}</div>
                    <p className="text-blue-100 text-sm mt-2">+8.2% من الأسبوع الماضي</p>
                  </div>
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                    <h3 className="text-lg font-bold mb-2">العملاء النشطون</h3>
                    <div className="text-3xl font-bold">{analytics.totalCustomers}</div>
                    <p className="text-purple-100 text-sm mt-2">+15.3% من الشهر الماضي</p>
                  </div>
                  <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                    <h3 className="text-lg font-bold mb-2">متوسط قيمة الطلب</h3>
                    <div className="text-3xl font-bold">{Math.round(analytics.averageOrderValue || 0)} ريال</div>
                    <p className="text-orange-100 text-sm mt-2">+5.7% من الشهر الماضي</p>
                  </div>
                </div>

                {/* Detailed Analytics */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">أداء المبيعات الشهرية</h3>
                    <BarChart
                      data={
                        analytics.salesByMonth?.map((month) => ({
                          label: month.month,
                          value: month.revenue,
                          color: "#10b981",
                        })) || []
                      }
                      height={250}
                    />
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">اتجاه الطلبات</h3>
                    <LineChart
                      data={
                        analytics.salesByDay?.map((day) => ({
                          label: day.day,
                          value: day.orders,
                        })) || []
                      }
                      height={250}
                      color="#3b82f6"
                    />
                  </div>
                </div>

                {/* Performance Metrics */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-6 text-gray-900 dark:text-white">مؤشرات الأداء الرئيسية</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">
                        {analytics.conversionRate?.toFixed(1)}%
                      </div>
                      <p className="text-gray-600 dark:text-gray-400">معدل التحويل</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">{analytics.bounceRate?.toFixed(1)}%</div>
                      <p className="text-gray-600 dark:text-gray-400">معدل الارتداد</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">
                        {Math.floor((analytics.averageSessionDuration || 0) / 60)}:
                        {String((analytics.averageSessionDuration || 0) % 60).padStart(2, "0")}
                      </div>
                      <p className="text-gray-600 dark:text-gray-400">متوسط مدة الجلسة</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminGuard>
  )
}
