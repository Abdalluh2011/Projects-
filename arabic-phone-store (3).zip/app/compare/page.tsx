"use client"

import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Scale, X, ShoppingCart } from "lucide-react"
import { useCompare } from "@/lib/compare-context"
import ProductRating from "@/components/product-rating"
import AddToCartButton from "@/components/add-to-cart-button"

export default function ComparePage() {
  const { compareList, removeFromCompare, clearCompare } = useCompare()

  if (compareList.length === 0) {
    return (
      <div className="container py-16 text-center">
        <Scale size={64} className="mx-auto text-gray-300 dark:text-gray-600 mb-6" />
        <h1 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">لا توجد منتجات للمقارنة</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-8">
          لم تقم بإضافة أي منتجات للمقارنة بعد. تصفح منتجاتنا واختر ما تريد مقارنته!
        </p>
        <Link href="/products" className="btn btn-primary">
          <ShoppingCart size={18} />
          تصفح المنتجات
        </Link>
      </div>
    )
  }

  const specifications = [
    { key: "screen", label: "الشاشة" },
    { key: "processor", label: "المعالج" },
    { key: "backCamera", label: "الكاميرا الخلفية" },
    { key: "frontCamera", label: "الكاميرا الأمامية" },
    { key: "storage", label: "التخزين" },
    { key: "ram", label: "الذاكرة" },
    { key: "battery", label: "البطارية" },
  ]

  return (
    <div className="container py-12">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-primary">
          الرئيسية
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} /> مقارنة المنتجات
      </div>

      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
          <Scale className="text-primary" size={32} />
          مقارنة المنتجات ({compareList.length})
        </h1>
        <button
          onClick={clearCompare}
          className="text-red-500 hover:text-red-700 transition-colors flex items-center gap-2"
        >
          <X size={16} />
          مسح الكل
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-600">
                <th className="text-right p-6 text-gray-600 dark:text-gray-400 font-medium w-48">المواصفات</th>
                {compareList.map((product) => (
                  <th key={product.id} className="p-6 min-w-[300px]">
                    <div className="relative">
                      <button
                        onClick={() => removeFromCompare(product.id)}
                        className="absolute top-0 left-0 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600 transition-colors"
                      >
                        <X size={12} />
                      </button>
                      <div className="text-center">
                        <div className="w-32 h-32 mx-auto mb-4 relative">
                          <Image
                            src={product.image || "/placeholder.svg?height=128&width=128"}
                            alt={product.name}
                            fill
                            sizes="128px"
                            className="object-contain"
                          />
                        </div>
                        <h3 className="font-bold text-gray-900 dark:text-white mb-2">{product.name}</h3>
                        <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="sm" />
                        <div className="mt-2">
                          <span className="text-xl font-bold text-primary">{product.currentPrice} ريال</span>
                          {product.oldPrice && (
                            <span className="text-gray-500 dark:text-gray-400 text-sm line-through mr-2">
                              {product.oldPrice} ريال
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {specifications.map((spec) => (
                <tr key={spec.key} className="border-b border-gray-200 dark:border-gray-600 last:border-b-0">
                  <td className="p-6 font-medium text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700">
                    {spec.label}
                  </td>
                  {compareList.map((product) => (
                    <td key={product.id} className="p-6 text-gray-700 dark:text-gray-300">
                      {product.specifications[spec.key as keyof typeof product.specifications] || "غير محدد"}
                    </td>
                  ))}
                </tr>
              ))}
              <tr className="border-b border-gray-200 dark:border-gray-600">
                <td className="p-6 font-medium text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700">الوصف</td>
                {compareList.map((product) => (
                  <td key={product.id} className="p-6 text-gray-700 dark:text-gray-300">
                    <p className="text-sm line-clamp-3">{product.description}</p>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="p-6 font-medium text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700">الإجراءات</td>
                {compareList.map((product) => (
                  <td key={product.id} className="p-6">
                    <div className="space-y-3">
                      <AddToCartButton product={product} />
                      <Link
                        href={`/products/${product.slug}`}
                        className="block text-center text-primary hover:underline text-sm"
                      >
                        عرض التفاصيل
                      </Link>
                    </div>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
