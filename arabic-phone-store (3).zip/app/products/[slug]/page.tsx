"use client"

import { useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { getProductBySlug, getRelatedProducts } from "@/lib/products"
import ProductRating from "@/components/product-rating"
import AddToCartButton from "@/components/add-to-cart-button"
import ProductCard from "@/components/product-card"
import FavoriteButton from "@/components/favorite-button"
import CompareButton from "@/components/compare-button"
import ShareButton from "@/components/share-button"
import ProductReviews from "@/components/product-reviews"
import { useRecentlyViewed } from "@/lib/recently-viewed-context"
import { notFound } from "next/navigation"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductBySlug(params.slug)
  const { addToRecentlyViewed } = useRecentlyViewed()

  useEffect(() => {
    if (product) {
      addToRecentlyViewed({
        id: product.id,
        name: product.name,
        price: product.currentPrice,
        image: product.image,
        slug: product.slug,
      })
    }
  }, [product, addToRecentlyViewed])

  if (!product) {
    notFound()
  }

  const relatedProducts = getRelatedProducts(product.id, 4)
  const currentUrl = typeof window !== "undefined" ? window.location.href : ""

  return (
    <div className="container py-12">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-primary">
          الرئيسية
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} />{" "}
        <Link href="/products" className="hover:text-primary">
          المنتجات
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} /> {product.name}
      </div>

      {/* Product Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-16">
        {/* Product Image */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-8 flex items-center justify-center border border-gray-200 dark:border-gray-700 relative">
          <div className="absolute top-4 right-4 flex gap-2">
            <FavoriteButton product={product} />
            <CompareButton product={product} />
          </div>
          <Image
            src={product.image || "/placeholder.svg?height=400&width=400"}
            alt={product.name}
            width={400}
            height={400}
            className="max-h-[400px] object-contain"
            priority
          />
        </div>

        {/* Product Info */}
        <div>
          {product.badge && (
            <span
              className={`inline-block px-3 py-1 rounded-full text-sm font-medium mb-4 ${
                product.badge.type === "new"
                  ? "bg-[#dc3545] text-white"
                  : product.badge.type === "bestseller"
                    ? "bg-[#28a745] text-white"
                    : "bg-[#ffc107] text-[#333]"
              }`}
            >
              {product.badge.text}
            </span>
          )}

          <h1 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">{product.name}</h1>

          <div className="mb-4">
            <ProductRating rating={product.rating} reviewCount={product.reviewCount} size="lg" />
          </div>

          <div className="mb-6">
            <span className="text-3xl font-bold text-primary">{product.currentPrice} ريال</span>
            {product.oldPrice && (
              <span className="text-gray-500 dark:text-gray-400 text-xl line-through mr-3">
                {product.oldPrice} ريال
              </span>
            )}
          </div>

          <div className="mb-8">
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{product.description}</p>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">المواصفات</h3>
            <div className="bg-[#f8f7fc] dark:bg-gray-700 rounded-lg p-4">
              <ul className="space-y-3">
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">الشاشة:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.screen}</span>
                </li>
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">المعالج:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.processor}</span>
                </li>
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">الكاميرا الخلفية:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.backCamera}</span>
                </li>
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">الكاميرا الأمامية:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.frontCamera}</span>
                </li>
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">التخزين:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.storage}</span>
                </li>
                {product.specifications.ram && (
                  <li className="flex">
                    <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">الذاكرة:</span>
                    <span className="text-gray-900 dark:text-white">{product.specifications.ram}</span>
                  </li>
                )}
                <li className="flex">
                  <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">البطارية:</span>
                  <span className="text-gray-900 dark:text-white">{product.specifications.battery}</span>
                </li>
                {product.specifications.additionalFeatures && (
                  <li className="flex">
                    <span className="font-medium ml-2 text-gray-700 dark:text-gray-300 w-28">ميزات إضافية:</span>
                    <span className="text-gray-900 dark:text-white">{product.specifications.additionalFeatures}</span>
                  </li>
                )}
              </ul>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <AddToCartButton product={product} />
            </div>
            <ShareButton title={product.name} url={currentUrl} description={product.description} />
          </div>
        </div>
      </div>

      {/* Product Reviews */}
      <div className="mb-16">
        <ProductReviews productId={product.id} />
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">منتجات مشابهة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <ProductCard key={relatedProduct.id} product={relatedProduct} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
