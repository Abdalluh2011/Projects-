import { Filter } from "lucide-react"
import { products, categories } from "@/lib/products"
import ProductCard from "@/components/product-card"

export default function ProductsPage() {
  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-8">جميع الهواتف</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Filter size={18} /> تصفية النتائج
              </h3>

              <div className="mb-6">
                <h4 className="font-medium mb-3">الفئات</h4>
                <ul className="space-y-2">
                  {categories.map((category) => (
                    <li key={category.id}>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-primary focus:ring-primary" />
                        <span>{category.name}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-6">
                <h4 className="font-medium mb-3">العلامات التجارية</h4>
                <ul className="space-y-2">
                  {Array.from(new Set(products.map((p) => p.brand))).map((brand) => (
                    <li key={brand}>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-primary focus:ring-primary" />
                        <span>{brand}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-medium mb-3">السعر</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="min-price" className="text-sm text-gray-600 block mb-1">
                      من
                    </label>
                    <input
                      type="number"
                      id="min-price"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label htmlFor="max-price" className="text-sm text-gray-600 block mb-1">
                      إلى
                    </label>
                    <input
                      type="number"
                      id="max-price"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="5000"
                    />
                  </div>
                </div>
              </div>
            </div>

            <button className="w-full bg-primary text-white py-2 rounded-lg hover:bg-primary-hover transition-colors">
              تطبيق الفلتر
            </button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="lg:col-span-3">
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-600">عرض {products.length} منتج</p>
            <div className="flex items-center gap-2">
              <label htmlFor="sort" className="text-gray-600">
                ترتيب حسب:
              </label>
              <select
                id="sort"
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              >
                <option value="newest">الأحدث</option>
                <option value="price-asc">السعر: من الأقل للأعلى</option>
                <option value="price-desc">السعر: من الأعلى للأقل</option>
                <option value="rating">التقييم</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
