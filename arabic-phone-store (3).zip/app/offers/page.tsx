"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Tag, Clock, Percent, Gift } from "lucide-react"
import { products } from "@/lib/products"
import ProductCard from "@/components/product-card"

export default function OffersPage() {
  const [activeTab, setActiveTab] = useState("all")

  // Filter products with discounts
  const discountedProducts = products.filter((product) => product.oldPrice && product.oldPrice > product.currentPrice)

  // Create special offers
  const specialOffers = [
    {
      id: "flash-sale",
      title: "تخفيضات البرق ⚡",
      description: "خصومات تصل إلى 40% لفترة محدودة",
      endTime: "2024-02-01T23:59:59",
      products: discountedProducts.slice(0, 3),
      color: "bg-red-500",
    },
    {
      id: "weekend-deal",
      title: "عروض نهاية الأسبوع 🎉",
      description: "خصومات خاصة على مجموعة مختارة",
      endTime: "2024-01-28T23:59:59",
      products: discountedProducts.slice(1, 4),
      color: "bg-blue-500",
    },
    {
      id: "clearance",
      title: "تصفية المخزون 📦",
      description: "أسعار لا تُقاوم على آخر القطع",
      endTime: "2024-01-31T23:59:59",
      products: discountedProducts.slice(2, 5),
      color: "bg-green-500",
    },
  ]

  const getTimeRemaining = (endTime: string) => {
    const now = new Date().getTime()
    const end = new Date(endTime).getTime()
    const difference = end - now

    if (difference > 0) {
      const days = Math.floor(difference / (1000 * 60 * 60 * 24))
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))

      return { days, hours, minutes, expired: false }
    }

    return { days: 0, hours: 0, minutes: 0, expired: true }
  }

  const filteredOffers = activeTab === "all" ? specialOffers : specialOffers.filter((offer) => offer.id === activeTab)

  return (
    <div className="container py-12">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-primary">
          الرئيسية
        </Link>{" "}
        <ArrowRight className="inline mx-2 rotate-180" size={14} /> العروض الخاصة
      </div>

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 flex items-center justify-center gap-3">
          <Tag className="text-primary" size={36} />
          العروض الخاصة والتخفيضات
        </h1>
        <p className="text-gray-600 dark:text-gray-400 text-lg">اكتشف أفضل العروض والخصومات على الهواتف الذكية</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap justify-center gap-4 mb-8">
        <button
          onClick={() => setActiveTab("all")}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            activeTab === "all"
              ? "bg-primary text-white"
              : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
          }`}
        >
          جميع العروض
        </button>
        <button
          onClick={() => setActiveTab("flash-sale")}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            activeTab === "flash-sale"
              ? "bg-primary text-white"
              : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
          }`}
        >
          تخفيضات البرق
        </button>
        <button
          onClick={() => setActiveTab("weekend-deal")}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            activeTab === "weekend-deal"
              ? "bg-primary text-white"
              : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
          }`}
        >
          عروض نهاية الأسبوع
        </button>
        <button
          onClick={() => setActiveTab("clearance")}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            activeTab === "clearance"
              ? "bg-primary text-white"
              : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
          }`}
        >
          تصفية المخزون
        </button>
      </div>

      {/* Offers */}
      <div className="space-y-12">
        {filteredOffers.map((offer) => {
          const timeRemaining = getTimeRemaining(offer.endTime)

          return (
            <div
              key={offer.id}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden border border-gray-200 dark:border-gray-700"
            >
              <div className={`${offer.color} text-white p-6`}>
                <div className="flex flex-col md:flex-row items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-2">{offer.title}</h2>
                    <p className="text-white/90">{offer.description}</p>
                  </div>
                  <div className="mt-4 md:mt-0">
                    {!timeRemaining.expired ? (
                      <div className="bg-white/20 rounded-lg p-4 text-center">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock size={16} />
                          <span className="text-sm">ينتهي خلال:</span>
                        </div>
                        <div className="flex gap-2 text-lg font-bold">
                          <div className="bg-white/30 rounded px-2 py-1">
                            <div>{timeRemaining.days}</div>
                            <div className="text-xs">يوم</div>
                          </div>
                          <div className="bg-white/30 rounded px-2 py-1">
                            <div>{timeRemaining.hours}</div>
                            <div className="text-xs">ساعة</div>
                          </div>
                          <div className="bg-white/30 rounded px-2 py-1">
                            <div>{timeRemaining.minutes}</div>
                            <div className="text-xs">دقيقة</div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-red-500 rounded-lg p-4 text-center">
                        <span className="font-bold">انتهى العرض</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {offer.products.map((product) => (
                    <div key={product.id} className="relative">
                      <ProductCard product={product} />
                      {product.oldPrice && (
                        <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                          <Percent size={12} />
                          {Math.round(((product.oldPrice - product.currentPrice) / product.oldPrice) * 100)}%
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Newsletter Signup */}
      <div className="mt-16 bg-gradient-to-r from-primary to-purple-600 rounded-2xl p-8 text-center text-white">
        <Gift size={48} className="mx-auto mb-4" />
        <h3 className="text-2xl font-bold mb-4">لا تفوت العروض الجديدة!</h3>
        <p className="mb-6">اشترك في النشرة الإخبارية لتصلك أحدث العروض والخصومات</p>
        <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
          <input
            type="email"
            placeholder="أدخل بريدك الإلكتروني"
            className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
          />
          <button className="bg-white text-primary px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors">
            اشتراك
          </button>
        </div>
      </div>
    </div>
  )
}
