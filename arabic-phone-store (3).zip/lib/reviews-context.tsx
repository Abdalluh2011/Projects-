"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface Review {
  id: string
  productId: string
  userName: string
  rating: number
  comment: string
  date: string
  helpful: number
}

interface ReviewsContextType {
  reviews: Review[]
  addReview: (review: Omit<Review, "id" | "date" | "helpful">) => void
  getProductReviews: (productId: string) => Review[]
  getAverageRating: (productId: string) => number
  markHelpful: (reviewId: string) => void
}

const ReviewsContext = createContext<ReviewsContextType | undefined>(undefined)

// بيانات تجريبية للمراجعات
const initialReviews: Review[] = [
  {
    id: "1",
    productId: "iphone-13-pro-max",
    userName: "أحمد محمد",
    rating: 5,
    comment: "هاتف ممتاز جداً، الكاميرا رائعة والأداء سريع. أنصح به بشدة!",
    date: "2024-01-15",
    helpful: 12,
  },
  {
    id: "2",
    productId: "iphone-13-pro-max",
    userName: "فاطمة علي",
    rating: 4,
    comment: "جودة عالية لكن السعر مرتفع قليلاً. بشكل عام راضية عن الشراء.",
    date: "2024-01-10",
    helpful: 8,
  },
  {
    id: "3",
    productId: "samsung-galaxy-a14",
    userName: "محمد سالم",
    rating: 4,
    comment: "هاتف جيد للسعر، البطارية تدوم طويلاً والشاشة واضحة.",
    date: "2024-01-12",
    helpful: 5,
  },
  {
    id: "4",
    productId: "xiaomi-poco-x3-pro",
    userName: "سارة أحمد",
    rating: 5,
    comment: "أفضل هاتف في هذه الفئة السعرية، الأداء ممتاز للألعاب.",
    date: "2024-01-08",
    helpful: 15,
  },
]

export function ReviewsProvider({ children }: { children: ReactNode }) {
  const [reviews, setReviews] = useState<Review[]>(initialReviews)

  // Load reviews from localStorage on initial render
  useEffect(() => {
    const savedReviews = localStorage.getItem("reviews")
    if (savedReviews) {
      try {
        const parsedReviews = JSON.parse(savedReviews)
        setReviews(parsedReviews)
      } catch (error) {
        console.error("Failed to parse reviews from localStorage:", error)
        setReviews(initialReviews)
      }
    }
  }, [])

  // Update localStorage whenever reviews change
  useEffect(() => {
    localStorage.setItem("reviews", JSON.stringify(reviews))
  }, [reviews])

  const addReview = (reviewData: Omit<Review, "id" | "date" | "helpful">) => {
    const newReview: Review = {
      ...reviewData,
      id: Date.now().toString(),
      date: new Date().toISOString().split("T")[0],
      helpful: 0,
    }
    setReviews((prev) => [newReview, ...prev])
  }

  const getProductReviews = (productId: string) => {
    return reviews.filter((review) => review.productId === productId)
  }

  const getAverageRating = (productId: string) => {
    const productReviews = getProductReviews(productId)
    if (productReviews.length === 0) return 0
    const sum = productReviews.reduce((acc, review) => acc + review.rating, 0)
    return Number((sum / productReviews.length).toFixed(1))
  }

  const markHelpful = (reviewId: string) => {
    setReviews((prev) =>
      prev.map((review) => (review.id === reviewId ? { ...review, helpful: review.helpful + 1 } : review)),
    )
  }

  return (
    <ReviewsContext.Provider value={{ reviews, addReview, getProductReviews, getAverageRating, markHelpful }}>
      {children}
    </ReviewsContext.Provider>
  )
}

export function useReviews() {
  const context = useContext(ReviewsContext)
  if (context === undefined) {
    throw new Error("useReviews must be used within a ReviewsProvider")
  }
  return context
}
