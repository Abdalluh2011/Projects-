"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useOrders } from "@/lib/orders-context"
import { products } from "@/lib/products"

export interface AnalyticsData {
  // Sales Analytics
  totalRevenue: number
  monthlyRevenue: number
  dailyRevenue: number
  averageOrderValue: number

  // Product Analytics
  totalProducts: number
  topSellingProducts: Array<{
    id: string
    name: string
    sales: number
    revenue: number
  }>
  lowStockProducts: Array<{
    id: string
    name: string
    stock: number
  }>

  // Customer Analytics
  totalCustomers: number
  newCustomers: number
  returningCustomers: number
  customerLifetimeValue: number

  // Order Analytics
  totalOrders: number
  pendingOrders: number
  completedOrders: number
  cancelledOrders: number
  ordersByStatus: Record<string, number>

  // Traffic Analytics
  pageViews: number
  uniqueVisitors: number
  conversionRate: number
  cartAbandonmentRate: number

  // Time-based Analytics
  salesByMonth: Array<{
    month: string
    revenue: number
    orders: number
  }>
  salesByDay: Array<{
    day: string
    revenue: number
    orders: number
  }>

  // Performance Metrics
  averageSessionDuration: number
  bounceRate: number
  topTrafficSources: Array<{
    source: string
    visitors: number
    percentage: number
  }>
}

interface AnalyticsContextType {
  analytics: AnalyticsData
  refreshAnalytics: () => void
  getAnalyticsByDateRange: (startDate: string, endDate: string) => AnalyticsData
  exportReport: (type: "sales" | "products" | "customers" | "orders") => void
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined)

// Mock data for demonstration
const generateMockAnalytics = (orders: any[]): AnalyticsData => {
  const now = new Date()
  const thisMonth = now.getMonth()
  const thisYear = now.getFullYear()

  // Calculate revenue
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)
  const monthlyOrders = orders.filter((order) => {
    const orderDate = new Date(order.orderDate)
    return orderDate.getMonth() === thisMonth && orderDate.getFullYear() === thisYear
  })
  const monthlyRevenue = monthlyOrders.reduce((sum, order) => sum + order.total, 0)

  const today = now.toISOString().split("T")[0]
  const dailyOrders = orders.filter((order) => order.orderDate === today)
  const dailyRevenue = dailyOrders.reduce((sum, order) => sum + order.total, 0)

  // Calculate order statistics
  const ordersByStatus = orders.reduce(
    (acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  // Generate sales by month (last 6 months)
  const salesByMonth = []
  for (let i = 5; i >= 0; i--) {
    const date = new Date(thisYear, thisMonth - i, 1)
    const monthOrders = orders.filter((order) => {
      const orderDate = new Date(order.orderDate)
      return orderDate.getMonth() === date.getMonth() && orderDate.getFullYear() === date.getFullYear()
    })

    salesByMonth.push({
      month: date.toLocaleDateString("ar-SA", { month: "short", year: "numeric" }),
      revenue: monthOrders.reduce((sum, order) => sum + order.total, 0),
      orders: monthOrders.length,
    })
  }

  // Generate sales by day (last 7 days)
  const salesByDay = []
  for (let i = 6; i >= 0; i--) {
    const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000)
    const dayString = date.toISOString().split("T")[0]
    const dayOrders = orders.filter((order) => order.orderDate === dayString)

    salesByDay.push({
      day: date.toLocaleDateString("ar-SA", { weekday: "short" }),
      revenue: dayOrders.reduce((sum, order) => sum + order.total, 0),
      orders: dayOrders.length,
    })
  }

  // Calculate top selling products
  const productSales = orders.reduce(
    (acc, order) => {
      order.items.forEach((item: any) => {
        if (!acc[item.id]) {
          acc[item.id] = { name: item.name, sales: 0, revenue: 0 }
        }
        acc[item.id].sales += item.quantity
        acc[item.id].revenue += item.price * item.quantity
      })
      return acc
    },
    {} as Record<string, any>,
  )

  const topSellingProducts = Object.entries(productSales)
    .map(([id, data]) => ({ id, ...data }))
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 5)

  // Mock low stock products
  const lowStockProducts = products.slice(0, 3).map((product) => ({
    id: product.id,
    name: product.name,
    stock: Math.floor(Math.random() * 10) + 1,
  }))

  // Mock customer data
  const uniqueCustomers = new Set(orders.map((order) => order.customerInfo.email)).size

  // Mock traffic data
  const mockTrafficSources = [
    { source: "البحث المباشر", visitors: 1250, percentage: 45 },
    { source: "وسائل التواصل الاجتماعي", visitors: 680, percentage: 25 },
    { source: "الإعلانات المدفوعة", visitors: 420, percentage: 15 },
    { source: "المواقع المرجعية", visitors: 280, percentage: 10 },
    { source: "أخرى", visitors: 140, percentage: 5 },
  ]

  return {
    totalRevenue,
    monthlyRevenue,
    dailyRevenue,
    averageOrderValue: orders.length > 0 ? totalRevenue / orders.length : 0,

    totalProducts: products.length,
    topSellingProducts,
    lowStockProducts,

    totalCustomers: uniqueCustomers,
    newCustomers: Math.floor(uniqueCustomers * 0.3),
    returningCustomers: Math.floor(uniqueCustomers * 0.7),
    customerLifetimeValue: uniqueCustomers > 0 ? totalRevenue / uniqueCustomers : 0,

    totalOrders: orders.length,
    pendingOrders: ordersByStatus.pending || 0,
    completedOrders: (ordersByStatus.delivered || 0) + (ordersByStatus.shipped || 0),
    cancelledOrders: ordersByStatus.cancelled || 0,
    ordersByStatus,

    pageViews: 15420,
    uniqueVisitors: 2780,
    conversionRate: orders.length > 0 ? (orders.length / 2780) * 100 : 0,
    cartAbandonmentRate: 68.5,

    salesByMonth,
    salesByDay,

    averageSessionDuration: 245, // seconds
    bounceRate: 32.5,
    topTrafficSources: mockTrafficSources,
  }
}

export function AnalyticsProvider({ children }: { children: ReactNode }) {
  const { orders } = useOrders()
  const [analytics, setAnalytics] = useState<AnalyticsData>({} as AnalyticsData)

  const refreshAnalytics = () => {
    const newAnalytics = generateMockAnalytics(orders)
    setAnalytics(newAnalytics)
  }

  useEffect(() => {
    refreshAnalytics()
  }, [orders])

  const getAnalyticsByDateRange = (startDate: string, endDate: string): AnalyticsData => {
    const filteredOrders = orders.filter((order) => {
      const orderDate = new Date(order.orderDate)
      const start = new Date(startDate)
      const end = new Date(endDate)
      return orderDate >= start && orderDate <= end
    })

    return generateMockAnalytics(filteredOrders)
  }

  const exportReport = (type: "sales" | "products" | "customers" | "orders") => {
    // Mock export functionality
    const reportData = {
      sales: {
        totalRevenue: analytics.totalRevenue,
        monthlyRevenue: analytics.monthlyRevenue,
        salesByMonth: analytics.salesByMonth,
      },
      products: {
        totalProducts: analytics.totalProducts,
        topSellingProducts: analytics.topSellingProducts,
        lowStockProducts: analytics.lowStockProducts,
      },
      customers: {
        totalCustomers: analytics.totalCustomers,
        newCustomers: analytics.newCustomers,
        returningCustomers: analytics.returningCustomers,
      },
      orders: {
        totalOrders: analytics.totalOrders,
        ordersByStatus: analytics.ordersByStatus,
        salesByDay: analytics.salesByDay,
      },
    }

    const dataStr = JSON.stringify(reportData[type], null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `${type}-report-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <AnalyticsContext.Provider value={{ analytics, refreshAnalytics, getAnalyticsByDateRange, exportReport }}>
      {children}
    </AnalyticsContext.Provider>
  )
}

export function useAnalytics() {
  const context = useContext(AnalyticsContext)
  if (context === undefined) {
    throw new Error("useAnalytics must be used within an AnalyticsProvider")
  }
  return context
}
