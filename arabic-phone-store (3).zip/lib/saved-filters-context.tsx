"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { FilterValues } from "@/components/filters/advanced-filter"

interface SavedFilter {
  id: string
  name: string
  type: string // 'orders', 'products', 'customers', etc.
  values: FilterValues
  createdAt: string
}

interface SavedFiltersContextType {
  savedFilters: SavedFilter[]
  saveFilter: (name: string, type: string, values: FilterValues) => void
  deleteFilter: (id: string) => void
  getFiltersByType: (type: string) => SavedFilter[]
}

const SavedFiltersContext = createContext<SavedFiltersContextType | undefined>(undefined)

export function SavedFiltersProvider({ children }: { children: ReactNode }) {
  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>([])

  useEffect(() => {
    const saved = localStorage.getItem("savedFilters")
    if (saved) {
      try {
        setSavedFilters(JSON.parse(saved))
      } catch (error) {
        console.error("Failed to parse saved filters:", error)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("savedFilters", JSON.stringify(savedFilters))
  }, [savedFilters])

  const saveFilter = (name: string, type: string, values: FilterValues) => {
    const newFilter: SavedFilter = {
      id: Date.now().toString(),
      name,
      type,
      values,
      createdAt: new Date().toISOString(),
    }
    setSavedFilters((prev) => [...prev, newFilter])
  }

  const deleteFilter = (id: string) => {
    setSavedFilters((prev) => prev.filter((filter) => filter.id !== id))
  }

  const getFiltersByType = (type: string) => {
    return savedFilters.filter((filter) => filter.type === type)
  }

  return (
    <SavedFiltersContext.Provider value={{ savedFilters, saveFilter, deleteFilter, getFiltersByType }}>
      {children}
    </SavedFiltersContext.Provider>
  )
}

export function useSavedFilters() {
  const context = useContext(SavedFiltersContext)
  if (context === undefined) {
    throw new Error("useSavedFilters must be used within a SavedFiltersProvider")
  }
  return context
}
