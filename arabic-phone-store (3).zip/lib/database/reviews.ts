import { supabase } from "@/lib/supabase"
import type { Database } from "@/lib/supabase"

type Review = Database["public"]["Tables"]["reviews"]["Row"]
type ReviewInsert = Database["public"]["Tables"]["reviews"]["Insert"]

export class ReviewsService {
  // Get reviews for a product
  static async getProductReviews(productId: string) {
    const { data, error } = await supabase
      .from("reviews")
      .select("*")
      .eq("product_id", productId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching reviews:", error)
      return { reviews: [], error }
    }

    return { reviews: data || [], error: null }
  }

  // Add new review
  static async addReview(review: ReviewInsert) {
    const { data, error } = await supabase.from("reviews").insert(review).select().single()

    if (error) {
      console.error("Error adding review:", error)
      return { review: null, error }
    }

    // Update product rating
    await this.updateProductRating(review.product_id)

    return { review: data, error: null }
  }

  // Update product rating based on reviews
  static async updateProductRating(productId: string) {
    const { data: reviews, error } = await supabase.from("reviews").select("rating").eq("product_id", productId)

    if (error || !reviews?.length) return

    const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
    const reviewCount = reviews.length

    await supabase
      .from("products")
      .update({
        rating: Math.round(averageRating * 10) / 10,
        review_count: reviewCount,
        updated_at: new Date().toISOString(),
      })
      .eq("id", productId)
  }

  // Delete review
  static async deleteReview(id: string, productId: string) {
    const { error } = await supabase.from("reviews").delete().eq("id", id)

    if (error) {
      console.error("Error deleting review:", error)
      return { error }
    }

    // Update product rating
    await this.updateProductRating(productId)

    return { error: null }
  }
}
