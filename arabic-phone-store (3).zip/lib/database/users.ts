import { supabase } from "@/lib/supabase"
import type { Database } from "@/lib/supabase"

type User = Database["public"]["Tables"]["users"]["Row"]
type UserInsert = Database["public"]["Tables"]["users"]["Insert"]
type UserUpdate = Database["public"]["Tables"]["users"]["Update"]

export class UsersService {
  // Get user by ID
  static async getUserById(id: string) {
    const { data, error } = await supabase.from("users").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching user:", error)
      return { user: null, error }
    }

    return { user: data, error: null }
  }

  // Create or update user profile
  static async upsertUser(user: UserInsert) {
    const { data, error } = await supabase.from("users").upsert(user).select().single()

    if (error) {
      console.error("Error upserting user:", error)
      return { user: null, error }
    }

    return { user: data, error: null }
  }

  // Update user profile
  static async updateUser(id: string, updates: UserUpdate) {
    const { data, error } = await supabase
      .from("users")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error updating user:", error)
      return { user: null, error }
    }

    return { user: data, error: null }
  }

  // Get all users (Admin only)
  static async getUsers(filters?: {
    role?: string
    limit?: number
    offset?: number
  }) {
    let query = supabase.from("users").select("*")

    if (filters?.role) {
      query = query.eq("role", filters.role)
    }

    if (filters?.limit) {
      query = query.limit(filters.limit)
    }

    if (filters?.offset) {
      query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
    }

    const { data, error, count } = await query.order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching users:", error)
      return { users: [], count: 0, error }
    }

    return { users: data || [], count: count || 0, error: null }
  }

  // Get user analytics
  static async getUserAnalytics() {
    const { data, error } = await supabase.from("users").select("id, role, created_at")

    if (error) {
      console.error("Error fetching user analytics:", error)
      return { analytics: null, error }
    }

    const users = data || []
    const totalUsers = users.length
    const adminUsers = users.filter((u) => u.role === "admin").length
    const customerUsers = users.filter((u) => u.role === "customer").length

    const thisMonth = new Date().getMonth()
    const thisYear = new Date().getFullYear()
    const newUsersThisMonth = users.filter((u) => {
      const userDate = new Date(u.created_at)
      return userDate.getMonth() === thisMonth && userDate.getFullYear() === thisYear
    }).length

    return {
      analytics: {
        totalUsers,
        adminUsers,
        customerUsers,
        newUsersThisMonth,
      },
      error: null,
    }
  }
}
