import { supabase } from "@/lib/supabase"
import type { Database } from "@/lib/supabase"

type Order = Database["public"]["Tables"]["orders"]["Row"]
type OrderInsert = Database["public"]["Tables"]["orders"]["Insert"]
type OrderUpdate = Database["public"]["Tables"]["orders"]["Update"]

export class OrdersService {
  // Create new order
  static async createOrder(order: OrderInsert) {
    const { data, error } = await supabase
      .from("orders")
      .insert({
        ...order,
        order_date: new Date().toISOString().split("T")[0],
      })
      .select()
      .single()

    if (error) {
      console.error("Error creating order:", error)
      return { order: null, error }
    }

    return { order: data, error: null }
  }

  // Get orders with filters
  static async getOrders(filters?: {
    userId?: string
    status?: string
    startDate?: string
    endDate?: string
    limit?: number
    offset?: number
  }) {
    let query = supabase.from("orders").select("*")

    if (filters?.userId) {
      query = query.eq("user_id", filters.userId)
    }

    if (filters?.status) {
      query = query.eq("status", filters.status)
    }

    if (filters?.startDate) {
      query = query.gte("order_date", filters.startDate)
    }

    if (filters?.endDate) {
      query = query.lte("order_date", filters.endDate)
    }

    if (filters?.limit) {
      query = query.limit(filters.limit)
    }

    if (filters?.offset) {
      query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
    }

    const { data, error, count } = await query.order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching orders:", error)
      return { orders: [], count: 0, error }
    }

    return { orders: data || [], count: count || 0, error: null }
  }

  // Get order by ID
  static async getOrderById(id: string) {
    const { data, error } = await supabase.from("orders").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching order:", error)
      return { order: null, error }
    }

    return { order: data, error: null }
  }

  // Update order status
  static async updateOrderStatus(id: string, status: string) {
    const { data, error } = await supabase
      .from("orders")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error updating order status:", error)
      return { order: null, error }
    }

    return { order: data, error: null }
  }

  // Get order analytics
  static async getOrderAnalytics(startDate?: string, endDate?: string) {
    let query = supabase.from("orders").select("*")

    if (startDate) {
      query = query.gte("order_date", startDate)
    }

    if (endDate) {
      query = query.lte("order_date", endDate)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching order analytics:", error)
      return { analytics: null, error }
    }

    const orders = data || []
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)
    const totalOrders = orders.length
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0

    const ordersByStatus = orders.reduce(
      (acc, order) => {
        acc[order.status] = (acc[order.status] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const ordersByMonth = orders.reduce(
      (acc, order) => {
        const month = new Date(order.order_date).toLocaleDateString("ar-SA", {
          month: "short",
          year: "numeric",
        })
        if (!acc[month]) {
          acc[month] = { revenue: 0, orders: 0 }
        }
        acc[month].revenue += order.total
        acc[month].orders += 1
        return acc
      },
      {} as Record<string, { revenue: number; orders: number }>,
    )

    return {
      analytics: {
        totalRevenue,
        totalOrders,
        averageOrderValue,
        ordersByStatus,
        ordersByMonth: Object.entries(ordersByMonth).map(([month, data]) => ({
          month,
          ...data,
        })),
      },
      error: null,
    }
  }
}
