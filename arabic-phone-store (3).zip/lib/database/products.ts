import { supabase } from "@/lib/supabase"
import type { Database } from "@/lib/supabase"

type Product = Database["public"]["Tables"]["products"]["Row"]
type ProductInsert = Database["public"]["Tables"]["products"]["Insert"]
type ProductUpdate = Database["public"]["Tables"]["products"]["Update"]

export class ProductsService {
  // Get all products with filters
  static async getProducts(filters?: {
    category?: string
    brand?: string
    minPrice?: number
    maxPrice?: number
    search?: string
    limit?: number
    offset?: number
  }) {
    let query = supabase.from("products").select("*").eq("is_active", true)

    if (filters?.category) {
      query = query.eq("category", filters.category)
    }

    if (filters?.brand) {
      query = query.eq("brand", filters.brand)
    }

    if (filters?.minPrice) {
      query = query.gte("current_price", filters.minPrice)
    }

    if (filters?.maxPrice) {
      query = query.lte("current_price", filters.maxPrice)
    }

    if (filters?.search) {
      query = query.or(
        `name.ilike.%${filters.search}%,description.ilike.%${filters.search}%,brand.ilike.%${filters.search}%`,
      )
    }

    if (filters?.limit) {
      query = query.limit(filters.limit)
    }

    if (filters?.offset) {
      query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
    }

    const { data, error, count } = await query.order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching products:", error)
      return { products: [], count: 0, error }
    }

    return { products: data || [], count: count || 0, error: null }
  }

  // Get product by slug
  static async getProductBySlug(slug: string) {
    const { data, error } = await supabase.from("products").select("*").eq("slug", slug).eq("is_active", true).single()

    if (error) {
      console.error("Error fetching product:", error)
      return { product: null, error }
    }

    return { product: data, error: null }
  }

  // Get related products
  static async getRelatedProducts(productId: string, category: string, limit = 4) {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("category", category)
      .neq("id", productId)
      .eq("is_active", true)
      .limit(limit)

    if (error) {
      console.error("Error fetching related products:", error)
      return { products: [], error }
    }

    return { products: data || [], error: null }
  }

  // Create product (Admin only)
  static async createProduct(product: ProductInsert) {
    const { data, error } = await supabase.from("products").insert(product).select().single()

    if (error) {
      console.error("Error creating product:", error)
      return { product: null, error }
    }

    return { product: data, error: null }
  }

  // Update product (Admin only)
  static async updateProduct(id: string, updates: ProductUpdate) {
    const { data, error } = await supabase
      .from("products")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error updating product:", error)
      return { product: null, error }
    }

    return { product: data, error: null }
  }

  // Delete product (Admin only)
  static async deleteProduct(id: string) {
    const { error } = await supabase
      .from("products")
      .update({ is_active: false, updated_at: new Date().toISOString() })
      .eq("id", id)

    if (error) {
      console.error("Error deleting product:", error)
      return { error }
    }

    return { error: null }
  }

  // Get product analytics
  static async getProductAnalytics() {
    const { data, error } = await supabase
      .from("products")
      .select("id, name, current_price, stock, category, brand")
      .eq("is_active", true)

    if (error) {
      console.error("Error fetching product analytics:", error)
      return { analytics: null, error }
    }

    // Calculate analytics
    const totalProducts = data?.length || 0
    const lowStockProducts = data?.filter((p) => p.stock < 10) || []
    const categories = [...new Set(data?.map((p) => p.category))] || []
    const brands = [...new Set(data?.map((p) => p.brand))] || []

    return {
      analytics: {
        totalProducts,
        lowStockProducts,
        categories,
        brands,
        averagePrice: data?.reduce((sum, p) => sum + p.current_price, 0) / totalProducts || 0,
      },
      error: null,
    }
  }
}
