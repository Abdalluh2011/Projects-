"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"

export interface RecentlyViewedItem {
  id: string
  name: string
  price: number
  image: string
  slug: string
  viewedAt: string
}

interface RecentlyViewedContextType {
  recentlyViewed: RecentlyViewedItem[]
  addToRecentlyViewed: (product: Omit<RecentlyViewedItem, "viewedAt">) => void
  clearRecentlyViewed: () => void
}

const RecentlyViewedContext = createContext<RecentlyViewedContextType | undefined>(undefined)

export function RecentlyViewedProvider({ children }: { children: ReactNode }) {
  const [recentlyViewed, setRecentlyViewed] = useState<RecentlyViewedItem[]>([])

  useEffect(() => {
    const saved = localStorage.getItem("recentlyViewed")
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        setRecentlyViewed(parsed)
      } catch (error) {
        console.error("Failed to parse recently viewed from localStorage:", error)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("recentlyViewed", JSON.stringify(recentlyViewed))
  }, [recentlyViewed])

  const addToRecentlyViewed = useCallback((product: Omit<RecentlyViewedItem, "viewedAt">) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((item) => item.id !== product.id)
      const newItem = { ...product, viewedAt: new Date().toISOString() }
      return [newItem, ...filtered].slice(0, 10) // Keep only last 10 items
    })
  }, [])

  const clearRecentlyViewed = useCallback(() => {
    setRecentlyViewed([])
  }, [])

  return (
    <RecentlyViewedContext.Provider value={{ recentlyViewed, addToRecentlyViewed, clearRecentlyViewed }}>
      {children}
    </RecentlyViewedContext.Provider>
  )
}

export function useRecentlyViewed() {
  const context = useContext(RecentlyViewedContext)
  if (context === undefined) {
    throw new Error("useRecentlyViewed must be used within a RecentlyViewedProvider")
  }
  return context
}
