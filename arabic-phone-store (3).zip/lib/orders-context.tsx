"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type OrderStatus = "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "cancelled"

export interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

export interface Order {
  id: string
  items: OrderItem[]
  total: number
  status: OrderStatus
  customerInfo: {
    firstName: string
    lastName: string
    email: string
    phone: string
    address: string
    city: string
    governorate: string
  }
  paymentMethod: string
  orderDate: string
  estimatedDelivery: string
  trackingNumber?: string
  statusHistory: {
    status: OrderStatus
    date: string
    description: string
  }[]
}

interface OrdersContextType {
  orders: Order[]
  addOrder: (order: Omit<Order, "id" | "orderDate" | "estimatedDelivery" | "statusHistory">) => string
  updateOrderStatus: (orderId: string, status: OrderStatus, description: string) => void
  getOrderById: (orderId: string) => Order | undefined
  getUserOrders: (email: string) => Order[]
}

const OrdersContext = createContext<OrdersContextType | undefined>(undefined)

// بيانات تجريبية للطلبات
const initialOrders: Order[] = [
  {
    id: "ORD-2024-001",
    items: [
      {
        id: "iphone-13-pro-max",
        name: "iPhone 13 Pro Max",
        price: 3499,
        quantity: 1,
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Apple-iPhone-13-Pro-Max.jpg-5LdOkm0VBerQt0ixtSfiS9s9D4n0dC.jpeg",
      },
    ],
    total: 4023.85,
    status: "shipped",
    customerInfo: {
      firstName: "أحمد",
      lastName: "محمد",
      email: "ahmed@example.com",
      phone: "+967712345678",
      address: "شارع الستين، حي الحصبة",
      city: "عدن",
      governorate: "عدن",
    },
    paymentMethod: "cash",
    orderDate: "2024-01-15",
    estimatedDelivery: "2024-01-20",
    trackingNumber: "TRK123456789",
    statusHistory: [
      { status: "pending", date: "2024-01-15", description: "تم استلام الطلب وهو قيد المراجعة" },
      { status: "confirmed", date: "2024-01-15", description: "تم تأكيد الطلب وبدء التحضير" },
      { status: "processing", date: "2024-01-16", description: "جاري تحضير الطلب للشحن" },
      { status: "shipped", date: "2024-01-17", description: "تم شحن الطلب وهو في الطريق إليك" },
    ],
  },
  {
    id: "ORD-2025-002",
    items: [
      {
        id: "samsung-galaxy-a14",
        name: "Samsung Galaxy A14",
        price: 699,
        quantity: 1,
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Samsung-Galaxy-A1.jpg-FRpMapWDErmg6JakD8WINgoKimWgC6.jpeg",
      },
      {
        id: "xiaomi-poco-x3-pro",
        name: "Xiaomi Poco X3 Pro",
        price: 899,
        quantity: 1,
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Xiaomi--Poco-X3.jpg-AxGFvcWyA8LHCv9pEkEV02z7uQAgtC.jpeg",
      },
    ],
    total: 1837.7,
    status: "processing",
    customerInfo: {
      firstName: "فاطمة",
      lastName: "علي",
      email: "fatima@example.com",
      phone: "+967713456789",
      address: "شارع الزبيري، حي السبعين",
      city: "صنعاء",
      governorate: "صنعاء",
    },
    paymentMethod: "cash",
    orderDate: "2025-01-18",
    estimatedDelivery: "2025-01-23",
    trackingNumber: "TRK987654321",
    statusHistory: [
      { status: "pending", date: "2025-01-18", description: "تم استلام الطلب وهو قيد المراجعة" },
      { status: "confirmed", date: "2025-01-18", description: "تم تأكيد الطلب وبدء التحضير" },
      { status: "processing", date: "2025-01-19", description: "جاري تحضير الطلب للشحن" },
    ],
  },
  {
    id: "ORD-2025-003",
    items: [
      {
        id: "oneplus-nord-n20",
        name: "OnePlus Nord N20",
        price: 1299,
        quantity: 1,
        image:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/one-plus.jpg-RgjPIWJgJaWgVbay26Hk2rIgJUoLcF.jpeg",
      },
    ],
    total: 1493.85,
    status: "confirmed",
    customerInfo: {
      firstName: "محمد",
      lastName: "سالم",
      email: "mohammed@example.com",
      phone: "+967714567890",
      address: "شارع جمال، حي الحصبة",
      city: "تعز",
      governorate: "تعز",
    },
    paymentMethod: "card",
    orderDate: "2025-01-20",
    estimatedDelivery: "2025-01-25",
    statusHistory: [
      { status: "pending", date: "2025-01-20", description: "تم استلام الطلب وهو قيد المراجعة" },
      { status: "confirmed", date: "2025-01-20", description: "تم تأكيد الطلب وبدء التحضير" },
    ],
  },
]

export function OrdersProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(initialOrders)

  useEffect(() => {
    const savedOrders = localStorage.getItem("orders")
    if (savedOrders) {
      try {
        const parsedOrders = JSON.parse(savedOrders)
        // دمج الطلبات المحفوظة مع الطلبات الافتراضية
        const mergedOrders = [...parsedOrders]
        // إضافة الطلبات الافتراضية إذا لم تكن موجودة
        initialOrders.forEach((initialOrder) => {
          if (!mergedOrders.find((order) => order.id === initialOrder.id)) {
            mergedOrders.push(initialOrder)
          }
        })
        setOrders(mergedOrders)
      } catch (error) {
        console.error("Failed to parse orders from localStorage:", error)
        setOrders(initialOrders)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders))
  }, [orders])

  const addOrder = (orderData: Omit<Order, "id" | "orderDate" | "estimatedDelivery" | "statusHistory">) => {
    const orderId = `ORD-${new Date().getFullYear()}-${String(orders.length + 1).padStart(3, "0")}`
    const orderDate = new Date().toISOString().split("T")[0]
    const estimatedDelivery = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]

    const newOrder: Order = {
      ...orderData,
      id: orderId,
      orderDate,
      estimatedDelivery,
      status: "pending",
      statusHistory: [
        {
          status: "pending",
          date: orderDate,
          description: "تم استلام الطلب وهو قيد المراجعة",
        },
      ],
    }

    setOrders((prev) => [newOrder, ...prev])
    return orderId
  }

  const updateOrderStatus = (orderId: string, status: OrderStatus, description: string) => {
    setOrders((prev) =>
      prev.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status,
              statusHistory: [
                ...order.statusHistory,
                {
                  status,
                  date: new Date().toISOString().split("T")[0],
                  description,
                },
              ],
            }
          : order,
      ),
    )
  }

  const getOrderById = (orderId: string) => {
    return orders.find((order) => order.id === orderId)
  }

  const getUserOrders = (email: string) => {
    return orders.filter((order) => order.customerInfo.email === email)
  }

  return (
    <OrdersContext.Provider value={{ orders, addOrder, updateOrderStatus, getOrderById, getUserOrders }}>
      {children}
    </OrdersContext.Provider>
  )
}

export function useOrders() {
  const context = useContext(OrdersContext)
  if (context === undefined) {
    throw new Error("useOrders must be used within an OrdersProvider")
  }
  return context
}
