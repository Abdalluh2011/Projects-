// Performance monitoring utilities
export class PerformanceMonitor {
  private static metrics: Map<string, number> = new Map()

  static startTimer(label: string) {
    this.metrics.set(label, performance.now())
  }

  static endTimer(label: string): number {
    const startTime = this.metrics.get(label)
    if (!startTime) return 0

    const duration = performance.now() - startTime
    this.metrics.delete(label)

    if (process.env.NODE_ENV === "development") {
      console.log(`⏱️ ${label}: ${duration.toFixed(2)}ms`)
    }

    return duration
  }

  static measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T> {
    return new Promise(async (resolve, reject) => {
      this.startTimer(label)
      try {
        const result = await fn()
        this.endTimer(label)
        resolve(result)
      } catch (error) {
        this.endTimer(label)
        reject(error)
      }
    })
  }

  static logWebVitals() {
    if (typeof window !== "undefined" && "performance" in window) {
      // Log Core Web Vitals
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          console.log(`📊 ${entry.name}: ${entry.value}`)
        }
      }).observe({ entryTypes: ["measure", "navigation"] })
    }
  }
}

// Cache utilities
export class CacheManager {
  private static cache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map()

  static set(key: string, data: any, ttlMinutes = 5) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMinutes * 60 * 1000,
    })
  }

  static get(key: string) {
    const item = this.cache.get(key)
    if (!item) return null

    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key)
      return null
    }

    return item.data
  }

  static clear() {
    this.cache.clear()
  }

  static size() {
    return this.cache.size
  }
}

// Image optimization utilities
export function getOptimizedImageUrl(url: string, width?: number, height?: number, quality = 80) {
  if (!url) return "/placeholder.svg?height=400&width=400"

  // If it's already a placeholder, return as is
  if (url.includes("placeholder.svg")) return url

  // For Supabase storage URLs, add transformation parameters
  if (url.includes("supabase")) {
    const params = new URLSearchParams()
    if (width) params.set("width", width.toString())
    if (height) params.set("height", height.toString())
    params.set("quality", quality.toString())

    return `${url}?${params.toString()}`
  }

  return url
}
