"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type NotificationType = "success" | "error" | "warning" | "info"

export interface Notification {
  id: string
  type: NotificationType
  title: string
  message: string
  timestamp: string
  read: boolean
  action?: {
    label: string
    url: string
  }
}

interface NotificationsContextType {
  notifications: Notification[]
  addNotification: (notification: Omit<Notification, "id" | "timestamp" | "read">) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
  removeNotification: (id: string) => void
  clearAll: () => void
  unreadCount: number
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined)

// إشعارات تجريبية
const initialNotifications: Notification[] = [
  {
    id: "1",
    type: "success",
    title: "تم تأكيد طلبك",
    message: "تم تأكيد طلبك #ORD-2024-001 وسيتم شحنه قريباً",
    timestamp: "2024-01-17T10:30:00Z",
    read: false,
    action: {
      label: "تتبع الطلب",
      url: "/orders/ORD-2024-001",
    },
  },
  {
    id: "2",
    type: "info",
    title: "عرض خاص",
    message: "خصم 20% على جميع هواتف Samsung لفترة محدودة!",
    timestamp: "2024-01-16T14:15:00Z",
    read: false,
    action: {
      label: "تسوق الآن",
      url: "/products?brand=Samsung",
    },
  },
  {
    id: "3",
    type: "warning",
    title: "انتهاء العرض قريباً",
    message: "عرض iPhone 13 Pro Max ينتهي خلال 24 ساعة",
    timestamp: "2024-01-15T09:00:00Z",
    read: true,
  },
]

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications)

  useEffect(() => {
    const savedNotifications = localStorage.getItem("notifications")
    if (savedNotifications) {
      try {
        const parsedNotifications = JSON.parse(savedNotifications)
        setNotifications(parsedNotifications)
      } catch (error) {
        console.error("Failed to parse notifications from localStorage:", error)
        setNotifications(initialNotifications)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("notifications", JSON.stringify(notifications))
  }, [notifications])

  const addNotification = (notificationData: Omit<Notification, "id" | "timestamp" | "read">) => {
    const newNotification: Notification = {
      ...notificationData,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      read: false,
    }
    setNotifications((prev) => [newNotification, ...prev])
  }

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notif) => ({ ...notif, read: true })))
  }

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id))
  }

  const clearAll = () => {
    setNotifications([])
  }

  const unreadCount = notifications.filter((notif) => !notif.read).length

  return (
    <NotificationsContext.Provider
      value={{
        notifications,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
        clearAll,
        unreadCount,
      }}
    >
      {children}
    </NotificationsContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationsContext)
  if (context === undefined) {
    throw new Error("useNotifications must be used within a NotificationsProvider")
  }
  return context
}
