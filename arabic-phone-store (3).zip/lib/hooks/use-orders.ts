"use client"

import { useState, useEffect } from "react"
import { OrdersService } from "@/lib/database/orders"

export function useOrders(filters?: {
  userId?: string
  status?: string
  startDate?: string
  endDate?: string
  limit?: number
  offset?: number
}) {
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [count, setCount] = useState(0)

  useEffect(() => {
    async function fetchOrders() {
      setLoading(true)
      setError(null)

      const { orders: data, count: total, error: err } = await OrdersService.getOrders(filters)

      if (err) {
        setError(err.message)
      } else {
        setOrders(data)
        setCount(total)
      }

      setLoading(false)
    }

    fetchOrders()
  }, [filters?.userId, filters?.status, filters?.startDate, filters?.endDate, filters?.limit, filters])

  const updateOrderStatus = async (orderId: string, status: string) => {
    const { order, error } = await OrdersService.updateOrderStatus(orderId, status)

    if (!error && order) {
      setOrders((prev) => prev.map((o) => (o.id === orderId ? order : o)))
    }

    return { order, error }
  }

  return { orders, loading, error, count, updateOrderStatus }
}

export function useOrder(id: string) {
  const [order, setOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchOrder() {
      setLoading(true)
      setError(null)

      const { order: data, error: err } = await OrdersService.getOrderById(id)

      if (err) {
        setError(err.message)
      } else {
        setOrder(data)
      }

      setLoading(false)
    }

    if (id) {
      fetchOrder()
    }
  }, [id])

  return { order, loading, error }
}
