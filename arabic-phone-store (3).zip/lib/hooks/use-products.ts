"use client"

import { useState, useEffect } from "react"
import { ProductsService } from "@/lib/database/products"

export function useProducts(filters?: {
  category?: string
  brand?: string
  minPrice?: number
  maxPrice?: number
  search?: string
  limit?: number
  offset?: number
}) {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [count, setCount] = useState(0)

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true)
      setError(null)

      const { products: data, count: total, error: err } = await ProductsService.getProducts(filters)

      if (err) {
        setError(err.message)
      } else {
        setProducts(data)
        setCount(total)
      }

      setLoading(false)
    }

    fetchProducts()
  }, [filters])

  return { products, loading, error, count }
}

export function useProduct(slug: string) {
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchProduct() {
      setLoading(true)
      setError(null)

      const { product: data, error: err } = await ProductsService.getProductBySlug(slug)

      if (err) {
        setError(err.message)
      } else {
        setProduct(data)
      }

      setLoading(false)
    }

    if (slug) {
      fetchProduct()
    }
  }, [slug])

  return { product, loading, error }
}
