import type { FilterValues } from "@/components/filters/advanced-filter"

export function applyFilters<T>(data: T[], filters: FilterValues, filterConfig: any[]): T[] {
  return data.filter((item: any) => {
    return Object.entries(filters).every(([key, value]) => {
      if (!value || (Array.isArray(value) && value.length === 0)) return true

      const config = filterConfig.find((f) => f.key === key)
      if (!config) return true

      const itemValue = getNestedValue(item, key)

      switch (config.type) {
        case "search":
          return itemValue?.toString().toLowerCase().includes(value.toLowerCase())

        case "select":
          return itemValue === value

        case "multiselect":
          return value.includes(itemValue)

        case "range":
          const numValue = Number.parseFloat(itemValue)
          const min = value.min ? Number.parseFloat(value.min) : Number.NEGATIVE_INFINITY
          const max = value.max ? Number.parseFloat(value.max) : Number.POSITIVE_INFINITY
          return numValue >= min && numValue <= max

        case "date":
          const itemDate = new Date(itemValue).toISOString().split("T")[0]
          return itemDate === value

        case "daterange":
          const date = new Date(itemValue).toISOString().split("T")[0]
          const startDate = value.start || "1900-01-01"
          const endDate = value.end || "2100-12-31"
          return date >= startDate && date <= endDate

        case "number":
          return Number.parseFloat(itemValue) === Number.parseFloat(value)

        default:
          return true
      }
    })
  })
}

export function applySorting<T>(data: T[], sortKey: string, direction: "asc" | "desc"): T[] {
  return [...data].sort((a: any, b: any) => {
    const aValue = getNestedValue(a, sortKey)
    const bValue = getNestedValue(b, sortKey)

    let comparison = 0

    if (typeof aValue === "string" && typeof bValue === "string") {
      comparison = aValue.localeCompare(bValue, "ar")
    } else if (typeof aValue === "number" && typeof bValue === "number") {
      comparison = aValue - bValue
    } else if (aValue instanceof Date && bValue instanceof Date) {
      comparison = aValue.getTime() - bValue.getTime()
    } else {
      comparison = String(aValue).localeCompare(String(bValue), "ar")
    }

    return direction === "desc" ? -comparison : comparison
  })
}

function getNestedValue(obj: any, path: string): any {
  return path.split(".").reduce((current, key) => current?.[key], obj)
}

export function getFilterSummary(filters: FilterValues, filterConfig: any[]): string[] {
  const summary: string[] = []

  Object.entries(filters).forEach(([key, value]) => {
    if (!value || (Array.isArray(value) && value.length === 0)) return

    const config = filterConfig.find((f) => f.key === key)
    if (!config) return

    switch (config.type) {
      case "search":
        summary.push(`البحث: "${value}"`)
        break
      case "select":
        const option = config.options?.find((o: any) => o.value === value)
        summary.push(`${config.label}: ${option?.label || value}`)
        break
      case "multiselect":
        const selectedOptions = config.options?.filter((o: any) => value.includes(o.value))
        if (selectedOptions?.length) {
          summary.push(`${config.label}: ${selectedOptions.map((o: any) => o.label).join(", ")}`)
        }
        break
      case "range":
        if (value.min || value.max) {
          const min = value.min || "غير محدد"
          const max = value.max || "غير محدد"
          summary.push(`${config.label}: ${min} - ${max}`)
        }
        break
      case "daterange":
        if (value.start || value.end) {
          const start = value.start || "غير محدد"
          const end = value.end || "غير محدد"
          summary.push(`${config.label}: ${start} إلى ${end}`)
        }
        break
      default:
        summary.push(`${config.label}: ${value}`)
    }
  })

  return summary
}
