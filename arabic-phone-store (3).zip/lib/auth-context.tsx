"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  name: string
  role: "admin" | "customer"
  avatar?: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  isAdmin: () => boolean
  isAuthenticated: () => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// بيانات المدراء المسموح لهم (في التطبيق الحقيقي، هذه ستأتي من قاعدة البيانات)
const ADMIN_USERS = [
  {
    id: "admin-1",
    email: "admin@alshamel.com",
    password: "admin123", // في التطبيق الحقيقي، يجب تشفير كلمة المرور
    name: "مدير النظام",
    role: "admin" as const,
    avatar: "/admin-avatar.jpg",
  },
  {
    id: "admin-2",
    email: "manager@alshamel.com",
    password: "manager123",
    name: "مدير المتجر",
    role: "admin" as const,
    avatar: "/manager-avatar.jpg",
  },
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // التحقق من وجود جلسة محفوظة
    const savedUser = localStorage.getItem("auth_user")
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser)
        setUser(userData)
      } catch (error) {
        console.error("خطأ في تحليل بيانات المستخدم المحفوظة:", error)
        localStorage.removeItem("auth_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true)

    // محاكاة تأخير الشبكة
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const adminUser = ADMIN_USERS.find((admin) => admin.email === email && admin.password === password)

    if (adminUser) {
      const userData: User = {
        id: adminUser.id,
        email: adminUser.email,
        name: adminUser.name,
        role: adminUser.role,
        avatar: adminUser.avatar,
      }

      setUser(userData)
      localStorage.setItem("auth_user", JSON.stringify(userData))
      setIsLoading(false)
      return { success: true }
    } else {
      setIsLoading(false)
      return { success: false, error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" }
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("auth_user")
  }

  const isAdmin = () => {
    return user?.role === "admin"
  }

  const isAuthenticated = () => {
    return user !== null
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        logout,
        isAdmin,
        isAuthenticated,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
