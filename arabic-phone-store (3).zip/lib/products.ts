export interface Product {
  id: string
  name: string
  slug: string
  image: string
  rating: number
  reviewCount: number
  currentPrice: number
  oldPrice?: number
  badge?: {
    type: "new" | "bestseller" | "special"
    text: string
  }
  specifications: {
    screen: string
    processor: string
    backCamera: string
    frontCamera: string
    storage: string
    ram?: string
    battery: string
    additionalFeatures?: string
  }
  description: string
  brand: string
  category: string
}

export const products: Product[] = [
  {
    id: "iphone-13-pro-max",
    name: "iPhone 13 Pro Max",
    slug: "iphone-13-pro-max",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Apple-iPhone-13-Pro-Max.jpg-5LdOkm0VBerQt0ixtSfiS9s9D4n0dC.jpeg",
    rating: 4.8,
    reviewCount: 156,
    currentPrice: 3499,
    oldPrice: 3999,
    badge: {
      type: "new",
      text: "جديد",
    },
    specifications: {
      screen: "Super Retina XDR بحجم 6.7 بوصة، 120Hz",
      processor: "شريحة A15 Bionic",
      backCamera: "نظام Pro بدقة 12MP (واسعة، واسعة جدًا، تقريب)",
      frontCamera: "TrueDepth بدقة 12MP",
      storage: "128GB / 256GB / 512GB / 1TB",
      battery: "تشغيل فيديو حتى 28 ساعة",
      additionalFeatures: "مقاومة الماء IP68، Face ID، MagSafe",
    },
    description:
      "يُعد iPhone 13 Pro Max قفزة نوعية في عالم الهواتف الذكية، حيث يقدم أكبر تحديث لنظام كاميرات Pro على الإطلاق، وشاشة Super Retina XDR مذهلة مع تقنية ProMotion لتجربة أكثر سلاسة واستجابة.",
    brand: "Apple",
    category: "هواتف فاخرة",
  },
  {
    id: "samsung-galaxy-a14",
    name: "Samsung Galaxy A14",
    slug: "samsung-galaxy-a14",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Samsung-Galaxy-A1.jpg-FRpMapWDErmg6JakD8WINgoKimWgC6.jpeg",
    rating: 4.2,
    reviewCount: 98,
    currentPrice: 699,
    oldPrice: 799,
    badge: {
      type: "bestseller",
      text: "الأكثر مبيعاً",
    },
    specifications: {
      screen: "PLS LCD بحجم 6.6 بوصة، 90Hz",
      processor: "Exynos 850",
      backCamera: "ثلاثية: 50MP (رئيسية) + 5MP (واسعة جداً) + 2MP (ماكرو)",
      frontCamera: "13MP",
      storage: "64GB / 128GB",
      ram: "4GB / 6GB",
      battery: "5000mAh، شحن 15W",
      additionalFeatures: "مستشعر بصمة جانبي، دعم بطاقة microSD",
    },
    description:
      "هاتف Samsung Galaxy A14 يقدم تجربة استخدام ممتازة بسعر مناسب، مع شاشة كبيرة وبطارية تدوم طويلاً وكاميرا رئيسية بدقة عالية.",
    brand: "Samsung",
    category: "هواتف اقتصادية",
  },
  {
    id: "xiaomi-poco-x3-pro",
    name: "Xiaomi Poco X3 Pro",
    slug: "xiaomi-poco-x3-pro",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Xiaomi--Poco-X3.jpg-AxGFvcWyA8LHCv9pEkEV02z7uQAgtC.jpeg",
    rating: 4.5,
    reviewCount: 112,
    currentPrice: 899,
    oldPrice: 1099,
    badge: {
      type: "special",
      text: "عرض خاص",
    },
    specifications: {
      screen: "IPS LCD بحجم 6.67 بوصة، 120Hz",
      processor: "Snapdragon 860",
      backCamera: "رباعية: 48MP (رئيسية) + 8MP (واسعة جداً) + 2MP (ماكرو) + 2MP (عمق)",
      frontCamera: "20MP",
      storage: "128GB / 256GB",
      ram: "6GB / 8GB",
      battery: "5160mAh، شحن سريع 33W",
      additionalFeatures: "مكبرات صوت ستيريو، مستشعر بصمة جانبي، مقاوم للماء IP53",
    },
    description:
      "يقدم Poco X3 Pro أداءً قوياً بسعر منافس، مع معالج قوي وشاشة بمعدل تحديث عالي وبطارية كبيرة تدعم الشحن السريع.",
    brand: "Xiaomi",
    category: "هواتف متوسطة",
  },
  {
    id: "blu-r1-hd",
    name: "BLU R1 HD",
    slug: "blu-r1-hd",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/BLU-R1-HD.jpg-p5Dar2Bi87KBPYsY1oGPm5kJhvA40a.jpeg",
    rating: 3.8,
    reviewCount: 45,
    currentPrice: 299,
    specifications: {
      screen: "IPS LCD بحجم 5.2 بوصة",
      processor: "MediaTek MT6735",
      backCamera: "8MP",
      frontCamera: "5MP",
      storage: "16GB",
      ram: "2GB",
      battery: "2500mAh",
    },
    description:
      "هاتف BLU R1 HD هو خيار اقتصادي ممتاز للمستخدمين الذين يبحثون عن هاتف بسعر منخفض لأداء المهام الأساسية.",
    brand: "BLU",
    category: "هواتف اقتصادية",
  },
  {
    id: "oneplus-nord-n20",
    name: "OnePlus Nord N20",
    slug: "oneplus-nord-n20",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/one-plus.jpg-RgjPIWJgJaWgVbay26Hk2rIgJUoLcF.jpeg",
    rating: 4.4,
    reviewCount: 87,
    currentPrice: 1299,
    oldPrice: 1499,
    specifications: {
      screen: "AMOLED بحجم 6.43 بوصة، 60Hz",
      processor: "Snapdragon 695 5G",
      backCamera: "ثلاثية: 64MP (رئيسية) + 2MP (ماكرو) + 2MP (عمق)",
      frontCamera: "16MP",
      storage: "128GB",
      ram: "6GB",
      battery: "4500mAh، شحن سريع 33W",
      additionalFeatures: "مستشعر بصمة تحت الشاشة، دعم 5G",
    },
    description:
      "يجمع OnePlus Nord N20 بين التصميم الأنيق والأداء الجيد مع شاشة AMOLED وشحن سريع وكاميرا رئيسية عالية الدقة.",
    brand: "OnePlus",
    category: "هواتف متوسطة",
  },
  {
    id: "xiaomi-redmi-note-9s",
    name: "Xiaomi Redmi Note 9S",
    slug: "xiaomi-redmi-note-9s",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Xiaomi--Redmi-Note-9S.jpg-rsAUHTrY7pdy4P027KxVLFUPb9tTeA.jpeg",
    rating: 4.3,
    reviewCount: 76,
    currentPrice: 799,
    oldPrice: 899,
    specifications: {
      screen: "IPS LCD بحجم 6.67 بوصة، 60Hz",
      processor: "Snapdragon 720G",
      backCamera: "رباعية: 48MP (رئيسية) + 8MP (واسعة جداً) + 5MP (ماكرو) + 2MP (عمق)",
      frontCamera: "16MP",
      storage: "64GB / 128GB",
      ram: "4GB / 6GB",
      battery: "5020mAh، شحن 18W",
      additionalFeatures: "مستشعر بصمة جانبي، دعم بطاقة microSD",
    },
    description: "يوفر Redmi Note 9S أداءً متوازناً مع بطارية كبيرة وشاشة واسعة ونظام كاميرا رباعي بسعر مناسب.",
    brand: "Xiaomi",
    category: "هواتف اقتصادية",
  },
]

export const categories = [
  {
    id: "premium",
    name: "هواتف فاخرة",
    description: "أحدث الهواتف الذكية الرائدة بأعلى المواصفات",
  },
  {
    id: "mid-range",
    name: "هواتف متوسطة",
    description: "هواتف بمواصفات جيدة وأسعار معقولة",
  },
  {
    id: "budget",
    name: "هواتف اقتصادية",
    description: "هواتف بأسعار مناسبة للميزانيات المحدودة",
  },
]

// Utility functions
export function getProductBySlug(slug: string): Product | undefined {
  return products.find((product) => product.slug === slug)
}

export function getProductsByCategory(categoryId: string): Product[] {
  return products.filter((product) => {
    if (categoryId === "premium") return product.category === "هواتف فاخرة"
    if (categoryId === "mid-range") return product.category === "هواتف متوسطة"
    if (categoryId === "budget") return product.category === "هواتف اقتصادية"
    return true
  })
}

export function getRelatedProducts(productId: string, limit = 4): Product[] {
  const currentProduct = products.find((p) => p.id === productId)
  if (!currentProduct) return products.slice(0, limit)

  return products.filter((p) => p.id !== productId && p.category === currentProduct.category).slice(0, limit)
}
